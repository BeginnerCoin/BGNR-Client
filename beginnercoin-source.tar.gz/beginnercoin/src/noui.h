// Copyright (c) 2013 The Beginnercoin developers
// Distributed under the MIT/X11 software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef BEGINNERCOIN_NOUI_H
#define BEGINNERCOIN_NOUI_H

extern void noui_connect();

#endif
