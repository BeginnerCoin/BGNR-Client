Description
------------

This directory contains data-driven tests for various aspects of Beginnercoin.

License
--------

The data files in this directory are

    Copyright (c) 2012-2014 The Beginnercoin Core developers
    Distributed under the MIT/X11 software license, see the accompanying
    file COPYING or http://www.opensource.org/licenses/mit-license.php.

