<?xml version="1.0" ?><!DOCTYPE TS><TS language="de" version="2.1">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About Beginnercoin Core</source>
        <translation>Über Beginnercoin Core</translation>
    </message>
    <message>
        <source>&lt;b&gt;Beginnercoin Core&lt;/b&gt; version</source>
        <translation>&lt;b&gt;&quot;Beginnercoin Core&quot;&lt;/b&gt;-Version</translation>
    </message>
    <message>
        <source>
This is experimental software.

Distributed under the MIT/X11 software license, see the accompanying file COPYING or http://www.opensource.org/licenses/mit-license.php.

This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (http://www.openssl.org/) and cryptographic software written by Eric Young (eay@cryptsoft.com) and UPnP software written by Thomas Bernard.</source>
        <translation>
Dies ist experimentelle Software.

Veröffentlicht unter der MIT/X11-Softwarelizenz, siehe beiligende Datei COPYING oder http://www.opensource.org/licenses/mit-license.php.

Dieses Produkt enthält Software, die vom OpenSSL-Projekt zur Verwendung im OpenSSL-Toolkit (https://www.openssl.org) entwickelt wird, sowie von Eric Young (eay@cryptsoft.com) geschriebene kryptographische Software und von Thomas Bernard geschriebene UPnP-Software.</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Urheberrecht</translation>
    </message>
    <message>
        <source>The Beginnercoin Core developers</source>
        <translation>Die &quot;Beginnercoin Core&quot;-Entwickler</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation>(%1-Bit)</translation>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Double-click to edit address or label</source>
        <translation>Doppelklick zum Bearbeiten der Adresse oder der Bezeichnung</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Eine neue Adresse erstellen</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Neu</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Ausgewählte Adresse in die Zwischenablage kopieren</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopieren</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Schließen</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>Adresse &amp;kopieren</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Ausgewählte Adresse aus der Liste entfernen</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Daten der aktuellen Ansicht in eine Datei exportieren</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>E&amp;xportieren</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Löschen</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Wählen Sie die Adresse aus, an die Sie Beginnercoins überweisen möchten</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Wählen Sie die Adresse aus, über die Sie Beginnercoins empfangen wollen</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>&amp;Auswählen</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>Zahlungsadressen</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>Empfangsadressen</translation>
    </message>
    <message>
        <source>These are your Beginnercoin addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Dies sind ihre Beginnercoin-Adressen zum Tätigen von Überweisungen. Bitte prüfen Sie den Betrag und die Empfangsadresse, bevor Sie Beginnercoins überweisen.</translation>
    </message>
    <message>
        <source>These are your Beginnercoin addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>Dies sind ihre Beginnercoin-Adressen zum Empfangen von Zahlungen. Es wird empfohlen für jede Transaktion eine neue Empfangsadresse zu verwenden.</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>&amp;Bezeichnung kopieren</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Editieren</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>Addressliste exportieren</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Kommagetrennte-Datei (*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Exportieren fehlgeschlagen</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1.</source>
        <translation>Beim Speichern der Adressliste nach %1 ist ein Fehler aufgetreten.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(keine Bezeichnung)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Passphrasendialog</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Passphrase eingeben</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Neue Passphrase</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Neue Passphrase wiederholen</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Geben Sie die neue Passphrase für die Wallet ein.&lt;br&gt;Bitte benutzen Sie eine Passphrase bestehend aus &lt;b&gt;10 oder mehr zufälligen Zeichen&lt;/b&gt; oder &lt;b&gt;8 oder mehr Wörtern&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Wallet verschlüsseln</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Dieser Vorgang benötigt ihre Passphrase, um die Wallet zu entsperren.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Wallet entsperren</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Dieser Vorgang benötigt ihre Passphrase, um die Wallet zu entschlüsseln.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Wallet entschlüsseln</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Passphrase ändern</translation>
    </message>
    <message>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>Geben Sie die alte und neue Wallet-Passphrase ein.</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Wallet-Verschlüsselung bestätigen</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR BEGINNERCOINS&lt;/b&gt;!</source>
        <translation>Warnung: Wenn Sie ihre Wallet verschlüsseln und ihre Passphrase verlieren, werden Sie &lt;b&gt;alle ihre Beginnercoins verlieren&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Sind Sie sich sicher, dass Sie ihre Wallet verschlüsseln möchten?</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>WICHTIG: Alle vorherigen Wallet-Sicherungen sollten durch die neu erzeugte, verschlüsselte Wallet ersetzt werden. Aus Sicherheitsgründen werden vorherige Sicherungen der unverschlüsselten Wallet nutzlos, sobald Sie die neue, verschlüsselte Wallet verwenden.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Warnung: Die Feststelltaste ist aktiviert!</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Wallet verschlüsselt</translation>
    </message>
    <message>
        <source>Beginnercoin will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your beginnercoins from being stolen by malware infecting your computer.</source>
        <translation>Beginnercoin wird jetzt beendet, um den Verschlüsselungsprozess abzuschließen. Bitte beachten Sie, dass die Wallet-Verschlüsselung nicht vollständig vor Diebstahl ihrer Beginnercoins durch Schadsoftware schützt, die ihren Computer befällt.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Wallet-Verschlüsselung fehlgeschlagen</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Die Wallet-Verschlüsselung ist aufgrund eines internen Fehlers fehlgeschlagen. Ihre Wallet wurde nicht verschlüsselt.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>Die eingegebenen Passphrasen stimmen nicht überein.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Wallet-Entsperrung fehlgeschlagen</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Die eingegebene Passphrase zur Wallet-Entschlüsselung war nicht korrekt.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Wallet-Entschlüsselung fehlgeschlagen</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Die Wallet-Passphrase wurde erfolgreich geändert.</translation>
    </message>
</context>
<context>
    <name>BeginnercoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>Nachricht s&amp;ignieren...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Synchronisiere mit Netzwerk...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Übersicht</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Knoten</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Allgemeine Wallet-Übersicht anzeigen</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transaktionen</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Transaktionsverlauf durchsehen</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Beenden</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Anwendung beenden</translation>
    </message>
    <message>
        <source>Show information about Beginnercoin</source>
        <translation>Informationen über Beginnercoin anzeigen</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Über &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Informationen über Qt anzeigen</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Konfiguration...</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>Wallet &amp;verschlüsseln...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>Wallet &amp;sichern...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>Passphrase &amp;ändern...</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>&amp;Zahlungsadressen...</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>&amp;Empfangsadressen...</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>&amp;URI öffnen...</translation>
    </message>
    <message>
        <source>Importing blocks from disk...</source>
        <translation>Importiere Blöcke von Datenträger...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>Reindiziere Blöcke auf Datenträger...</translation>
    </message>
    <message>
        <source>Send coins to a Beginnercoin address</source>
        <translation>Beginnercoins an eine Beginnercoin-Adresse überweisen</translation>
    </message>
    <message>
        <source>Modify configuration options for Beginnercoin</source>
        <translation>Die Konfiguration des Clients bearbeiten</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Eine Wallet-Sicherungskopie erstellen und abspeichern</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Ändert die Passphrase, die für die Wallet-Verschlüsselung benutzt wird</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>&amp;Debugfenster</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Debugging- und Diagnosekonsole öffnen</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>Nachricht &amp;verifizieren...</translation>
    </message>
    <message>
        <source>Beginnercoin</source>
        <translation>Beginnercoin</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Wallet</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Überweisen</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>&amp;Empfangen</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Anzeigen / Verstecken</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Das Hauptfenster anzeigen oder verstecken</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Verschlüsselt die zu ihrer Wallet gehörenden privaten Schlüssel</translation>
    </message>
    <message>
        <source>Sign messages with your Beginnercoin addresses to prove you own them</source>
        <translation>Nachrichten signieren, um den Besitz ihrer Beginnercoin-Adressen zu beweisen</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Beginnercoin addresses</source>
        <translation>Nachrichten verifizieren, um sicherzustellen, dass diese mit den angegebenen Beginnercoin-Adressen signiert wurden</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Datei</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Einstellungen</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Hilfe</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Registerkartenleiste</translation>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[Testnetz]</translation>
    </message>
    <message>
        <source>Beginnercoin Core</source>
        <translation>Beginnercoin Core</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and beginnercoin: URIs)</source>
        <translation>Zahlungen anfordern (erzeugt QR-Codes und &quot;beginnercoin:&quot;-URIs)</translation>
    </message>
    <message>
        <source>&amp;About Beginnercoin Core</source>
        <translation>&amp;Über Beginnercoin Core</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>Liste verwendeter Zahlungsadressen und Bezeichnungen anzeigen</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>Liste verwendeter Empfangsadressen und Bezeichnungen anzeigen</translation>
    </message>
    <message>
        <source>Open a beginnercoin: URI or payment request</source>
        <translation>Eine &quot;beginnercoin:&quot;-URI oder Zahlungsanforderung öffnen</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>&amp;Kommandozeilenoptionen</translation>
    </message>
    <message>
        <source>Show the Beginnercoin Core help message to get a list with possible Beginnercoin command-line options</source>
        <translation>Zeige den &quot;Beginnercoin Core&quot;-Hilfetext, um eine Liste mit möglichen Kommandozeilenoptionen zu erhalten</translation>
    </message>
    <message>
        <source>Beginnercoin client</source>
        <translation>Beginnercoin-Client</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Beginnercoin network</source>
        <translation><numerusform>%n aktive Verbindung zum Beginnercoin-Netzwerk</numerusform><numerusform>%n aktive Verbindungen zum Beginnercoin-Netzwerk</numerusform></translation>
    </message>
    <message>
        <source>No block source available...</source>
        <translation>Keine Blockquelle verfügbar...</translation>
    </message>
    <message>
        <source>Processed %1 of %2 (estimated) blocks of transaction history.</source>
        <translation>%1 von (geschätzten) %2 Blöcken des Transaktionsverlaufs verarbeitet.</translation>
    </message>
    <message>
        <source>Processed %1 blocks of transaction history.</source>
        <translation>%1 Blöcke des Transaktionsverlaufs verarbeitet.</translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation><numerusform>%n Stunde</numerusform><numerusform>%n Stunden</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation><numerusform>%n Tag</numerusform><numerusform>%n Tage</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation><numerusform>%n Woche</numerusform><numerusform>%n Wochen</numerusform></translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 und %2</translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation><numerusform>%n Jahr</numerusform><numerusform>%n Jahre</numerusform></translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>%1 im Rückstand</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>Der letzte empfangene Block ist %1 alt.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Transaktionen hiernach werden noch nicht angezeigt.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Warnung</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Hinweis</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Auf aktuellem Stand</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Hole auf...</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Gesendete Transaktion</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Eingehende Transaktion</translation>
    </message>
    <message>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Datum: %1
Betrag: %2
Typ: %3
Adresse: %4</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Wallet ist &lt;b&gt;verschlüsselt&lt;/b&gt; und aktuell &lt;b&gt;entsperrt&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Wallet ist &lt;b&gt;verschlüsselt&lt;/b&gt; und aktuell &lt;b&gt;gesperrt&lt;/b&gt;</translation>
    </message>
    <message>
        <source>A fatal error occurred. Beginnercoin can no longer continue safely and will quit.</source>
        <translation>Ein schwerer Fehler ist aufgetreten. Beginnercoin kann nicht stabil weiter ausgeführt werden und wird beendet.</translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <source>Network Alert</source>
        <translation>Netzwerkalarm</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Control Address Selection</source>
        <translation>&quot;Coin Control&quot;-Adressauswahl</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Anzahl:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Byte:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Betrag:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Priorität:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Gebühr:</translation>
    </message>
    <message>
        <source>Low Output:</source>
        <translation>Zu geringer Ausgabebetrag:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Abzüglich Gebühr:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Wechselgeld:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>Alles (de)selektieren</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>Baumansicht</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>Listenansicht</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Bestätigungen</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Bestätigt</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorität</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Adresse kopieren</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Bezeichnung kopieren</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Betrag kopieren</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Transaktions-ID kopieren</translation>
    </message>
    <message>
        <source>Lock unspent</source>
        <translation>Nicht ausgegebenen Betrag sperren</translation>
    </message>
    <message>
        <source>Unlock unspent</source>
        <translation>Nicht ausgegebenen Betrag entsperren</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Anzahl kopieren</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Gebühr kopieren</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Abzüglich Gebühr kopieren</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Byte kopieren</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>Priorität kopieren</translation>
    </message>
    <message>
        <source>Copy low output</source>
        <translation>Zu geringen Ausgabebetrag kopieren</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Wechselgeld kopieren</translation>
    </message>
    <message>
        <source>highest</source>
        <translation>am höchsten</translation>
    </message>
    <message>
        <source>higher</source>
        <translation>höher</translation>
    </message>
    <message>
        <source>high</source>
        <translation>hoch</translation>
    </message>
    <message>
        <source>medium-high</source>
        <translation>mittel-hoch</translation>
    </message>
    <message>
        <source>medium</source>
        <translation>mittel</translation>
    </message>
    <message>
        <source>low-medium</source>
        <translation>niedrig-mittel</translation>
    </message>
    <message>
        <source>low</source>
        <translation>niedrig</translation>
    </message>
    <message>
        <source>lower</source>
        <translation>niedriger</translation>
    </message>
    <message>
        <source>lowest</source>
        <translation>am niedrigsten</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation>(%1 gesperrt)</translation>
    </message>
    <message>
        <source>none</source>
        <translation>keine</translation>
    </message>
    <message>
        <source>Dust</source>
        <translation>&quot;Dust&quot;</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>ja</translation>
    </message>
    <message>
        <source>no</source>
        <translation>nein</translation>
    </message>
    <message>
        <source>This label turns red, if the transaction size is greater than 1000 bytes.</source>
        <translation>Diese Bezeichnung wird rot, wenn die Transaktion größer als 1000 Byte ist.</translation>
    </message>
    <message>
        <source>This means a fee of at least %1 per kB is required.</source>
        <translation>Das bedeutet, dass eine Gebühr von mindestens %1 pro kB erforderlich ist.</translation>
    </message>
    <message>
        <source>Can vary +/- 1 byte per input.</source>
        <translation>Kann um +/- 1 Byte pro Eingabe variieren.</translation>
    </message>
    <message>
        <source>Transactions with higher priority are more likely to get included into a block.</source>
        <translation>Transaktionen mit höherer Priorität haben eine größere Chance in einen Block aufgenommen zu werden.</translation>
    </message>
    <message>
        <source>This label turns red, if the priority is smaller than &quot;medium&quot;.</source>
        <translation>Diese Bezeichnung wird rot, wenn die Priorität niedriger als &quot;mittel&quot; ist.</translation>
    </message>
    <message>
        <source>This label turns red, if any recipient receives an amount smaller than %1.</source>
        <translation>Diese Bezeichnung wird rot, wenn irgendein Empfänger einen Betrag kleiner als %1 erhält.</translation>
    </message>
    <message>
        <source>This means a fee of at least %1 is required.</source>
        <translation>Das bedeutet, dass eine Gebühr von mindestens %1 erforderlich ist.</translation>
    </message>
    <message>
        <source>Amounts below 0.546 times the minimum relay fee are shown as dust.</source>
        <translation>Beträge kleiner als das 0,546-fache der niedrigsten Vermittlungsgebühr werden als &quot;Dust&quot; angezeigt.</translation>
    </message>
    <message>
        <source>This label turns red, if the change is smaller than %1.</source>
        <translation>Diese Bezeichnung wird rot, wenn das Wechselgeld weniger als %1 ist.</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(keine Bezeichnung)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation>Wechselgeld von %1 (%2)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation>(Wechselgeld)</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Adresse bearbeiten</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Bezeichnung</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>Bezeichnung, die dem Adresslisteneintrag zugeordnet ist.</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>Adresse, die dem Adresslisteneintrag zugeordnet ist. Diese kann nur bei Zahlungsadressen verändert werden.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Adresse</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Neue Empfangsadresse</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Neue Zahlungsadresse</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Empfangsadresse bearbeiten</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Zahlungsadresse bearbeiten</translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>Die eingegebene Adresse &quot;%1&quot; befindet sich bereits im Adressbuch.</translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is not a valid Beginnercoin address.</source>
        <translation>Die eingegebene Adresse &quot;%1&quot; ist keine gültige Beginnercoin-Adresse.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Wallet konnte nicht entsperrt werden.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Erzeugung eines neuen Schlüssels fehlgeschlagen.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>Es wird ein neues Datenverzeichnis angelegt.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>Verzeichnis existiert bereits. Fügen Sie %1 an, wenn Sie beabsichtigen hier ein neues Verzeichnis anzulegen.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>Pfad existiert bereits und ist kein Verzeichnis.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>Datenverzeichnis kann hier nicht angelegt werden.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>Beginnercoin Core - Command-line options</source>
        <translation>Beginnercoin Core - Kommandozeilenoptionen</translation>
    </message>
    <message>
        <source>Beginnercoin Core</source>
        <translation>Beginnercoin Core</translation>
    </message>
    <message>
        <source>version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Benutzung:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>Kommandozeilenoptionen</translation>
    </message>
    <message>
        <source>UI options</source>
        <translation>UI-Optionen</translation>
    </message>
    <message>
        <source>Set language, for example &quot;de_DE&quot; (default: system locale)</source>
        <translation>Sprache festlegen, z.B. &quot;de_DE&quot; (Standard: Systemstandard)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>Minimiert starten</translation>
    </message>
    <message>
        <source>Set SSL root certificates for payment request (default: -system-)</source>
        <translation>SSL-Wurzelzertifikate für Zahlungsanforderungen festlegen (Standard: Systemstandard)</translation>
    </message>
    <message>
        <source>Show splash screen on startup (default: 1)</source>
        <translation>Startbildschirm beim Starten anzeigen (Standard: 1)</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: 0)</source>
        <translation>Datenverzeichnis beim Starten auswählen (Standard: 0)</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Willkommen</translation>
    </message>
    <message>
        <source>Welcome to Beginnercoin Core.</source>
        <translation>Willkommen zu Beginnercoin Core.</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where Beginnercoin Core will store its data.</source>
        <translation>Da Sie das Programm gerade zum ersten Mal starten, können Sie nun auswählen wo Beginnercoin Core seine Daten ablegen soll.</translation>
    </message>
    <message>
        <source>Beginnercoin Core will download and store a copy of the Beginnercoin block chain. At least %1GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</source>
        <translation>Beginnercoin Core wird eine Kopie der Blockkette herunterladen und speichern. Mindestens %1GB Daten werden in diesem Verzeichnis abgelegt und die Datenmenge wächst über die Zeit an. Auch die Wallet wird in diesem Verzeichnis abgelegt.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>Standard-Datenverzeichnis verwenden</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>Ein benutzerdefiniertes Datenverzeichnis verwenden:</translation>
    </message>
    <message>
        <source>Beginnercoin</source>
        <translation>Beginnercoin</translation>
    </message>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; can not be created.</source>
        <translation>Fehler: Angegebenes Datenverzeichnis &quot;%1&quot; kann nicht angelegt werden.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <source>GB of free space available</source>
        <translation>GB freier Speicherplatz verfügbar</translation>
    </message>
    <message>
        <source>(of %1GB needed)</source>
        <translation>(von benötigten %1GB)</translation>
    </message>
</context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>URI öffnen</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>Zahlungsanforderung über URI oder aus Datei öffnen</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>Zahlungsanforderungsdatei auswählen</translation>
    </message>
    <message>
        <source>Select payment request file to open</source>
        <translation>Zu öffnende Zahlungsanforderungsdatei auswählen</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Konfiguration</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;Allgemein</translation>
    </message>
    <message>
        <source>Optional transaction fee per kB that helps make sure your transactions are processed quickly. Most transactions are 1 kB.</source>
        <translation>Optionale Transaktionsgebühr pro kB, die sicherstellt, dass ihre Transaktionen schnell bearbeitet werden. Die meisten Transaktionen sind 1 kB groß.</translation>
    </message>
    <message>
        <source>Pay transaction &amp;fee</source>
        <translation>Transaktions&amp;gebühr bezahlen</translation>
    </message>
    <message>
        <source>Automatically start Beginnercoin after logging in to the system.</source>
        <translation>Beginnercoin nach der Anmeldung am System automatisch ausführen.</translation>
    </message>
    <message>
        <source>&amp;Start Beginnercoin on system login</source>
        <translation>&amp;Starte Beginnercoin nach Systemanmeldung</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>Größe des &amp;Datenbankcaches</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation>Anzahl an Skript-&amp;Verifizierungs-Threads</translation>
    </message>
    <message>
        <source>Connect to the Beginnercoin network through a SOCKS proxy.</source>
        <translation>Über einen SOCKS-Proxy mit dem Beginnercoin-Netzwerk verbinden.</translation>
    </message>
    <message>
        <source>&amp;Connect through SOCKS proxy (default proxy):</source>
        <translation>Über einen SOCKS-Proxy &amp;verbinden (Standardproxy):</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>IP-Adresse des Proxies (z.B. IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Third party URLs (e.g. a block explorer) that appear in the transactions tab as context menu items. %s in the URL is replaced by transaction hash. Multiple URLs are separated by vertical bar |.</source>
        <translation>Externe URLs (z.B. ein Block-Explorer), die im Kontextmenü des Transaktionsverlaufs eingefügt werden. In der URL wird %s durch den Transaktionshash ersetzt. Bei Angabe mehrerer URLs müssen diese durch &quot;|&quot; voneinander getrennt werden.</translation>
    </message>
    <message>
        <source>Third party transaction URLs</source>
        <translation>Externe Transaktions-URLs</translation>
    </message>
    <message>
        <source>Active command-line options that override above options:</source>
        <translation>Aktive Kommandozeilenoptionen, die obige Konfiguration überschreiben:</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>Setzt die Clientkonfiguration auf Standardwerte zurück.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>Konfiguration &amp;zurücksetzen</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Netzwerk</translation>
    </message>
    <message>
        <source>(0 = auto, &lt;0 = leave that many cores free)</source>
        <translation>(0 = automatisch, &lt;0 = so viele Kerne frei lassen)</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>W&amp;allet</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>Erweiterte Wallet-Optionen</translation>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation>&quot;&amp;Coin Control&quot;-Funktionen aktivieren</translation>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction cannot be used until that transaction has at least one confirmation. This also affects how your balance is computed.</source>
        <translation>Wenn Sie das Ausgeben von unbestätigtem Wechselgeld deaktivieren, kann das Wechselgeld einer Transaktion nicht verwendet werden, bis es mindestens eine Bestätigung erhalten hat. Dies wirkt sich auf die Berechnung des Kontostands aus.</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation>&amp;Unbestätigtes Wechselgeld darf ausgegeben werden</translation>
    </message>
    <message>
        <source>Automatically open the Beginnercoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Automatisch den Beginnercoin-Clientport auf dem Router öffnen. Dies funktioniert nur, wenn ihr Router UPnP unterstützt und dies aktiviert ist.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Portweiterleitung via &amp;UPnP</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>Proxy-&amp;IP:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Port des Proxies (z.B. 9050)</translation>
    </message>
    <message>
        <source>SOCKS &amp;Version:</source>
        <translation>SOCKS-&amp;Version:</translation>
    </message>
    <message>
        <source>SOCKS version of the proxy (e.g. 5)</source>
        <translation>SOCKS-Version des Proxies (z.B. 5)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Programmfenster</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Nur ein Symbol im Infobereich anzeigen, nachdem das Programmfenster minimiert wurde.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>In den Infobereich anstatt in die Taskleiste &amp;minimieren</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>Minimiert die Anwendung anstatt sie zu beenden wenn das Fenster geschlossen wird. Wenn dies aktiviert ist, müssen Sie das Programm über &quot;Beenden&quot; im Menü schließen.</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>Beim Schließen m&amp;inimieren</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>Anzei&amp;ge</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>&amp;Sprache der Benutzeroberfläche:</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting Beginnercoin.</source>
        <translation>Legt die Sprache der Benutzeroberfläche fest. Diese Einstellung wird erst nach einem Neustart von Beginnercoin aktiv.</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp;Einheit der Beträge:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Wählen Sie die standardmäßige Untereinheit, die in der Benutzeroberfläche und beim Überweisen von Beginnercoins angezeigt werden soll.</translation>
    </message>
    <message>
        <source>Whether to show Beginnercoin addresses in the transaction list or not.</source>
        <translation>Legt fest, ob Beginnercoin-Adressen im Transaktionsverlauf angezeigt werden.</translation>
    </message>
    <message>
        <source>&amp;Display addresses in transaction list</source>
        <translation>Adressen im Transaktionsverlauf &amp;anzeigen</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>Legt fest, ob die &quot;Coin Control&quot;-Funktionen angezeigt werden.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>A&amp;bbrechen</translation>
    </message>
    <message>
        <source>default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>none</source>
        <translation>keine</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>Zurücksetzen der Konfiguration bestätigen</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>Clientneustart nötig, um die Änderungen zu aktivieren.</translation>
    </message>
    <message>
        <source>Client will be shutdown, do you want to proceed?</source>
        <translation>Client wird beendet, wollen Sie fortfahren?</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>Diese Änderung würde einen Clientneustart benötigen.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>Die eingegebene Proxyadresse ist ungültig.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Beginnercoin network after a connection is established, but this process has not completed yet.</source>
        <translation>Die angezeigten Informationen sind möglicherweise nicht mehr aktuell. Ihre Wallet wird automatisch synchronisiert, nachdem eine Verbindung zum Beginnercoin-Netzwerk hergestellt wurde. Dieser Prozess ist jedoch derzeit noch nicht abgeschlossen.</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Wallet</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>Verfügbar:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>Ihr aktuell verfügbarer Kontostand</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>Ausstehend:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>Betrag aus unbestätigten Transaktionen, der noch nicht im aktuell verfügbaren Kontostand enthalten ist</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Unreif:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>Erarbeiteter Betrag der noch nicht gereift ist</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Gesamtbetrag:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>Aktueller Gesamtbetrag aus obigen Kategorien</translation>
    </message>
    <message>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;Letzte Transaktionen&lt;/b&gt;</translation>
    </message>
    <message>
        <source>out of sync</source>
        <translation>nicht synchron</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>URI handling</source>
        <translation>URI-Verarbeitung</translation>
    </message>
    <message>
        <source>URI can not be parsed! This can be caused by an invalid Beginnercoin address or malformed URI parameters.</source>
        <translation>URI kann nicht analysiert werden! Dies kann durch eine ungültige Beginnercoin-Adresse oder fehlerhafte URI-Parameter verursacht werden.</translation>
    </message>
    <message>
        <source>Requested payment amount of %1 is too small (considered dust).</source>
        <translation>Angeforderter Zahlungsbetrag in Höhe von %1 ist zu niedrig und wurde als &quot;Dust&quot; eingestuft.</translation>
    </message>
    <message>
        <source>Payment request error</source>
        <translation>fehlerhafte Zahlungsanforderung</translation>
    </message>
    <message>
        <source>Cannot start beginnercoin: click-to-pay handler</source>
        <translation>&quot;beginnercoin: Klicken-zum-Bezahlen&quot;-Handler konnte nicht gestartet werden</translation>
    </message>
    <message>
        <source>Net manager warning</source>
        <translation>Netzwerkmanager-Warnung</translation>
    </message>
    <message>
        <source>Your active proxy doesn&apos;t support SOCKS5, which is required for payment requests via proxy.</source>
        <translation>Ihr aktiver Proxy unterstützt kein SOCKS5, dies wird jedoch für Zahlungsanforderungen über einen Proxy benötigt.</translation>
    </message>
    <message>
        <source>Payment request fetch URL is invalid: %1</source>
        <translation>Abruf-URL der Zahlungsanforderung ist ungültig: %1</translation>
    </message>
    <message>
        <source>Payment request file handling</source>
        <translation>Zahlungsanforderungsdatei-Verarbeitung</translation>
    </message>
    <message>
        <source>Payment request file can not be read or processed! This can be caused by an invalid payment request file.</source>
        <translation>Zahlungsanforderungsdatei kann nicht gelesen oder verarbeitet werden! Dies kann durch eine ungültige Zahlungsanforderungsdatei verursacht werden.</translation>
    </message>
    <message>
        <source>Unverified payment requests to custom payment scripts are unsupported.</source>
        <translation>Unverifizierte Zahlungsanforderungen an benutzerdefinierte Zahlungsskripte werden nicht unterstützt.</translation>
    </message>
    <message>
        <source>Refund from %1</source>
        <translation>Rücküberweisung von %1</translation>
    </message>
    <message>
        <source>Error communicating with %1: %2</source>
        <translation>Kommunikationsfehler mit %1: %2</translation>
    </message>
    <message>
        <source>Payment request can not be parsed or processed!</source>
        <translation>Zahlungsanforderung kann nicht analysiert oder verarbeitet werden!</translation>
    </message>
    <message>
        <source>Bad response from server %1</source>
        <translation>Fehlerhafte Antwort vom Server: %1</translation>
    </message>
    <message>
        <source>Payment acknowledged</source>
        <translation>Zahlung bestätigt</translation>
    </message>
    <message>
        <source>Network request error</source>
        <translation>fehlerhafte Netzwerkanfrage</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Beginnercoin</source>
        <translation>Beginnercoin</translation>
    </message>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; does not exist.</source>
        <translation>Fehler: Angegebenes Datenverzeichnis &quot;%1&quot; existiert nicht.</translation>
    </message>
    <message>
        <source>Error: Cannot parse configuration file: %1. Only use key=value syntax.</source>
        <translation>Fehler: Konfigurationsdatei kann nicht analysiert werden: %1. Bitte nur &quot;Schlüssel=Wert&quot;-Syntax verwenden.</translation>
    </message>
    <message>
        <source>Error: Invalid combination of -regtest and -testnet.</source>
        <translation>Fehler: Ungültige Kombination von -regtest und -testnet.</translation>
    </message>
    <message>
        <source>Beginnercoin Core didn&apos;t yet exit safely...</source>
        <translation>Beginnercoin Core wurde noch nicht sicher beendet...</translation>
    </message>
    <message>
        <source>Enter a Beginnercoin address (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Beginnercoin-Adresse eingeben (z.B. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>Grafik &amp;speichern...</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation>Grafik &amp;kopieren</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation>QR-Code speichern</translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation>PNG-Grafik (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Client name</source>
        <translation>Clientname</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>k.A.</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Clientversion</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Information</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>Debugfenster</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <source>Using OpenSSL version</source>
        <translation>Verwendete OpenSSL-Version</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Startzeit</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Netzwerk</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Anzahl Verbindungen</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Blockkette</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Aktuelle Anzahl Blöcke</translation>
    </message>
    <message>
        <source>Estimated total blocks</source>
        <translation>Geschätzte Gesamtzahl Blöcke</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Letzte Blockzeit</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Öffnen</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Konsole</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>&amp;Netzwerkauslastung</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Zurücksetzen</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Summen</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>eingehend:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>ausgehend:</translation>
    </message>
    <message>
        <source>Build date</source>
        <translation>Erstellungsdatum</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>Debugprotokolldatei</translation>
    </message>
    <message>
        <source>Open the Beginnercoin debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Öffnet die Beginnercoin-Debugprotokolldatei aus dem aktuellen Datenverzeichnis. Dies kann bei großen Protokolldateien einige Sekunden dauern.</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Konsole zurücksetzen</translation>
    </message>
    <message>
        <source>Welcome to the Beginnercoin RPC console.</source>
        <translation>Willkommen in der Beginnercoin-RPC-Konsole.</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Pfeiltaste hoch und runter, um den Verlauf durchzublättern und &lt;b&gt;Strg-L&lt;/b&gt;, um die Konsole zurückzusetzen.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Bitte &lt;b&gt;help&lt;/b&gt; eingeben, um eine Übersicht verfügbarer Befehle zu erhalten.</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 m</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 h</translation>
    </message>
    <message>
        <source>%1 h %2 m</source>
        <translation>%1 h %2 m</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>&amp;Betrag:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Bezeichnung:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;Nachricht:</translation>
    </message>
    <message>
        <source>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</source>
        <translation>Eine der bereits verwendeten Empfangsadressen wiederverwenden. Addressen wiederzuverwenden birgt Sicherheits- und Datenschutzrisiken. Außer zum Neuerstellen einer bereits erzeugten Zahlungsanforderung sollten Sie dies nicht nutzen.</translation>
    </message>
    <message>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation>Vorhandene Empfangsadresse &amp;wiederverwenden (nicht empfohlen)</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Beginnercoin network.</source>
        <translation>Eine optionale Nachricht, die an die Zahlungsanforderung angehängt wird. Sie wird angezeigt, wenn die Anforderung geöffnet wird. Hinweis: Diese Nachricht wird nicht mit der Zahlung über das Beginnercoin-Netzwerk gesendet.</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation>Eine optionale Bezeichnung, die der neuen Empfangsadresse zugeordnet wird.</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>Verwenden Sie dieses Formular, um Zahlungen anzufordern. Alle Felder sind &lt;b&gt;optional&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation>Ein optional angeforderte Betrag. Lassen Sie dieses Feld leer oder setzen Sie es auf 0, um keinen spezifischen Betrag anzufordern.</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Alle Formularfelder zurücksetzen.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Zurücksetzen</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>Verlauf der angeforderten Zahlungen</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>&amp;Zahlung anfordern</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation>Ausgewählte Zahlungsanforderungen anzeigen (entspricht einem Doppelklick auf einen Eintrag)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Anzeigen</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation>Ausgewählte Einträge aus der Liste entfernen</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Bezeichnung kopieren</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>Nachricht kopieren</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Betrag kopieren</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR-Code</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>&amp;URI kopieren</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>&amp;Addresse kopieren</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>Grafik &amp;speichern...</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation>Zahlung anfordern an %1</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>Zahlungsinformationen</translation>
    </message>
    <message>
        <source>URI</source>
        <translation>URI</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>Resultierende URI ist zu lang, bitte den Text für Bezeichnung/Nachricht kürzen.</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation>Beim Enkodieren der URI in den QR-Code ist ein Fehler aufgetreten.</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(keine Bezeichnung)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>(keine Nachricht)</translation>
    </message>
    <message>
        <source>(no amount)</source>
        <translation>(kein Betrag)</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Beginnercoins überweisen</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>&quot;Coin Control&quot;-Funktionen</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>Eingaben...</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>automatisch ausgewählt</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Unzureichender Kontostand!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Anzahl:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Byte:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Betrag:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Priorität:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Gebühr:</translation>
    </message>
    <message>
        <source>Low Output:</source>
        <translation>Zu geringer Ausgabebetrag:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Abzüglich Gebühr:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Wechselgeld:</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation>Wenn dies aktivert, und die Wechselgeld-Adresse leer oder ungültig ist, wird das Wechselgeld einer neu erzeugten Adresse gutgeschrieben.</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation>Benutzerdefinierte Wechselgeld-Adresse</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>An mehrere Empfänger auf einmal überweisen</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>Empfänger &amp;hinzufügen</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Alle Formularfelder zurücksetzen.</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>&amp;Zurücksetzen</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Kontostand:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Überweisung bestätigen</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>&amp;Überweisen</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Überweisung bestätigen</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation>%1 an %2</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Anzahl kopieren</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Betrag kopieren</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Gebühr kopieren</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Abzüglich Gebühr kopieren</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Byte kopieren</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>Priorität kopieren</translation>
    </message>
    <message>
        <source>Copy low output</source>
        <translation>Zu geringen Ausgabebetrag kopieren</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Wechselgeld kopieren</translation>
    </message>
    <message>
        <source>Total Amount %1 (= %2)</source>
        <translation>Gesamtbetrag %1 (= %2)</translation>
    </message>
    <message>
        <source>or</source>
        <translation>oder</translation>
    </message>
    <message>
        <source>The recipient address is not valid, please recheck.</source>
        <translation>Die Zahlungsadresse ist ungültig, bitte nochmals überprüfen.</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Der zu zahlende Betrag muss größer als 0 sein.</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>Der angegebene Betrag übersteigt ihren Kontostand.</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>Der angegebene Betrag übersteigt aufgrund der Transaktionsgebühr in Höhe von %1 ihren Kontostand.</translation>
    </message>
    <message>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation>Doppelte Zahlungsadresse gefunden, pro Überweisung kann an jede Adresse nur einmalig etwas überwiesen werden.</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation>Transaktionserstellung fehlgeschlagen!</translation>
    </message>
    <message>
        <source>The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Die Transaktion wurde abgelehnt! Dies kann passieren, wenn einige Beginnercoins aus ihrer Wallet bereits ausgegeben wurden. Beispielsweise weil Sie eine Kopie ihrer wallet.dat genutzt, die Beginnercoins dort ausgegeben haben und dies daher in der derzeit aktiven Wallet nicht vermerkt ist.</translation>
    </message>
    <message>
        <source>Warning: Invalid Beginnercoin address</source>
        <translation>Warnung: Ungültige Beginnercoin-Adresse</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(keine Bezeichnung)</translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation>Warnung: Unbekannte Wechselgeld-Adresse</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>Wollen Sie die Überweisung ausführen?</translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation>als Transaktionsgebühr hinzugefügt</translation>
    </message>
    <message>
        <source>Payment request expired</source>
        <translation>Zahlungsanforderung abgelaufen</translation>
    </message>
    <message>
        <source>Invalid payment address %1</source>
        <translation>Ungültige Zahlungsadresse %1</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>Betra&amp;g:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>E&amp;mpfänger:</translation>
    </message>
    <message>
        <source>The address to send the payment to (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Die Zahlungsadresse der Überweisung (z.B. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Adressbezeichnung eingeben (diese wird zusammen mit der Adresse dem Adressbuch hinzugefügt)</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Bezeichnung:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Bereits verwendete Adresse auswählen</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>Dies ist eine normale Überweisung.</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Adresse aus der Zwischenablage einfügen</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>Diesen Eintrag entfernen</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Nachricht:</translation>
    </message>
    <message>
        <source>This is a verified payment request.</source>
        <translation>Dies is eine verifizierte Zahlungsanforderung.</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation>Adressbezeichnung eingeben, die dann zusammen mit der Adresse der Liste bereits verwendeter Adressen hinzugefügt wird.</translation>
    </message>
    <message>
        <source>A message that was attached to the beginnercoin: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Beginnercoin network.</source>
        <translation>Eine an die &quot;beginnercoin:&quot;-URI angefügte Nachricht, die zusammen mit der Transaktion gespeichert wird. Hinweis: Diese Nachricht wird nicht über das Beginnercoin-Netzwerk gesendet.</translation>
    </message>
    <message>
        <source>This is an unverified payment request.</source>
        <translation>Dies is eine unverifizierte Zahlungsanforderung.</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Empfänger:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>Memo:</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>Beginnercoin Core is shutting down...</source>
        <translation>Beginnercoin Core wird beendet...</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>Fahren Sie den Computer nicht herunter, bevor dieses Fenster verschwindet.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Signaturen - eine Nachricht signieren / verifizieren</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>Nachricht &amp;signieren</translation>
    </message>
    <message>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Sie können Nachrichten mit ihren Adressen signieren, um den Besitz dieser Adressen zu beweisen. Bitte nutzen Sie diese Funktion mit Vorsicht und nehmen Sie sich vor Phishingangriffen in Acht. Signieren Sie nur Nachrichten, mit denen Sie vollständig einverstanden sind.</translation>
    </message>
    <message>
        <source>The address to sign the message with (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Die Adresse mit der die Nachricht signiert wird (z.B. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Bereits verwendete Adresse auswählen</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Adresse aus der Zwischenablage einfügen</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Zu signierende Nachricht hier eingeben</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Signatur</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Aktuelle Signatur in die Zwischenablage kopieren</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Beginnercoin address</source>
        <translation>Die Nachricht signieren, um den Besitz dieser Beginnercoin-Adresse zu beweisen</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>&amp;Nachricht signieren</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Alle &quot;Nachricht signieren&quot;-Felder zurücksetzen</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>&amp;Zurücksetzen</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>Nachricht &amp;verifizieren</translation>
    </message>
    <message>
        <source>Enter the signing address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack.</source>
        <translation>Geben Sie die signierende Adresse, Nachricht (achten Sie darauf Zeilenumbrüche, Leerzeichen, Tabulatoren usw. exakt zu kopieren) und Signatur unten ein, um die Nachricht zu verifizieren. Vorsicht, interpretieren Sie nicht mehr in die Signatur hinein, als in der signierten Nachricht selber enthalten ist, um nicht von einem Man-in-the-middle-Angriff hinters Licht geführt zu werden.</translation>
    </message>
    <message>
        <source>The address the message was signed with (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Die Adresse mit der die Nachricht signiert wurde (z.B. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Beginnercoin address</source>
        <translation>Die Nachricht verifizieren, um sicherzustellen, dass diese mit der angegebenen Beginnercoin-Adresse signiert wurde</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>&amp;Nachricht verifizieren</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Alle &quot;Nachricht verifizieren&quot;-Felder zurücksetzen</translation>
    </message>
    <message>
        <source>Enter a Beginnercoin address (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Beginnercoin-Adresse eingeben (z.B. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <source>Click &quot;Sign Message&quot; to generate signature</source>
        <translation>Auf &quot;Nachricht signieren&quot; klicken, um die Signatur zu erzeugen</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>Die eingegebene Adresse ist ungültig.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>Bitte überprüfen Sie die Adresse und versuchen Sie es erneut.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>Die eingegebene Adresse verweist nicht auf einen Schlüssel.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>Wallet-Entsperrung wurde abgebrochen.</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>Privater Schlüssel zur eingegebenen Adresse ist nicht verfügbar.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation>Signierung der Nachricht fehlgeschlagen.</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>Nachricht signiert.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>Die Signatur konnte nicht dekodiert werden.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>Bitte überprüfen Sie die Signatur und versuchen Sie es erneut.</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation>Die Signatur entspricht nicht dem &quot;Message Digest&quot;.</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation>Verifikation der Nachricht fehlgeschlagen.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>Nachricht verifiziert.</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>Beginnercoin Core</source>
        <translation>Beginnercoin Core</translation>
    </message>
    <message>
        <source>The Beginnercoin Core developers</source>
        <translation>Die &quot;Beginnercoin Core&quot;-Entwickler</translation>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[Testnetz]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>Offen bis %1</translation>
    </message>
    <message>
        <source>conflicted</source>
        <translation>in Konflikt stehend</translation>
    </message>
    <message>
        <source>%1/offline</source>
        <translation>%1/offline</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/unbestätigt</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 Bestätigungen</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message numerus="yes">
        <source>, broadcast through %n node(s)</source>
        <translation><numerusform>, über %n Knoten übertragen</numerusform><numerusform>, über %n Knoten übertragen</numerusform></translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Quelle</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>Erzeugt</translation>
    </message>
    <message>
        <source>From</source>
        <translation>Von</translation>
    </message>
    <message>
        <source>To</source>
        <translation>An</translation>
    </message>
    <message>
        <source>own address</source>
        <translation>eigene Adresse</translation>
    </message>
    <message>
        <source>label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation>Gutschrift</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation><numerusform>reift noch %n weiteren Block</numerusform><numerusform>reift noch %n weitere Blöcke</numerusform></translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation>nicht angenommen</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>Belastung</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>Transaktionsgebühr</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation>Nettobetrag</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation>Transaktions-ID</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation>Händler</translation>
    </message>
    <message>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to &quot;not accepted&quot; and it won&apos;t be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>Erzeugte Beginnercoins müssen %1 Blöcke lang reifen, bevor sie ausgegeben werden können. Als Sie diesen Block erzeugten, wurde er an das Netzwerk übertragen, um ihn der Blockkette hinzuzufügen. Falls dies fehlschlägt wird der Status in &quot;nicht angenommen&quot; geändert und Sie werden keine Beginnercoins gutgeschrieben bekommen. Das kann gelegentlich passieren, wenn ein anderer Knoten einen Block fast zeitgleich erzeugt.</translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation>Debuginformationen</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation>Transaktion</translation>
    </message>
    <message>
        <source>Inputs</source>
        <translation>Eingaben</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>true</source>
        <translation>wahr</translation>
    </message>
    <message>
        <source>false</source>
        <translation>falsch</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>, wurde noch nicht erfolgreich übertragen</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation><numerusform>Offen für %n weiteren Block</numerusform><numerusform>Offen für %n weitere Blöcke</numerusform></translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>unbekannt</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>Transaktionsdetails</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Dieser Bereich zeigt eine detaillierte Beschreibung der Transaktion an</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>Immature (%1 confirmations, will be available after %2)</source>
        <translation>Unreif (%1 Bestätigungen, wird verfügbar sein nach %2)</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation><numerusform>Offen für %n weiteren Block</numerusform><numerusform>Offen für %n weitere Blöcke</numerusform></translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Offen bis %1</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Bestätigt (%1 Bestätigungen)</translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Dieser Block wurde von keinem anderen Knoten empfangen und wird wahrscheinlich nicht angenommen werden!</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Erzeugt, jedoch nicht angenommen</translation>
    </message>
    <message>
        <source>Offline</source>
        <translation>Offline</translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation>Unbestätigt</translation>
    </message>
    <message>
        <source>Confirming (%1 of %2 recommended confirmations)</source>
        <translation>Wird bestätigt (%1 von %2 empfohlenen Bestätigungen)</translation>
    </message>
    <message>
        <source>Conflicted</source>
        <translation>in Konflikt stehend</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Empfangen über</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Empfangen von</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Überwiesen an</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Eigenüberweisung</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Erarbeitet</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(k.A.)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Transaktionsstatus, fahren Sie mit der Maus über dieses Feld, um die Anzahl der Bestätigungen zu sehen.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Datum und Uhrzeit zu der die Transaktion empfangen wurde.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Art der Transaktion</translation>
    </message>
    <message>
        <source>Destination address of transaction.</source>
        <translation>Zieladresse der Transaktion</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Der Betrag, der dem Kontostand abgezogen oder hinzugefügt wurde.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Heute</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>Diese Woche</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>Diesen Monat</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Letzten Monat</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>Dieses Jahr</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Zeitraum...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Empfangen über</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Überwiesen an</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>Eigenüberweisung</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Erarbeitet</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Andere</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Zu suchende Adresse oder Bezeichnung eingeben</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Minimaler Betrag</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Adresse kopieren</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Bezeichnung kopieren</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Betrag kopieren</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Transaktions-ID kopieren</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Bezeichnung bearbeiten</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>Transaktionsdetails anzeigen</translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation>Transaktionsverlauf exportieren</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Exportieren fehlgeschlagen</translation>
    </message>
    <message>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation>Beim Speichern des Transaktionsverlaufs nach %1 ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation>Exportieren erfolgreich</translation>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation>Speichern des Transaktionsverlaufs nach %1 war erfolgreich.</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Kommagetrennte-Datei (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Bestätigt</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Zeitraum:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>bis</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.</source>
        <translation>Es wurde keine Wallet geladen.</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>Beginnercoins überweisen</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>E&amp;xportieren</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Daten der aktuellen Ansicht in eine Datei exportieren</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>Wallet sichern</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>Wallet-Daten (*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>Sicherung fehlgeschlagen</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation>Beim Speichern der Wallet-Daten nach %1 ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation>Speichern der Wallet-Daten nach %1 war erfolgreich.</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation>Sicherung erfolgreich</translation>
    </message>
</context>
<context>
    <name>beginnercoin-core</name>
    <message>
        <source>Usage:</source>
        <translation>Benutzung:</translation>
    </message>
    <message>
        <source>List commands</source>
        <translation>Befehle auflisten</translation>
    </message>
    <message>
        <source>Get help for a command</source>
        <translation>Hilfe zu einem Befehl erhalten</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Optionen:</translation>
    </message>
    <message>
        <source>Specify configuration file (default: beginnercoin.conf)</source>
        <translation>Konfigurationsdatei festlegen (Standard: beginnercoin.conf)</translation>
    </message>
    <message>
        <source>Specify pid file (default: beginnercoind.pid)</source>
        <translation>PID-Datei festlegen (Standard: beginnercoind.pid)</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Datenverzeichnis festlegen</translation>
    </message>
    <message>
        <source>Listen for connections on &lt;port&gt; (default: 9844 or testnet: 19844)</source>
        <translation>&lt;port&gt; nach Verbindungen abhören (Standard: 9844 oder Testnetz: 19844)</translation>
    </message>
    <message>
        <source>Maintain at most &lt;n&gt; connections to peers (default: 125)</source>
        <translation>Maximal &lt;n&gt; Verbindungen zu Gegenstellen aufrechterhalten (Standard: 125)</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Mit dem angegebenen Knoten verbinden, um Adressen von Gegenstellen abzufragen, danach trennen</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>Die eigene öffentliche Adresse angeben</translation>
    </message>
    <message>
        <source>Threshold for disconnecting misbehaving peers (default: 100)</source>
        <translation>Schwellenwert, um Verbindungen zu sich nicht konform verhaltenden Gegenstellen zu beenden (Standard: 100)</translation>
    </message>
    <message>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: 86400)</source>
        <translation>Anzahl Sekunden, während denen sich nicht konform verhaltenden Gegenstellen die Wiederverbindung verweigert wird (Standard: 86400)</translation>
    </message>
    <message>
        <source>An error occurred while setting up the RPC port %u for listening on IPv4: %s</source>
        <translation>Beim Einrichten des RPC-Ports %u zum Abhören von IPv4 ist ein Fehler aufgetreten: %s</translation>
    </message>
    <message>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: 9744 or testnet: 19744)</source>
        <translation>&lt;port&gt; nach JSON-RPC-Verbindungen abhören (Standard: 9744 oder Testnetz: 19744)</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Kommandozeilen- und JSON-RPC-Befehle annehmen</translation>
    </message>
    <message>
        <source>Beginnercoin Core RPC client version</source>
        <translation>&quot;Beginnercoin Core&quot;-RPC-Client-Version</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Als Hintergrunddienst ausführen und Befehle annehmen</translation>
    </message>
    <message>
        <source>Use the test network</source>
        <translation>Das Testnetz verwenden</translation>
    </message>
    <message>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation>Eingehende Verbindungen annehmen (Standard: 1, wenn nicht -proxy oder -connect)</translation>
    </message>
    <message>
        <source>%s, you must set a rpcpassword in the configuration file:
%s
It is recommended you use the following random password:
rpcuser=beginnercoinrpc
rpcpassword=%s
(you do not need to remember this password)
The username and password MUST NOT be the same.
If the file does not exist, create it with owner-readable-only file permissions.
It is also recommended to set alertnotify so you are notified of problems;
for example: alertnotify=echo %%s | mail -s &quot;Beginnercoin Alert&quot; admin@foo.com
</source>
        <translation>%s, Sie müssen den Wert rpcpasswort in dieser Konfigurationsdatei angeben:
%s
Es wird empfohlen das folgende Zufallspasswort zu verwenden:
rpcuser=beginnercoinrpc
rpcpassword=%s
(Sie müssen sich dieses Passwort nicht merken!)
Der Benutzername und das Passwort dürfen NICHT identisch sein.
Falls die Konfigurationsdatei nicht existiert, erzeugen Sie diese bitte mit Leserechten nur für den Dateibesitzer.
Es wird ebenfalls empfohlen alertnotify anzugeben, um im Problemfall benachrichtig zu werden;
zum Beispiel: alertnotify=echo %%s | mail -s \&quot;Beginnercoin Alert\&quot; admin@foo.com
</translation>
    </message>
    <message>
        <source>Acceptable ciphers (default: TLSv1.2+HIGH:TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!3DES:@STRENGTH)</source>
        <translation>Zulässige Chiffren (Standard: TLSv1.2+HIGH:TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!3DES:@STRENGTH)</translation>
    </message>
    <message>
        <source>An error occurred while setting up the RPC port %u for listening on IPv6, falling back to IPv4: %s</source>
        <translation>Beim Einrichten des RPC-Ports %u zum Abhören von IPv6 ist ein Fehler aufgetreten, es wird auf IPv4 zurückgegriffen: %s</translation>
    </message>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>An die angegebene Adresse binden und immer abhören. Für IPv6 &quot;[Host]:Port&quot;-Schreibweise verwenden</translation>
    </message>
    <message>
        <source>Continuously rate-limit free transactions to &lt;n&gt;*1000 bytes per minute (default:15)</source>
        <translation>Anzahl der freien Transaktionen auf &lt;n&gt; * 1000 Byte pro Minute begrenzen (Standard: 15)</translation>
    </message>
    <message>
        <source>Enter regression test mode, which uses a special chain in which blocks can be solved instantly. This is intended for regression testing tools and app development.</source>
        <translation>Regressionstest-Modus aktivieren, der eine spezielle Blockkette nutzt, in der Blöcke sofort gelöst werden können. Dies ist für Regressionstest-Tools und Anwendungsentwicklung gedacht.</translation>
    </message>
    <message>
        <source>Enter regression test mode, which uses a special chain in which blocks can be solved instantly.</source>
        <translation>Regressionstest-Modus aktivieren, der eine spezielle Blockkette nutzt, in der Blöcke sofort gelöst werden können.</translation>
    </message>
    <message>
        <source>Error: Listening for incoming connections failed (listen returned error %d)</source>
        <translation>Fehler: Abhören nach eingehenden Verbindungen fehlgeschlagen (Fehler %d)</translation>
    </message>
    <message>
        <source>Error: The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Fehler: Die Transaktion wurde abgelehnt! Dies kann passieren, wenn einige Beginnercoins aus ihrer Wallet bereits ausgegeben wurden. Beispielsweise weil Sie eine Kopie ihrer wallet.dat genutzt, die Beginnercoins dort ausgegeben haben und dies daher in der derzeit aktiven Wallet nicht vermerkt ist.</translation>
    </message>
    <message>
        <source>Error: This transaction requires a transaction fee of at least %s because of its amount, complexity, or use of recently received funds!</source>
        <translation>Fehler: Diese Transaktion benötigt aufgrund ihres Betrags, ihrer Komplexität oder der Nutzung erst kürzlich erhaltener Zahlungen eine Transaktionsgebühr in Höhe von mindestens %s!</translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation>Befehl ausführen wenn sich eine Wallet-Transaktion verändert (%s im Befehl wird durch die TxID ersetzt)</translation>
    </message>
    <message>
        <source>Fees smaller than this are considered zero fee (for transaction creation) (default:</source>
        <translation>Niedrigere Gebühren als diese werden als gebührenfrei angesehen (bei der Transaktionserstellung) (Standard:</translation>
    </message>
    <message>
        <source>Flush database activity from memory pool to disk log every &lt;n&gt; megabytes (default: 100)</source>
        <translation>Datenbankaktivitäten vom Arbeitsspeicher-Pool alle &lt;n&gt; Megabyte auf den Datenträger schreiben (Standard: 100)</translation>
    </message>
    <message>
        <source>How thorough the block verification of -checkblocks is (0-4, default: 3)</source>
        <translation>Legt fest, wie gründlich die Blockverifikation von -checkblocks ist (0-4, Standard: 3)</translation>
    </message>
    <message>
        <source>In this mode -genproclimit controls how many blocks are generated immediately.</source>
        <translation>In diesem Modus legt -genproclimit fest, wie viele Blöcke sofort erzeugt werden.</translation>
    </message>
    <message>
        <source>Set the number of script verification threads (%u to %d, 0 = auto, &lt;0 = leave that many cores free, default: %d)</source>
        <translation>Maximale Anzahl an Skript-Verifizierungs-Threads festlegen (%u bis %d, 0 = automatisch, &lt;0 = so viele Kerne frei lassen, Standard: %d)</translation>
    </message>
    <message>
        <source>Set the processor limit for when generation is on (-1 = unlimited, default: -1)</source>
        <translation>Legt ein Prozessor-/CPU-Kernlimit fest, wenn CPU-Mining aktiviert ist (-1 = unbegrenzt, Standard: -1)</translation>
    </message>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation>Dies ist eine Vorab-Testversion - Verwendung auf eigene Gefahr - nicht für Mining- oder Handelsanwendungen nutzen!</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer. Beginnercoin Core is probably already running.</source>
        <translation>Kann auf diesem Computer nicht an %s binden, da Beginnercoin Core wahrscheinlich bereits gestartet wurde.</translation>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services (default: -proxy)</source>
        <translation>Separaten SOCKS5-Proxy verwenden, um Gegenstellen über versteckte Tor-Dienste zu erreichen (Standard: -proxy)</translation>
    </message>
    <message>
        <source>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Warnung: -paytxfee ist auf einen sehr hohen Wert festgelegt! Dies ist die Gebühr die beim Senden einer Transaktion fällig wird.</translation>
    </message>
    <message>
        <source>Warning: Please check that your computer&apos;s date and time are correct! If your clock is wrong Beginnercoin will not work properly.</source>
        <translation>Warnung: Bitte korrigieren Sie die Datums- und Uhrzeiteinstellungen ihres Computers, da Beginnercoin ansonsten nicht ordnungsgemäß funktionieren wird!</translation>
    </message>
    <message>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation>Warnung: Das Netzwerk scheint nicht vollständig übereinzustimmen! Einige Miner scheinen Probleme zu haben.</translation>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation>Warnung: Wir scheinen nicht vollständig mit unseren Gegenstellen übereinzustimmen! Sie oder die anderen Knoten müssen unter Umständen ihre Client-Software aktualisieren.</translation>
    </message>
    <message>
        <source>Warning: error reading wallet.dat! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>Warnung: Lesen von wallet.dat fehlgeschlagen! Alle Schlüssel wurden korrekt gelesen, Transaktionsdaten bzw. Adressbucheinträge fehlen aber möglicherweise oder sind inkorrekt.</translation>
    </message>
    <message>
        <source>Warning: wallet.dat corrupt, data salvaged! Original wallet.dat saved as wallet.{timestamp}.bak in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>Warnung: wallet.dat beschädigt, Datenrettung erfolgreich! Original wallet.dat wurde als wallet.{Zeitstempel}.dat in %s gespeichert. Falls ihr Kontostand oder Transaktionen nicht korrekt sind, sollten Sie von einer Datensicherung wiederherstellen.</translation>
    </message>
    <message>
        <source>(default: 1)</source>
        <translation>(Standard: 1)</translation>
    </message>
    <message>
        <source>(default: wallet.dat)</source>
        <translation>(Standard: wallet.dat)</translation>
    </message>
    <message>
        <source>&lt;category&gt; can be:</source>
        <translation>&lt;category&gt; kann sein:</translation>
    </message>
    <message>
        <source>Attempt to recover private keys from a corrupt wallet.dat</source>
        <translation>Versuchen, private Schlüssel aus einer beschädigten wallet.dat wiederherzustellen</translation>
    </message>
    <message>
        <source>Beginnercoin Core Daemon</source>
        <translation>&quot;Beginnercoin Core&quot;-Hintergrunddienst</translation>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation>Blockerzeugungsoptionen:</translation>
    </message>
    <message>
        <source>Clear list of wallet transactions (diagnostic tool; implies -rescan)</source>
        <translation>Liste der Wallet-Transaktionen zurücksetzen (Diagnosetool; beinhaltet -rescan)</translation>
    </message>
    <message>
        <source>Connect only to the specified node(s)</source>
        <translation>Mit nur dem oder den angegebenen Knoten verbinden</translation>
    </message>
    <message>
        <source>Connect through SOCKS proxy</source>
        <translation>Über einen SOCKS-Proxy verbinden</translation>
    </message>
    <message>
        <source>Connect to JSON-RPC on &lt;port&gt; (default: 9744 or testnet: 19744)</source>
        <translation>Mit JSON-RPC auf &lt;port&gt; verbinden (Standard: 9744 oder Testnetz: 19744)</translation>
    </message>
    <message>
        <source>Connection options:</source>
        <translation>Verbindungsoptionen:</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>Beschädigte Blockdatenbank erkannt</translation>
    </message>
    <message>
        <source>Debugging/Testing options:</source>
        <translation>Debugging-/Testoptionen:</translation>
    </message>
    <message>
        <source>Disable safemode, override a real safe mode event (default: 0)</source>
        <translation>Sicherheitsmodus deaktivieren, übergeht ein echtes Sicherheitsmodusereignis (Standard: 0)</translation>
    </message>
    <message>
        <source>Discover own IP address (default: 1 when listening and no -externalip)</source>
        <translation>Eigene IP-Adresse erkennen (Standard: 1, wenn abgehört wird und nicht -externalip)</translation>
    </message>
    <message>
        <source>Do not load the wallet and disable wallet RPC calls</source>
        <translation>Die Wallet nicht laden und Wallet-RPC-Aufrufe deaktivieren</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Möchten Sie die Blockdatenbank jetzt neu aufbauen?</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>Fehler beim Initialisieren der Blockdatenbank</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>Fehler beim Initialisieren der Wallet-Datenbankumgebung %s!</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>Fehler beim Laden der Blockdatenbank</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>Fehler beim Öffnen der Blockdatenbank</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Fehler: Zu wenig freier Speicherplatz auf dem Datenträger!</translation>
    </message>
    <message>
        <source>Error: Wallet locked, unable to create transaction!</source>
        <translation>Fehler: Wallet gesperrt, Transaktion kann nicht erstellt werden!</translation>
    </message>
    <message>
        <source>Error: system error: </source>
        <translation>Fehler: Systemfehler: </translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Fehler, es konnte kein Port abgehört werden. Wenn dies so gewünscht wird -listen=0 verwenden.</translation>
    </message>
    <message>
        <source>Failed to read block info</source>
        <translation>Lesen der Blockinformationen fehlgeschlagen</translation>
    </message>
    <message>
        <source>Failed to read block</source>
        <translation>Lesen des Blocks fehlgeschlagen</translation>
    </message>
    <message>
        <source>Failed to sync block index</source>
        <translation>Synchronisation des Blockindex fehlgeschlagen</translation>
    </message>
    <message>
        <source>Failed to write block index</source>
        <translation>Schreiben des Blockindex fehlgeschlagen</translation>
    </message>
    <message>
        <source>Failed to write block info</source>
        <translation>Schreiben der Blockinformationen fehlgeschlagen</translation>
    </message>
    <message>
        <source>Failed to write block</source>
        <translation>Schreiben des Blocks fehlgeschlagen</translation>
    </message>
    <message>
        <source>Failed to write file info</source>
        <translation>Schreiben der Dateiinformationen fehlgeschlagen</translation>
    </message>
    <message>
        <source>Failed to write to coin database</source>
        <translation>Schreiben in die Münzendatenbank fehlgeschlagen</translation>
    </message>
    <message>
        <source>Failed to write transaction index</source>
        <translation>Schreiben des Transaktionsindex fehlgeschlagen</translation>
    </message>
    <message>
        <source>Failed to write undo data</source>
        <translation>Schreiben der Rücksetzdaten fehlgeschlagen</translation>
    </message>
    <message>
        <source>Fee per kB to add to transactions you send</source>
        <translation>Gebühr pro kB, die gesendeten Transaktionen hinzugefügt wird</translation>
    </message>
    <message>
        <source>Fees smaller than this are considered zero fee (for relaying) (default:</source>
        <translation>Niedrigere Gebühren als diese werden als gebührenfrei angesehen (bei der Vermittlung) (Standard:</translation>
    </message>
    <message>
        <source>Find peers using DNS lookup (default: 1 unless -connect)</source>
        <translation>Gegenstellen via DNS-Abfrage finden (Standard: 1, außer bei -connect)</translation>
    </message>
    <message>
        <source>Force safe mode (default: 0)</source>
        <translation>Sicherheitsmodus erzwingen (Standard: 0)</translation>
    </message>
    <message>
        <source>Generate coins (default: 0)</source>
        <translation>Beginnercoins erzeugen (Standard: 0)</translation>
    </message>
    <message>
        <source>How many blocks to check at startup (default: 288, 0 = all)</source>
        <translation>Wieviele Blöcke beim Starten geprüft werden sollen (Standard: 288, 0 = alle)</translation>
    </message>
    <message>
        <source>If &lt;category&gt; is not supplied, output all debugging information.</source>
        <translation>Wenn &lt;category&gt; nicht angegeben wird, jegliche Debugginginformationen ausgeben.</translation>
    </message>
    <message>
        <source>Importing...</source>
        <translation>Importiere...</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>Fehlerhafter oder kein Genesis-Block gefunden. Falsches Datenverzeichnis für das Netzwerk?</translation>
    </message>
    <message>
        <source>Invalid -onion address: &apos;%s&apos;</source>
        <translation>Ungültige &quot;-onion&quot;-Adresse: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>Nicht genügend Datei-Deskriptoren verfügbar.</translation>
    </message>
    <message>
        <source>Prepend debug output with timestamp (default: 1)</source>
        <translation>Debugausgaben einen Zeitstempel voranstellen (Standard: 1)</translation>
    </message>
    <message>
        <source>RPC client options:</source>
        <translation>RPC-Client-Optionen:</translation>
    </message>
    <message>
        <source>Rebuild block chain index from current blk000??.dat files</source>
        <translation>Blockkettenindex aus aktuellen Dateien blk000??.dat wiederaufbauen</translation>
    </message>
    <message>
        <source>Select SOCKS version for -proxy (4 or 5, default: 5)</source>
        <translation>SOCKS-Version des Proxies wählen (4 oder 5, Standard: 5)</translation>
    </message>
    <message>
        <source>Set database cache size in megabytes (%d to %d, default: %d)</source>
        <translation>Größe des Datenbankcaches in Megabyte festlegen (%d bis %d, Standard: %d)</translation>
    </message>
    <message>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation>Maximale Blockgröße in Byte festlegen (Standard: %d)</translation>
    </message>
    <message>
        <source>Set the number of threads to service RPC calls (default: 4)</source>
        <translation>Maximale Anzahl an Threads zur Verarbeitung von RPC-Anfragen festlegen (Standard: 4)</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>Wallet-Datei angeben (innerhalb des Datenverzeichnisses)</translation>
    </message>
    <message>
        <source>Spend unconfirmed change when sending transactions (default: 1)</source>
        <translation>Unbestätigtes Wechselgeld beim Senden von Transaktionen ausgeben (Standard: 1)</translation>
    </message>
    <message>
        <source>This is intended for regression testing tools and app development.</source>
        <translation>Dies ist für Regressionstest-Tools und Anwendungsentwicklung gedacht.</translation>
    </message>
    <message>
        <source>Usage (deprecated, use beginnercoin-cli):</source>
        <translation>Benutzung (veraltet, bitte beginnercoin-cli verwenden):</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>Verifiziere Blöcke...</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>Verifiziere Wallet...</translation>
    </message>
    <message>
        <source>Wait for RPC server to start</source>
        <translation>Warten, bis der RPC-Server gestartet ist</translation>
    </message>
    <message>
        <source>Wallet %s resides outside data directory %s</source>
        <translation>Wallet %s liegt außerhalb des Datenverzeichnisses %s</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>Wallet-Optionen:</translation>
    </message>
    <message>
        <source>Warning: Deprecated argument -debugnet ignored, use -debug=net</source>
        <translation>Warnung: Veraltetes Argument -debugnet gefunden, bitte -debug=net verwenden</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to change -txindex</source>
        <translation>Sie müssen die Datenbank mit Hilfe von -reindex neu aufbauen, um -txindex zu verändern</translation>
    </message>
    <message>
        <source>Imports blocks from external blk000??.dat file</source>
        <translation>Blöcke aus externer Datei blk000??.dat importieren</translation>
    </message>
    <message>
        <source>Cannot obtain a lock on data directory %s. Beginnercoin Core is probably already running.</source>
        <translation>Datenverzeichnis %s kann nicht gesperrt werden, da Beginnercoin Core wahrscheinlich bereits gestartet wurde.</translation>
    </message>
    <message>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation>Befehl ausführen wenn ein relevanter Alarm empfangen wird oder wir einen wirklich langen Fork entdecken (%s im Befehl wird durch die Nachricht ersetzt)</translation>
    </message>
    <message>
        <source>Output debugging information (default: 0, supplying &lt;category&gt; is optional)</source>
        <translation>Debugginginformationen ausgeben (Standard: 0, &lt;category&gt; anzugeben ist optional)</translation>
    </message>
    <message>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: %d)</source>
        <translation>Maximale Größe in Byte von Transaktionen hoher Priorität/mit niedrigen Gebühren festlegen (Standard: %d)</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Hinweis</translation>
    </message>
    <message>
        <source>Invalid amount for -minrelaytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Ungültiger Betrag für -minrelaytxfee=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount for -mintxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Ungültiger Betrag für -mintxfee=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Limit size of signature cache to &lt;n&gt; entries (default: 50000)</source>
        <translation>Größe des Signaturcaches auf &lt;n&gt; Einträge begrenzen (Standard: 50000)</translation>
    </message>
    <message>
        <source>Log transaction priority and fee per kB when mining blocks (default: 0)</source>
        <translation>Transaktionspriorität und Gebühr pro kB beim Erzeugen von Blöcken protokollieren (Standard: 0)</translation>
    </message>
    <message>
        <source>Maintain a full transaction index (default: 0)</source>
        <translation>Einen vollständigen Transaktionsindex führen (Standard: 0)</translation>
    </message>
    <message>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: 5000)</source>
        <translation>Maximale Größe des Empfangspuffers pro Verbindung, &lt;n&gt; * 1000 Byte (Standard: 5000)</translation>
    </message>
    <message>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: 1000)</source>
        <translation>Maximale Größe des Sendepuffers pro Verbindung, &lt;n&gt; * 1000 Byte (Standard: 1000)</translation>
    </message>
    <message>
        <source>Only accept block chain matching built-in checkpoints (default: 1)</source>
        <translation>Blockkette nur als gültig ansehen, wenn sie mit den integrierten Prüfpunkten übereinstimmt (Standard: 1)</translation>
    </message>
    <message>
        <source>Only connect to nodes in network &lt;net&gt; (IPv4, IPv6 or Tor)</source>
        <translation>Verbinde nur zu Knoten des Netztyps &lt;net&gt; (IPv4, IPv6 oder Tor)</translation>
    </message>
    <message>
        <source>Print block on startup, if found in block index</source>
        <translation>Block beim Starten ausgeben, wenn dieser im Blockindex gefunden wurde.</translation>
    </message>
    <message>
        <source>Print block tree on startup (default: 0)</source>
        <translation>Blockbaum beim Starten ausgeben (Standard: 0)</translation>
    </message>
    <message>
        <source>RPC SSL options: (see the Beginnercoin Wiki for SSL setup instructions)</source>
        <translation>RPC-SSL-Optionen (siehe Beginnercoin-Wiki für SSL-Einrichtung):</translation>
    </message>
    <message>
        <source>RPC server options:</source>
        <translation>RPC-Serveroptionen:</translation>
    </message>
    <message>
        <source>Randomly drop 1 of every &lt;n&gt; network messages</source>
        <translation>Zufällig eine von &lt;n&gt; Netzwerknachrichten verwerfen</translation>
    </message>
    <message>
        <source>Randomly fuzz 1 of every &lt;n&gt; network messages</source>
        <translation>Zufällig eine von &lt;n&gt; Netzwerknachrichten verwürfeln</translation>
    </message>
    <message>
        <source>Run a thread to flush wallet periodically (default: 1)</source>
        <translation>Einen Thread starten, der periodisch die Wallet sicher auf den Datenträger schreibt (Standard: 1)</translation>
    </message>
    <message>
        <source>SSL options: (see the Beginnercoin Wiki for SSL setup instructions)</source>
        <translation>SSL-Optionen (siehe Beginnercoin-Wiki für SSL-Einrichtungssanweisungen):</translation>
    </message>
    <message>
        <source>Send command to Beginnercoin Core</source>
        <translation>Befehl an Beginnercoin Core senden</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Rückverfolgungs- und Debuginformationen an die Konsole senden, anstatt sie in debug.log zu schreiben</translation>
    </message>
    <message>
        <source>Set minimum block size in bytes (default: 0)</source>
        <translation>Minimale Blockgröße in Byte festlegen (Standard: 0)</translation>
    </message>
    <message>
        <source>Sets the DB_PRIVATE flag in the wallet db environment (default: 1)</source>
        <translation>DB_PRIVATE-Flag in der Wallet-Datenbankumgebung setzen (Standard: 1)</translation>
    </message>
    <message>
        <source>Show all debugging options (usage: --help -help-debug)</source>
        <translation>Zeige alle Debuggingoptionen (Benutzung: --help -help-debug)</translation>
    </message>
    <message>
        <source>Show benchmark information (default: 0)</source>
        <translation>Zeige Benchmarkinformationen (Standard: 0)</translation>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>Protokolldatei debug.log beim Starten des Clients kürzen (Standard: 1, wenn kein -debug)</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>Signierung der Transaktion fehlgeschlagen</translation>
    </message>
    <message>
        <source>Specify connection timeout in milliseconds (default: 5000)</source>
        <translation>Verbindungzeitüberschreitung in Millisekunden festlegen (Standard: 5000)</translation>
    </message>
    <message>
        <source>Start Beginnercoin Core Daemon</source>
        <translation>&quot;Beginnercoin Core&quot;-Hintergrunddienst starten</translation>
    </message>
    <message>
        <source>System error: </source>
        <translation>Systemfehler: </translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>Transaktionsbetrag zu niedrig</translation>
    </message>
    <message>
        <source>Transaction amounts must be positive</source>
        <translation>Transaktionsbeträge müssen positiv sein</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>Transaktion zu groß</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 0)</source>
        <translation>UPnP verwenden, um eine Portweiterleitung einzurichten (Standard: 0)</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 1 when listening)</source>
        <translation>UPnP verwenden, um eine Portweiterleitung einzurichten (Standard: 1, wenn abgehört wird)</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Benutzername für JSON-RPC-Verbindungen</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Warnung</translation>
    </message>
    <message>
        <source>Warning: This version is obsolete, upgrade required!</source>
        <translation>Warnung: Diese Version is veraltet, Aktualisierung erforderlich!</translation>
    </message>
    <message>
        <source>Zapping all transactions from wallet...</source>
        <translation>Lösche alle Transaktionen aus Wallet...</translation>
    </message>
    <message>
        <source>on startup</source>
        <translation>beim Starten</translation>
    </message>
    <message>
        <source>version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>wallet.dat corrupt, salvage failed</source>
        <translation>wallet.dat beschädigt, Datenrettung fehlgeschlagen</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Passwort für JSON-RPC-Verbindungen</translation>
    </message>
    <message>
        <source>Allow JSON-RPC connections from specified IP address</source>
        <translation>JSON-RPC-Verbindungen von der angegebenen IP-Adresse erlauben</translation>
    </message>
    <message>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</source>
        <translation>Sende Befehle an Knoten &lt;ip&gt; (Standard: 127.0.0.1)</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>Befehl ausführen wenn der beste Block wechselt (%s im Befehl wird durch den Hash des Blocks ersetzt)</translation>
    </message>
    <message>
        <source>Upgrade wallet to latest format</source>
        <translation>Wallet auf das neueste Format aktualisieren</translation>
    </message>
    <message>
        <source>Set key pool size to &lt;n&gt; (default: 100)</source>
        <translation>Größe des Schlüsselpools festlegen auf &lt;n&gt; (Standard: 100)</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Blockkette erneut nach fehlenden Wallet-Transaktionen durchsuchen</translation>
    </message>
    <message>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>OpenSSL (https) für JSON-RPC-Verbindungen verwenden</translation>
    </message>
    <message>
        <source>Server certificate file (default: server.cert)</source>
        <translation>Serverzertifikat (Standard: server.cert)</translation>
    </message>
    <message>
        <source>Server private key (default: server.pem)</source>
        <translation>Privater Serverschlüssel (Standard: server.pem)</translation>
    </message>
    <message>
        <source>This help message</source>
        <translation>Dieser Hilfetext</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer (bind returned error %d, %s)</source>
        <translation>Kann auf diesem Computer nicht an %s binden (von bind zurückgegebener Fehler %d, %s)</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Erlaube DNS-Abfragen für -addnode, -seednode und -connect</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Lade Adressen...</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Fehler beim Laden von wallet.dat: Wallet beschädigt</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet requires newer version of Beginnercoin</source>
        <translation>Fehler beim Laden von wallet.dat: Wallet benötigt neuere Version von Beginnercoin</translation>
    </message>
    <message>
        <source>Wallet needed to be rewritten: restart Beginnercoin to complete</source>
        <translation>Wallet musste neu geschrieben werden: starten Sie Beginnercoin zur Fertigstellung neu</translation>
    </message>
    <message>
        <source>Error loading wallet.dat</source>
        <translation>Fehler beim Laden von wallet.dat</translation>
    </message>
    <message>
        <source>Invalid -proxy address: &apos;%s&apos;</source>
        <translation>Ungültige Adresse in -proxy: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: &apos;%s&apos;</source>
        <translation>Unbekannter Netztyp in -onlynet angegeben: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Unknown -socks proxy version requested: %i</source>
        <translation>Unbekannte Proxyversion in -socks angefordert: %i</translation>
    </message>
    <message>
        <source>Cannot resolve -bind address: &apos;%s&apos;</source>
        <translation>Kann Adresse in -bind nicht auflösen: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Cannot resolve -externalip address: &apos;%s&apos;</source>
        <translation>Kann Adresse in -externalip nicht auflösen: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Ungültiger Betrag für -paytxfee=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount</source>
        <translation>Ungültiger Betrag</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Unzureichender Kontostand</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Lade Blockindex...</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Mit dem angegebenen Knoten verbinden und versuchen die Verbindung aufrecht zu erhalten</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Lade Wallet...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Wallet kann nicht auf eine ältere Version herabgestuft werden</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>Standardadresse kann nicht geschrieben werden</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Durchsuche erneut...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Laden abgeschlossen</translation>
    </message>
    <message>
        <source>To use the %s option</source>
        <translation>Zur Nutzung der %s-Option</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <source>You must set rpcpassword=&lt;password&gt; in the configuration file:
%s
If the file does not exist, create it with owner-readable-only file permissions.</source>
        <translation>Sie müssen den Wert rpcpassword=&lt;passwort&gt; in der Konfigurationsdatei angeben:
%s
Falls die Konfigurationsdatei nicht existiert, erzeugen Sie diese bitte mit Leserechten nur für den Dateibesitzer.</translation>
    </message>
</context>
</TS>