<?xml version="1.0" ?><!DOCTYPE TS><TS language="da" version="2.1">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About Beginnercoin Core</source>
        <translation>Om Beginnercoin Core</translation>
    </message>
    <message>
        <source>&lt;b&gt;Beginnercoin Core&lt;/b&gt; version</source>
        <translation>&lt;b&gt;Beginnercoin Core&lt;/b&gt; version</translation>
    </message>
    <message>
        <source>
This is experimental software.

Distributed under the MIT/X11 software license, see the accompanying file COPYING or http://www.opensource.org/licenses/mit-license.php.

This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (http://www.openssl.org/) and cryptographic software written by Eric Young (eay@cryptsoft.com) and UPnP software written by Thomas Bernard.</source>
        <translation>
Dette program er eksperimentelt.

Det er gjort tilgængeligt under MIT/X11-softwarelicensen. Se den medfølgende fil &quot;COPYING&quot; eller http://www.opensource.org/licenses/mit-license.php.

Produktet indeholder software som er udviklet af OpenSSL Project til brug i OpenSSL Toolkit (http://www.openssl.org/), kryptografisk software skrevet af Eric Young (eay@cryptsoft.com) og UPnP-software skrevet af Thomas Bernard.</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Ophavsret</translation>
    </message>
    <message>
        <source>The Beginnercoin Core developers</source>
        <translation>Udviklerne af Beginnercoin Core</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation>(%1-bit)</translation>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Double-click to edit address or label</source>
        <translation>Dobbeltklik for at redigere adresse eller mærkat</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Opret en ny adresse</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>Ny</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Kopiér den valgte adresse til systemets udklipsholder</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>Kopiér</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>Luk</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>Kopiér adresse</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Slet den markerede adresse fra listen</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Eksportér den aktuelle visning til en fil</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>Eksportér</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>Slet</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Vælg adresse at sende beginnercoins til</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Vælg adresse at modtage beginnercoins med</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>Vælg</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>Afsendelsesadresser</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>Modtagelsesadresser</translation>
    </message>
    <message>
        <source>These are your Beginnercoin addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Disse er dine Beginnercoin-adresser for at sende betalinger. Tjek altid beløb og modtageradresse, inden du sender beginnercoins.</translation>
    </message>
    <message>
        <source>These are your Beginnercoin addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>Dette er dine Beginnercoin-adresser til at modtage betalinger med. Det anbefales are bruge en ny modtagelsesadresse for hver transaktion.</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>Kopiér mærkat</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>Redigér</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>Eksportér adresseliste</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Kommasepareret fil (*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Eksport mislykkedes</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1.</source>
        <translation>En fejl opstod under gemning af adresseliste til %1.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Mærkat</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(ingen mærkat)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Adgangskodedialog</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Indtast adgangskode</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Ny adgangskode</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Gentag ny adgangskode</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Indtast den nye adgangskode til tegnebogen.&lt;br/&gt;Brug venligst en adgangskode på &lt;b&gt;10 eller flere tilfældige tegn&lt;/b&gt; eller &lt;b&gt;otte eller flere ord&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Kryptér tegnebog</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Denne funktion har brug for din tegnebogs adgangskode for at låse tegnebogen op.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Lås tegnebog op</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Denne funktion har brug for din tegnebogs adgangskode for at dekryptere tegnebogen.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Dekryptér tegnebog</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Skift adgangskode</translation>
    </message>
    <message>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>Indtast den gamle og den nye adgangskode til tegnebogen.</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Bekræft tegnebogskryptering</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR BEGINNERCOINS&lt;/b&gt;!</source>
        <translation>Advarsel: Hvis du krypterer din tegnebog og mister din adgangskode, vil du &lt;b&gt;MISTE ALLE DINE BEGINNERCOINS&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Er du sikker på, at du ønsker at kryptere din tegnebog?</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>VIGTIGT: Enhver tidligere sikkerhedskopi, som du har lavet af tegnebogsfilen, bør blive erstattet af den nyligt genererede, krypterede tegnebogsfil. Af sikkerhedsmæssige årsager vil tidligere sikkerhedskopier af den ikke-krypterede tegnebogsfil blive ubrugelige i det øjeblik, du starter med at anvende den nye, krypterede tegnebog.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Advarsel: Caps Lock-tasten er aktiveret!</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Tegnebog krypteret</translation>
    </message>
    <message>
        <source>Beginnercoin will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your beginnercoins from being stolen by malware infecting your computer.</source>
        <translation>Beginnercoin vil nu lukke for at gennemføre krypteringsprocessen. Husk på, at kryptering af din tegnebog vil ikke beskytte dine beginnercoins fuldt ud mod at blive stjålet af malware på din computer.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Tegnebogskryptering mislykkedes</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Tegnebogskryptering mislykkedes på grund af en intern fejl. Din tegnebog blev ikke krypteret.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>De angivne adgangskoder stemmer ikke overens.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Tegnebogsoplåsning mislykkedes</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Den angivne adgangskode for tegnebogsdekrypteringen er forkert.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Tegnebogsdekryptering mislykkedes</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Tegnebogens adgangskode blev ændret.</translation>
    </message>
</context>
<context>
    <name>BeginnercoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>Underskriv besked …</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Synkroniserer med netværk …</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>Oversigt</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Knude</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Vis generel oversigt over tegnebog</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>Transaktioner</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Gennemse transaktionshistorik</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>Luk</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Afslut program</translation>
    </message>
    <message>
        <source>Show information about Beginnercoin</source>
        <translation>Vis informationer om Beginnercoin</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Om Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Vis informationer om Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>Indstillinger …</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>Kryptér tegnebog …</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>Sikkerhedskopiér tegnebog …</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>Skift adgangskode …</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>Afsendelsesadresser …</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>Modtagelsesadresser …</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>Åbn URI …</translation>
    </message>
    <message>
        <source>Importing blocks from disk...</source>
        <translation>Importerer blokke fra disken …</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>Genindekserer blokke på disken …</translation>
    </message>
    <message>
        <source>Send coins to a Beginnercoin address</source>
        <translation>Send beginnercoins til en Beginnercoin-adresse</translation>
    </message>
    <message>
        <source>Modify configuration options for Beginnercoin</source>
        <translation>Redigér konfigurationsindstillinger for Beginnercoin</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Lav sikkerhedskopi af tegnebogen til et andet sted</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Skift adgangskode anvendt til tegnebogskryptering</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>Fejlsøgningsvindue</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Åbn fejlsøgnings- og diagnosticeringskonsollen</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>Verificér besked …</translation>
    </message>
    <message>
        <source>Beginnercoin</source>
        <translation>Beginnercoin</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Tegnebog</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>Send</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>Modtag</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>Vis / skjul</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Vis eller skjul hovedvinduet</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Kryptér de private nøgler, der hører til din tegnebog</translation>
    </message>
    <message>
        <source>Sign messages with your Beginnercoin addresses to prove you own them</source>
        <translation>Underskriv beskeder med dine Beginnercoin-adresser for at bevise, at de tilhører dig</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Beginnercoin addresses</source>
        <translation>Verificér beskeder for at sikre, at de er underskrevet med de angivne Beginnercoin-adresser</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>Fil</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>Opsætning</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>Hjælp</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Faneværktøjslinje</translation>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[testnetværk]</translation>
    </message>
    <message>
        <source>Beginnercoin Core</source>
        <translation>Beginnercoin Core</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and beginnercoin: URIs)</source>
        <translation>Forespørg betalinger (genererer QR-koder og &quot;beginnercoin:&quot;-URI&apos;er)</translation>
    </message>
    <message>
        <source>&amp;About Beginnercoin Core</source>
        <translation>Om Beginnercoin Core</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>Vis listen over brugte afsendelsesadresser og -mærkater</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>Vis listen over brugte modtagelsesadresser og -mærkater</translation>
    </message>
    <message>
        <source>Open a beginnercoin: URI or payment request</source>
        <translation>Åbn en &quot;beginnercoin:&quot;-URI eller betalingsforespørgsel</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>Tilvalg for kommandolinje</translation>
    </message>
    <message>
        <source>Show the Beginnercoin Core help message to get a list with possible Beginnercoin command-line options</source>
        <translation>Vis Beginnercoin Core hjælpebesked for at få en liste over mulige tilvalg for Beginnercoin kommandolinje</translation>
    </message>
    <message>
        <source>Beginnercoin client</source>
        <translation>Beginnercoin-klient</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Beginnercoin network</source>
        <translation><numerusform>%n aktiv forbindelse til Beginnercoin-netværket</numerusform><numerusform>%n aktive forbindelser til Beginnercoin-netværket</numerusform></translation>
    </message>
    <message>
        <source>No block source available...</source>
        <translation>Ingen blokkilde tilgængelig …</translation>
    </message>
    <message>
        <source>Processed %1 of %2 (estimated) blocks of transaction history.</source>
        <translation>Behandlet %1 ud af %2 (estimeret) blokke af transaktionshistorikken.</translation>
    </message>
    <message>
        <source>Processed %1 blocks of transaction history.</source>
        <translation>Behandlet %1 blokke af transaktionshistorikken.</translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation><numerusform>%n time</numerusform><numerusform>%n timer</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation><numerusform>%n dag</numerusform><numerusform>%n dage</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation><numerusform>%n uge</numerusform><numerusform>%n uger</numerusform></translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 og %2</translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation><numerusform>%n år</numerusform><numerusform>%n år</numerusform></translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>%1 bagud</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>Senest modtagne blok blev genereret for %1 siden.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Transaktioner herefter vil endnu ikke være synlige.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fejl</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Opdateret</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Indhenter …</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Afsendt transaktion</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Indgående transaktion</translation>
    </message>
    <message>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Dato: %1
Beløb: %2
Type: %3
Adresse: %4
</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Tegnebog er &lt;b&gt;krypteret&lt;/b&gt; og i øjeblikket &lt;b&gt;ulåst&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Tegnebog er &lt;b&gt;krypteret&lt;/b&gt; og i øjeblikket &lt;b&gt;låst&lt;/b&gt;</translation>
    </message>
    <message>
        <source>A fatal error occurred. Beginnercoin can no longer continue safely and will quit.</source>
        <translation>Der opstod en fatal fejl. Beginnercoin kan ikke længere fortsætte sikkert og vil afslutte.</translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <source>Network Alert</source>
        <translation>Netværksadvarsel</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Control Address Selection</source>
        <translation>Adressevalg for coin-styring</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Mængde:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Byte:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Beløb:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Prioritet:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Gebyr:</translation>
    </message>
    <message>
        <source>Low Output:</source>
        <translation>Lavt output:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Efter gebyr:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Byttepenge:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>(af)vælg alle</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>Trætilstand</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>Listetilstand</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Beløb</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Bekræftelser</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Bekræftet</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopiér adresse</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopiér mærkat</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopiér beløb</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Kopiér transaktions-ID</translation>
    </message>
    <message>
        <source>Lock unspent</source>
        <translation>Fastlås ubrugte</translation>
    </message>
    <message>
        <source>Unlock unspent</source>
        <translation>Lås ubrugte op</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Kopiér mængde</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Kopiér gebyr</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Kopiér efter-gebyr</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Kopiér byte</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>Kopiér prioritet</translation>
    </message>
    <message>
        <source>Copy low output</source>
        <translation>Kopiér lavt output</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Kopiér byttepenge</translation>
    </message>
    <message>
        <source>highest</source>
        <translation>højest</translation>
    </message>
    <message>
        <source>higher</source>
        <translation>højere</translation>
    </message>
    <message>
        <source>high</source>
        <translation>højt</translation>
    </message>
    <message>
        <source>medium-high</source>
        <translation>mellemhøj</translation>
    </message>
    <message>
        <source>medium</source>
        <translation>medium</translation>
    </message>
    <message>
        <source>low-medium</source>
        <translation>mellemlav</translation>
    </message>
    <message>
        <source>low</source>
        <translation>lav</translation>
    </message>
    <message>
        <source>lower</source>
        <translation>lavere</translation>
    </message>
    <message>
        <source>lowest</source>
        <translation>lavest</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation>(%1 fastlåst)</translation>
    </message>
    <message>
        <source>none</source>
        <translation>ingen</translation>
    </message>
    <message>
        <source>Dust</source>
        <translation>Støv</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>ja</translation>
    </message>
    <message>
        <source>no</source>
        <translation>nej</translation>
    </message>
    <message>
        <source>This label turns red, if the transaction size is greater than 1000 bytes.</source>
        <translation>Dette mærkat bliver rødt, hvis transaktionsstørrelsen er større end 1000 byte.</translation>
    </message>
    <message>
        <source>This means a fee of at least %1 per kB is required.</source>
        <translation>Dette betyder, at et gebyr på mindst %1 pr. kB er nødvendigt.</translation>
    </message>
    <message>
        <source>Can vary +/- 1 byte per input.</source>
        <translation>Kan variere ±1 byte pr. input.</translation>
    </message>
    <message>
        <source>Transactions with higher priority are more likely to get included into a block.</source>
        <translation>Transaktioner med højere prioritet har højere sansynlighed for at blive inkluderet i en blok.</translation>
    </message>
    <message>
        <source>This label turns red, if the priority is smaller than &quot;medium&quot;.</source>
        <translation>Dette mærkat bliver rødt, hvis prioriteten er mindre end &quot;medium&quot;.</translation>
    </message>
    <message>
        <source>This label turns red, if any recipient receives an amount smaller than %1.</source>
        <translation>Dette mærkat bliver rødt, hvis mindst én modtager et beløb mindre end %1.</translation>
    </message>
    <message>
        <source>This means a fee of at least %1 is required.</source>
        <translation>Dette betyder, at et gebyr på mindst %1 er nødvendigt.</translation>
    </message>
    <message>
        <source>Amounts below 0.546 times the minimum relay fee are shown as dust.</source>
        <translation>Beløb under 0,546 gange det minimale videreførselsgebyr vises som støv.</translation>
    </message>
    <message>
        <source>This label turns red, if the change is smaller than %1.</source>
        <translation>Dette mærkat bliver rødt, hvis byttepengene er mindre end %1.</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(ingen mærkat)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation>byttepenge fra %1 (%2)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation>(byttepange)</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Redigér adresse</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>Mærkat</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>Mærkatet, der er associeret med denne indgang i adresselisten</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>Adressen, der er associeret med denne indgang i adresselisten. Denne kan kune ændres for afsendelsesadresser.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Ny modtagelsesadresse</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Ny afsendelsesadresse</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Redigér modtagelsesadresse</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Redigér afsendelsesadresse</translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>Den indtastede adresse &quot;%1&quot; er allerede i adressebogen.</translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is not a valid Beginnercoin address.</source>
        <translation>Den indtastede adresse &quot;%1&quot; er ikke en gyldig Beginnercoin-adresse.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Kunne ikke låse tegnebog op.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Ny nøglegenerering mislykkedes.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>En ny datamappe vil blive oprettet.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>navn</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>Mappe eksisterer allerede. Tilføj %1, hvis du vil oprette en ny mappe her.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>Sti eksisterer allerede og er ikke en mappe.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>Kan ikke oprette en mappe her.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>Beginnercoin Core - Command-line options</source>
        <translation>Beginnercoin Core – tilvalg for kommandolinje</translation>
    </message>
    <message>
        <source>Beginnercoin Core</source>
        <translation>Beginnercoin Core</translation>
    </message>
    <message>
        <source>version</source>
        <translation>version</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Anvendelse:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>kommandolinjetilvalg</translation>
    </message>
    <message>
        <source>UI options</source>
        <translation>Brugergrænsefladeindstillinger</translation>
    </message>
    <message>
        <source>Set language, for example &quot;de_DE&quot; (default: system locale)</source>
        <translation>Angiv sprog, fx &quot;da_DK&quot; (standard: systemlokalitet)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>Start minimeret</translation>
    </message>
    <message>
        <source>Set SSL root certificates for payment request (default: -system-)</source>
        <translation>Sæt SSL-rodcertifikater for betalingsforespørgsel (standard: -system-)</translation>
    </message>
    <message>
        <source>Show splash screen on startup (default: 1)</source>
        <translation>Vis opstartsbillede ved opstart (standard: 1)</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: 0)</source>
        <translation>Vælg datamappe ved opstart (standard: 0)</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Velkommen</translation>
    </message>
    <message>
        <source>Welcome to Beginnercoin Core.</source>
        <translation>Velkommen til Beginnercoin Core.</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where Beginnercoin Core will store its data.</source>
        <translation>Siden dette er første gang, programmet startes, kan du vælge, hvor Beginnercoin Core skal gemme sin data.</translation>
    </message>
    <message>
        <source>Beginnercoin Core will download and store a copy of the Beginnercoin block chain. At least %1GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</source>
        <translation>Beginnercoin Core vil downloade og gemme et kopi af Beginnercoin-blokkæden. Mindst %1 GB data vil blive gemt i denne mappe, og den vil vokse over tid. Tegnebogen vil også blive gemt i denne mappe.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>Brug standardmappen for data</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>Brug tilpasset mappe for data:</translation>
    </message>
    <message>
        <source>Beginnercoin</source>
        <translation>Beginnercoin</translation>
    </message>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; can not be created.</source>
        <translation>Fejl: Angivet datamappe &quot;%1&quot; kan ikke oprettes.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fejl</translation>
    </message>
    <message>
        <source>GB of free space available</source>
        <translation>GB fri plads tilgængelig</translation>
    </message>
    <message>
        <source>(of %1GB needed)</source>
        <translation>(ud af %1 GB behøvet)</translation>
    </message>
</context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>Åbn URI</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>Åbn betalingsforespørgsel fra URI eller fil</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>Vælg fil for betalingsforespørgsel</translation>
    </message>
    <message>
        <source>Select payment request file to open</source>
        <translation>Vælg fil for betalingsforespørgsel til åbning</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Indstillinger</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>Generelt</translation>
    </message>
    <message>
        <source>Optional transaction fee per kB that helps make sure your transactions are processed quickly. Most transactions are 1 kB.</source>
        <translation>Valgfrit transaktionsgebyr pr. kB, der hjælper dine transaktioner med at blive behandlet hurtigt. De fleste transaktioner er på 1 kB.</translation>
    </message>
    <message>
        <source>Pay transaction &amp;fee</source>
        <translation>Betal transaktionsgebyr</translation>
    </message>
    <message>
        <source>Automatically start Beginnercoin after logging in to the system.</source>
        <translation>Start Beginnercoin automatisk, når der logges ind på systemet.</translation>
    </message>
    <message>
        <source>&amp;Start Beginnercoin on system login</source>
        <translation>Start Beginnercoin ved systemlogin</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>Størrelsen på databasens cache</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation>Antallet af scriptverificeringstråde</translation>
    </message>
    <message>
        <source>Connect to the Beginnercoin network through a SOCKS proxy.</source>
        <translation>Forbind til Beginnercoin-netværket gennem en SOCKS-proxy.</translation>
    </message>
    <message>
        <source>&amp;Connect through SOCKS proxy (default proxy):</source>
        <translation>Forbind gennem SOCKS-proxy (standard-proxy):</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>IP-adresse for proxyen (fx IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Third party URLs (e.g. a block explorer) that appear in the transactions tab as context menu items. %s in the URL is replaced by transaction hash. Multiple URLs are separated by vertical bar |.</source>
        <translation>Tredjeparts-URL&apos;er (fx et blokhåndteringsværktøj), der vises i transaktionsfanen som genvejsmenupunkter. %s i URL&apos;en erstattes med transaktionens hash. Flere URL&apos;er separeres med en lodret streg |.</translation>
    </message>
    <message>
        <source>Third party transaction URLs</source>
        <translation>Tredjeparts-transaktions-URL&apos;er</translation>
    </message>
    <message>
        <source>Active command-line options that override above options:</source>
        <translation>Aktuelle tilvalg for kommandolinjen, der tilsidesætter ovenstående tilvalg:</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>Nulstil alle klientindstillinger til deres standard.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>Nulstil indstillinger</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>Netværk</translation>
    </message>
    <message>
        <source>(0 = auto, &lt;0 = leave that many cores free)</source>
        <translation>(0 = auto, &lt;0 = efterlad så mange kerner fri)</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>Tegnebog</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>Ekspert</translation>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation>Slå egenskaber for coin-styring til</translation>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction cannot be used until that transaction has at least one confirmation. This also affects how your balance is computed.</source>
        <translation>Hvis du slår brug af ubekræftede byttepenge fra, kan byttepengene fra en transaktion ikke bruges, før pågældende transaktion har mindst én bekræftelse. Dette påvirker også måden hvorpå din saldo beregnes.</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation>Brug ubekræftede byttepenge</translation>
    </message>
    <message>
        <source>Automatically open the Beginnercoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Åbn automatisk Beginnercoin-klientens port på routeren. Dette virker kun, når din router understøtter UPnP, og UPnP er aktiveret.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Konfigurér port vha. UPnP</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>Proxy-IP:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Port for proxyen (fx 9050)</translation>
    </message>
    <message>
        <source>SOCKS &amp;Version:</source>
        <translation>SOCKS-version</translation>
    </message>
    <message>
        <source>SOCKS version of the proxy (e.g. 5)</source>
        <translation>SOCKS-version for proxyen (fx 5)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>Vindue</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Vis kun et statusikon efter minimering af vinduet.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>Minimér til statusfeltet i stedet for proceslinjen</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>Minimér i stedet for at afslutte programmet, når vinduet lukkes. Når denne indstilling er valgt, vil programmet kun blive lukket, når du har valgt Afslut i menuen.</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>Minimér ved lukning</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>Visning</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>Sprog for brugergrænseflade:</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting Beginnercoin.</source>
        <translation>Sproget for brugergrænsefladen kan angives her. Denne indstilling træder først i kraft, når Beginnercoin genstartes.</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>Enhed at vise beløb i:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Vælg standard for underopdeling af enhed, som skal vises i brugergrænsefladen og ved afsendelse af beginnercoins.</translation>
    </message>
    <message>
        <source>Whether to show Beginnercoin addresses in the transaction list or not.</source>
        <translation>Afgør hvorvidt Beginnercoin-adresser skal vises i transaktionslisten eller ej.</translation>
    </message>
    <message>
        <source>&amp;Display addresses in transaction list</source>
        <translation>Vis adresser i transaktionsliste</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>Hvorvidt egenskaber for coin-styring skal vises eller ej.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>Annullér</translation>
    </message>
    <message>
        <source>default</source>
        <translation>standard</translation>
    </message>
    <message>
        <source>none</source>
        <translation>ingeningen</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>Bekræft nulstilling af indstillinger</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>Genstart af klienten er nødvendig for at aktivere ændringer.</translation>
    </message>
    <message>
        <source>Client will be shutdown, do you want to proceed?</source>
        <translation>Klienten vil blive lukket ned; vil du fortsætte?</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>Denne ændring vil kræve en genstart af klienten.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>Den angivne proxy-adresse er ugyldig.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Beginnercoin network after a connection is established, but this process has not completed yet.</source>
        <translation>Den viste information kan være forældet. Din tegnebog synkroniserer automatisk med Beginnercoin-netværket, når en forbindelse etableres, men denne proces er ikke gennemført endnu.</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Tegnebog</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>Tilgængelig:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>Din nuværende tilgængelige saldo</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>Uafgjort:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>Total saldo for transaktioner, som ikke er blevet bekræftet endnu, og som ikke endnu er en del af den tilgængelige saldo</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Umodne:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>Udvunden saldo, som endnu ikke er modnet</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Total:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>Din nuværende totale saldo</translation>
    </message>
    <message>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;Nyeste transaktioner&lt;/b&gt;</translation>
    </message>
    <message>
        <source>out of sync</source>
        <translation>ikke synkroniseret</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>URI handling</source>
        <translation>URI-håndtering</translation>
    </message>
    <message>
        <source>URI can not be parsed! This can be caused by an invalid Beginnercoin address or malformed URI parameters.</source>
        <translation>URI kan ikke fortolkes! Dette kan skyldes en ugyldig Beginnercoin-adresse eller misdannede URI-parametre.</translation>
    </message>
    <message>
        <source>Requested payment amount of %1 is too small (considered dust).</source>
        <translation>Forespurgt betalingsbeløb på %1 er for lille (regnes som støv).</translation>
    </message>
    <message>
        <source>Payment request error</source>
        <translation>Fejl i betalingsforespørgsel</translation>
    </message>
    <message>
        <source>Cannot start beginnercoin: click-to-pay handler</source>
        <translation>Kan ikke starte beginnercoin: click-to-pay-håndtering</translation>
    </message>
    <message>
        <source>Net manager warning</source>
        <translation>Net-håndterings-advarsel</translation>
    </message>
    <message>
        <source>Your active proxy doesn&apos;t support SOCKS5, which is required for payment requests via proxy.</source>
        <translation>Din aktuelle proxy understøtter ikke SOCKS5, hvilket kræves for betalingsforespørgsler via proxy.</translation>
    </message>
    <message>
        <source>Payment request fetch URL is invalid: %1</source>
        <translation>Betalingsforespørgslens hentnings-URL er ugyldig: %1</translation>
    </message>
    <message>
        <source>Payment request file handling</source>
        <translation>Filhåndtering for betalingsanmodninger</translation>
    </message>
    <message>
        <source>Payment request file can not be read or processed! This can be caused by an invalid payment request file.</source>
        <translation>Betalingsanmodningsfil kan ikke indlæses eller bearbejdes! Dette kan skyldes en ugyldig betalingsanmodningsfil.</translation>
    </message>
    <message>
        <source>Unverified payment requests to custom payment scripts are unsupported.</source>
        <translation>Ikke-verificerede betalingsforespørgsler for tilpassede betalings-scripts understøttes ikke.</translation>
    </message>
    <message>
        <source>Refund from %1</source>
        <translation>Tilbagebetaling fra %1</translation>
    </message>
    <message>
        <source>Error communicating with %1: %2</source>
        <translation>Fejl under kommunikation med %1: %2</translation>
    </message>
    <message>
        <source>Payment request can not be parsed or processed!</source>
        <translation>Betalingsanmodning kan ikke fortolkes eller bearbejdes!</translation>
    </message>
    <message>
        <source>Bad response from server %1</source>
        <translation>Fejlagtigt svar fra server %1</translation>
    </message>
    <message>
        <source>Payment acknowledged</source>
        <translation>Betaling anerkendt</translation>
    </message>
    <message>
        <source>Network request error</source>
        <translation>Fejl i netværksforespørgsel</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Beginnercoin</source>
        <translation>Beginnercoin</translation>
    </message>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; does not exist.</source>
        <translation>Fejl: Angivet datamappe &quot;%1&quot; eksisterer ikke.</translation>
    </message>
    <message>
        <source>Error: Cannot parse configuration file: %1. Only use key=value syntax.</source>
        <translation>Fejl: Kan ikke fortolke konfigurationsfil: %1. Brug kun syntaksen nøgle=værdi.</translation>
    </message>
    <message>
        <source>Error: Invalid combination of -regtest and -testnet.</source>
        <translation>Fejl: Ugyldig kombination af -regtest og -testnet.</translation>
    </message>
    <message>
        <source>Beginnercoin Core didn&apos;t yet exit safely...</source>
        <translation>Beginnercoin Core blev ikke afsluttet på sikker vis …</translation>
    </message>
    <message>
        <source>Enter a Beginnercoin address (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Indtast en Beginnercoin-adresse (fx 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>Gem billede …</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation>Kopiér foto</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation>Gem QR-kode</translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation>PNG-billede (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Client name</source>
        <translation>Klientnavn</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Klientversion</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>Fejlsøgningsvindue</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Generelt</translation>
    </message>
    <message>
        <source>Using OpenSSL version</source>
        <translation>Anvender OpenSSL-version</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Opstartstidspunkt</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Netværk</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Antal forbindelser</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Blokkæde</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Nuværende antal blokke</translation>
    </message>
    <message>
        <source>Estimated total blocks</source>
        <translation>Estimeret antal blokke</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Tidsstempel for seneste blok</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>Åbn</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>Konsol</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>Netværkstrafik</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>Ryd</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Totaler</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>Indkommende:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>Udgående:</translation>
    </message>
    <message>
        <source>Build date</source>
        <translation>Byggedato</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>Fejlsøgningslogfil</translation>
    </message>
    <message>
        <source>Open the Beginnercoin debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Åbn Beginnercoin-fejlsøgningslogfilen fra den nuværende datamappe. Dette kan tage nogle få sekunder for store logfiler.</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Ryd konsol</translation>
    </message>
    <message>
        <source>Welcome to the Beginnercoin RPC console.</source>
        <translation>Velkommen til Beginnercoin RPC-konsollen.</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Brug op- og ned-piletasterne til at navigere i historikken og &lt;b&gt;Ctrl-L&lt;/b&gt; til at rydde skærmen.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Tast &lt;b&gt;help&lt;/b&gt; for en oversigt over de tilgængelige kommandoer.</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 m</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 t</translation>
    </message>
    <message>
        <source>%1 h %2 m</source>
        <translation>%1 t %2 m</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>Beløb:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>Mærkat:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>Besked:</translation>
    </message>
    <message>
        <source>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</source>
        <translation>Genbrug en af de tidligere brugte modtagelsesadresser. Genbrug af adresser har indflydelse på sikkerhed og privatliv. Brug ikke dette med mindre du genskaber en betalingsforespørgsel fra tidligere.</translation>
    </message>
    <message>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation>Genbrug en eksisterende modtagelsesadresse (anbefales ikke)</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Beginnercoin network.</source>
        <translation>En valgfri besked, der føjes til betalingsanmodningen, og som vil vises, når anmodningen åbnes. Bemærk: Beskeden vil ikke sendes med betalingen over Beginnercoin-netværket.</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation>Et valgfrit mærkat, der associeres med den nye modtagelsesadresse.</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>Brug denne formular for at anmode om betalinger. Alle felter er &lt;b&gt;valgfri&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation>Et valgfrit beløb til anmodning. Lad dette felt være tomt eller indeholde nul for at anmode om et ikke-specifikt beløb.</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Ryd alle felter af formen.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Ryd</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>Historik over betalingsanmodninger</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>Anmod om betaling</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation>Vis den valgte forespørgsel (gør det samme som dobbeltklik på en indgang)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Vis</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation>Fjern de valgte indgange fra listen</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopiér mærkat</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>Kopiér besked</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopier beløb</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR-kode</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>Kopiér URI</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>Kopiér adresse</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>Gem billede …</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation>Anmod om betaling til %1</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>Betalingsinformation</translation>
    </message>
    <message>
        <source>URI</source>
        <translation>URI</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Beløb</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Mærkat</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Besked</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>Resulterende URI var for lang; prøv at forkorte teksten til mærkaten/beskeden.</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation>Fejl ved kodning fra URI til QR-kode.</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Mærkat</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Besked</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Beløb</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(ingen mærkat)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>(ingen besked)</translation>
    </message>
    <message>
        <source>(no amount)</source>
        <translation>(intet beløb)</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Send beginnercoins</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>Egenskaber for coin-styring</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>Inputs …</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>valgt automatisk</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Utilstrækkelige midler!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Mængde:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Byte:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Beløb:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Prioritet:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Gebyr:</translation>
    </message>
    <message>
        <source>Low Output:</source>
        <translation>Lavt output:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Efter gebyr:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Byttepenge:</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation>Hvis dette aktiveres, men byttepengeadressen er tom eller ugyldig, vil byttepenge blive sendt til en nygenereret adresse.</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation>Tilpasset byttepengeadresse</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Send til flere modtagere på en gang</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>Tilføj modtager</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Ryd alle felter af formen.</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Ryd alle</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Saldo:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Bekræft afsendelsen</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>Afsend</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Bekræft afsendelse af beginnercoins</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation>%1 til %2</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Kopiér mængde</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopier beløb</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Kopiér gebyr</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Kopiér efter-gebyr</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Kopiér byte</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>Kopiér prioritet</translation>
    </message>
    <message>
        <source>Copy low output</source>
        <translation>Kopiér lavt output</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Kopiér byttepenge</translation>
    </message>
    <message>
        <source>Total Amount %1 (= %2)</source>
        <translation>Totalbeløb %1 (= %2)</translation>
    </message>
    <message>
        <source>or</source>
        <translation>eller</translation>
    </message>
    <message>
        <source>The recipient address is not valid, please recheck.</source>
        <translation>Modtagerens adresse er ikke gyldig. Tjek venligst adressen igen.</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Beløbet til betaling skal være større end 0.</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>Beløbet overstiger din saldo.</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>Totalen overstiger din saldo, når transaktionsgebyret på %1 er inkluderet.</translation>
    </message>
    <message>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation>Duplikeret adresse fundet. Du kan kun sende til hver adresse én gang pr. afsendelse.</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation>Oprettelse af transaktion mislykkedes!</translation>
    </message>
    <message>
        <source>The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Transaktionen blev afvist! Dette kan ske, hvis nogle af dine beginnercoins i din tegnebog allerede er brugt, som hvis du brugte en kopi af wallet.dat og dine beginnercoins er blevet brugt i kopien, men ikke er markeret som brugt her.</translation>
    </message>
    <message>
        <source>Warning: Invalid Beginnercoin address</source>
        <translation>Advarsel: Ugyldig Beginnercoin-adresse</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(ingen mærkat)</translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation>Advarsel: Ukendt byttepengeadresse</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>Er du sikker på, at du vil sende?</translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation>tilføjet som transaktionsgebyr</translation>
    </message>
    <message>
        <source>Payment request expired</source>
        <translation>Betalingsforespørgsel udløbet</translation>
    </message>
    <message>
        <source>Invalid payment address %1</source>
        <translation>Ugyldig betalingsadresse %1</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>Beløb:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>Betal til:</translation>
    </message>
    <message>
        <source>The address to send the payment to (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Beginnercoin-adressen som betalingen skal sendes til (fx 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Indtast en mærkat for denne adresse for at føje den til din adressebog</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>Mærkat:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Vælg tidligere brugt adresse</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>Dette er en normal betaling.</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Indsæt adresse fra udklipsholderen</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>Fjern denne indgang</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Besked:</translation>
    </message>
    <message>
        <source>This is a verified payment request.</source>
        <translation>Dette er en verificeret betalingsforespørgsel.</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation>Indtast et mærkat for denne adresse for at føje den til listen over brugte adresser</translation>
    </message>
    <message>
        <source>A message that was attached to the beginnercoin: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Beginnercoin network.</source>
        <translation>En besked, som blev føjet til &quot;bitcon:&quot;-URI&apos;en, som vil gemmes med transaktionen til din reference. Bemærk: Denne besked vil ikke blive sendt over Beginnercoin-netværket.</translation>
    </message>
    <message>
        <source>This is an unverified payment request.</source>
        <translation>Dette er en ikke-verificeret betalingsforespørgsel.</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Betal til:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>Memo:</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>Beginnercoin Core is shutting down...</source>
        <translation>Beginnercoin Core lukker ned …</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>Luk ikke computeren ned, før dette vindue forsvinder.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Signature - Underskriv/verificér en besked</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>Underskriv besked</translation>
    </message>
    <message>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Du kan underskrive beskeder med dine Beginnercoin-adresser for at bevise, at de tilhører dig. Pas på ikke at underskrive noget vagt, da phisingangreb kan narre dig til at overdrage din identitet. Underskriv kun fuldt detaljerede udsagn, du er enig i.</translation>
    </message>
    <message>
        <source>The address to sign the message with (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Beginnercoin-adressen som beskeden skal underskrives med (fx 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Vælg tidligere brugt adresse</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Indsæt adresse fra udklipsholderen</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Indtast her beskeden, du ønsker at underskrive</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Underskrift</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Kopiér den nuværende underskrift til systemets udklipsholder</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Beginnercoin address</source>
        <translation>Underskriv denne besked for at bevise, at Beginnercoin-adressen tilhører dig</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>Underskriv besked</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Nulstil alle &quot;underskriv besked&quot;-felter</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Ryd alle</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>Verificér besked</translation>
    </message>
    <message>
        <source>Enter the signing address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack.</source>
        <translation>Indtast herunder den underskrivende adresse, beskeden (inkludér linjeskift, mellemrum mv. nøjagtigt, som de fremgår) og underskriften for at verificere beskeden. Vær forsigtig med ikke at lægge mere i underskriften end besked selv, så du undgår at blive narret af et man-in-the-middle-angreb.</translation>
    </message>
    <message>
        <source>The address the message was signed with (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Beginnercoin-adressen som beskeden er underskrevet med (fx 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Beginnercoin address</source>
        <translation>Verificér beskeden for at sikre, at den er underskrevet med den angivne Beginnercoin-adresse</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>Verificér besked</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Nulstil alle &quot;verificér besked&quot;-felter</translation>
    </message>
    <message>
        <source>Enter a Beginnercoin address (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Indtast en Beginnercoin-adresse (fx 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <source>Click &quot;Sign Message&quot; to generate signature</source>
        <translation>Klik &quot;Underskriv besked&quot; for at generere underskriften</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>Den indtastede adresse er ugyldig.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>Tjek venligst adressen og forsøg igen.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>Den indtastede adresse henviser ikke til en nøgle.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>Tegnebogsoplåsning annulleret.</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>Den private nøgle for den indtastede adresse er ikke tilgængelig.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation>Underskrivning af besked mislykkedes.</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>Besked underskrevet.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>Underskriften kunne ikke afkodes.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>Tjek venligst underskriften, og forsøg igen.</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation>Underskriften matcher ikke beskedens indhold.</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation>Verificering af besked mislykkedes.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>Besked verificeret.</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>Beginnercoin Core</source>
        <translation>Beginnercoin Core</translation>
    </message>
    <message>
        <source>The Beginnercoin Core developers</source>
        <translation>Udviklerne af Beginnercoin Core</translation>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[testnetværk]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>Åben indtil %1</translation>
    </message>
    <message>
        <source>conflicted</source>
        <translation>konflikt</translation>
    </message>
    <message>
        <source>%1/offline</source>
        <translation>%1/offline</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/ubekræftet</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 bekræftelser</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message numerus="yes">
        <source>, broadcast through %n node(s)</source>
        <translation><numerusform>, transmitteret igennem %n knude</numerusform><numerusform>, transmitteret igennem %n knuder</numerusform></translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Kilde</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>Genereret</translation>
    </message>
    <message>
        <source>From</source>
        <translation>Fra</translation>
    </message>
    <message>
        <source>To</source>
        <translation>Til</translation>
    </message>
    <message>
        <source>own address</source>
        <translation>egen adresse</translation>
    </message>
    <message>
        <source>label</source>
        <translation>mærkat</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation>Kredit</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation><numerusform>modner efter yderligere %n blok</numerusform><numerusform>modner efter yderligere %n blokke</numerusform></translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation>ikke accepteret</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>Debet</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>Transaktionsgebyr</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation>Nettobeløb</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Besked</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation>Transaktions-ID</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation>Forretningsdrivende</translation>
    </message>
    <message>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to &quot;not accepted&quot; and it won&apos;t be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>Udvundne beginnercoins skal modne %1 blokke, før de kan bruges. Da du genererede denne blok, blev den udsendt til netværket for at blive føjet til blokkæden. Hvis det ikke lykkes at få den i kæden, vil dens tilstand ændres til &quot;ikke accepteret&quot;, og den vil ikke kunne bruges. Dette kan ske nu og da, hvis en anden knude udvinder en blok inden for nogle få sekunder fra din.</translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation>Fejlsøgningsinformation</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation>Transaktion</translation>
    </message>
    <message>
        <source>Inputs</source>
        <translation>Input</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Beløb</translation>
    </message>
    <message>
        <source>true</source>
        <translation>sand</translation>
    </message>
    <message>
        <source>false</source>
        <translation>falsk</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>, er ikke blevet transmitteret endnu</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation><numerusform>Åbn yderligere %n blok</numerusform><numerusform>Åbn yderligere %n blokke</numerusform></translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>ukendt</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>Transaktionsdetaljer</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Denne rude viser en detaljeret beskrivelse af transaktionen</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Beløb</translation>
    </message>
    <message>
        <source>Immature (%1 confirmations, will be available after %2)</source>
        <translation>Umoden (%1 bekræftelser; vil være tilgængelig efter %2)</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation><numerusform>Åbn yderligere %n blok</numerusform><numerusform>Åbn yderligere %n blokke</numerusform></translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Åben indtil %1</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Bekræftet (%1 bekræftelser)</translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Denne blok blev ikke modtaget af nogen andre knuder og vil formentlig ikke blive accepteret!</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Genereret, men ikke accepteret</translation>
    </message>
    <message>
        <source>Offline</source>
        <translation>Offline</translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation>Ubekræftet</translation>
    </message>
    <message>
        <source>Confirming (%1 of %2 recommended confirmations)</source>
        <translation>Bekræfter (%1 af %2 anbefalede bekræftelser)</translation>
    </message>
    <message>
        <source>Conflicted</source>
        <translation>Konflikt</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Modtaget med</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Modtaget fra</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Sendt til</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Betaling til dig selv</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Udvundne</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(n/a)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Transaktionsstatus. Hold musen over dette felt for at vise antallet af bekræftelser.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Dato og klokkeslæt for modtagelse af transaktionen.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Transaktionstype.</translation>
    </message>
    <message>
        <source>Destination address of transaction.</source>
        <translation>Destinationsadresse for transaktion.</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Beløb trukket fra eller tilføjet balance.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>I dag</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>Denne uge</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>Denne måned</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Sidste måned</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>Dette år</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Interval …</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Modtaget med</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Sendt til</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>Til dig selv</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Udvundne</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Andet</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Indtast adresse eller mærkat for at søge</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Minimumsbeløb</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopiér adresse</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopiér mærkat</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopiér beløb</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Kopiér transaktions-ID</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Redigér mærkat</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>Vis transaktionsdetaljer</translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation>Historik for eksport af transaktioner</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Eksport mislykkedes</translation>
    </message>
    <message>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation>En fejl opstod under gemning af transaktionshistorik til %1.</translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation>Eksport problemfri</translation>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation>Transaktionshistorikken blev gemt til %1 med succes.</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Kommasepareret fil (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Bekræftet</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Mærkat</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Beløb</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Interval:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>til</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.</source>
        <translation>Ingen tegnebog er indlæst.</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>Send beginnercoins</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>Eksportér</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Eksportér den aktuelle visning til en fil</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>Sikkerhedskopiér tegnebog</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>Tegnebogsdata (*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>Sikkerhedskopiering mislykkedes</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation>Der skete en fejl under gemning af tegnebogsdata til %1.</translation>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation>Tegnebogsdata blev gemt til %1 med succes.</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation>Sikkerhedskopiering problemfri</translation>
    </message>
</context>
<context>
    <name>beginnercoin-core</name>
    <message>
        <source>Usage:</source>
        <translation>Anvendelse:</translation>
    </message>
    <message>
        <source>List commands</source>
        <translation>Liste over kommandoer</translation>
    </message>
    <message>
        <source>Get help for a command</source>
        <translation>Få hjælp til en kommando</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Indstillinger:</translation>
    </message>
    <message>
        <source>Specify configuration file (default: beginnercoin.conf)</source>
        <translation>Angiv konfigurationsfil (standard: beginnercoin.conf)</translation>
    </message>
    <message>
        <source>Specify pid file (default: beginnercoind.pid)</source>
        <translation>Angiv pid-fil (default: beginnercoind.pid)</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Angiv datamappe</translation>
    </message>
    <message>
        <source>Listen for connections on &lt;port&gt; (default: 9844 or testnet: 19844)</source>
        <translation>Lyt til forbindelser på &lt;port&gt; (standard: 9844 eller testnetværk: 19844)</translation>
    </message>
    <message>
        <source>Maintain at most &lt;n&gt; connections to peers (default: 125)</source>
        <translation>Oprethold højest &lt;n&gt; forbindelser til andre i netværket (standard: 125)</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Forbind til en knude for at modtage adresser på andre knuder, og afbryd derefter</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>Angiv din egen offentlige adresse</translation>
    </message>
    <message>
        <source>Threshold for disconnecting misbehaving peers (default: 100)</source>
        <translation>Grænse for afbrydelse til dårlige forbindelser (standard: 100)</translation>
    </message>
    <message>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: 86400)</source>
        <translation>Antal sekunder dårlige forbindelser skal vente før reetablering (standard: 86400)</translation>
    </message>
    <message>
        <source>An error occurred while setting up the RPC port %u for listening on IPv4: %s</source>
        <translation>Der opstod en fejl ved angivelse af RPC-porten %u til at lytte på IPv4: %s</translation>
    </message>
    <message>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: 9744 or testnet: 19744)</source>
        <translation>Lyt til JSON-RPC-forbindelser på &lt;port&gt; (standard: 9744 eller testnetværk: 19744)</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Acceptér kommandolinje- og JSON-RPC-kommandoer</translation>
    </message>
    <message>
        <source>Beginnercoin Core RPC client version</source>
        <translation>Beginnercoin Core RPC-klient-version</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Kør i baggrunden som en service, og acceptér kommandoer</translation>
    </message>
    <message>
        <source>Use the test network</source>
        <translation>Brug testnetværket</translation>
    </message>
    <message>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation>Acceptér forbindelser udefra (standard: 1 hvis hverken -proxy eller -connect)</translation>
    </message>
    <message>
        <source>%s, you must set a rpcpassword in the configuration file:
%s
It is recommended you use the following random password:
rpcuser=beginnercoinrpc
rpcpassword=%s
(you do not need to remember this password)
The username and password MUST NOT be the same.
If the file does not exist, create it with owner-readable-only file permissions.
It is also recommended to set alertnotify so you are notified of problems;
for example: alertnotify=echo %%s | mail -s &quot;Beginnercoin Alert&quot; admin@foo.com
</source>
        <translation>%s, du skal angive en RPC-adgangskode i konfigurationsfilen:
%s
Det anbefales, at du bruger nedenstående, tilfældige adgangskode:
rpcuser=beginnercoinrpc
rpcpassword=%s
(du behøver ikke huske denne adgangskode)
Brugernavnet og adgangskode MÅ IKKE være det samme.
Hvis filen ikke eksisterer, opret den og giv ingen andre end ejeren læserettighed.
Det anbefales også at angive alertnotify, så du påmindes om problemer;
fx: alertnotify=echo %%s | mail -s &quot;Beginnercoin Alert&quot; admin@foo.com
</translation>
    </message>
    <message>
        <source>Acceptable ciphers (default: TLSv1.2+HIGH:TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!3DES:@STRENGTH)</source>
        <translation>Accepterede krypteringer (standard: TLSv1.2+HIGH:TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!3DES:@STRENGTH)</translation>
    </message>
    <message>
        <source>An error occurred while setting up the RPC port %u for listening on IPv6, falling back to IPv4: %s</source>
        <translation>Der opstod en fejl ved angivelse af RPC-porten %u til at lytte på IPv6, falder tilbage til IPv4: %s</translation>
    </message>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>Tildel til den givne adresse og lyt altid på den. Brug [vært]:port-notation for IPv6</translation>
    </message>
    <message>
        <source>Continuously rate-limit free transactions to &lt;n&gt;*1000 bytes per minute (default:15)</source>
        <translation>Rate-begræns kontinuerligt frie transaktioner til &lt;n&gt;*1000 byte i minuttet (standard:15)</translation>
    </message>
    <message>
        <source>Enter regression test mode, which uses a special chain in which blocks can be solved instantly. This is intended for regression testing tools and app development.</source>
        <translation>Start regressionstesttilstand, som bruger en speciel kæde, hvor blokke kan løses med det samme. Dette er tiltænkt til testværktøjer for regression of programudvikling.</translation>
    </message>
    <message>
        <source>Enter regression test mode, which uses a special chain in which blocks can be solved instantly.</source>
        <translation>Start regressionstesttilstand, som bruger en speciel kæde, hvor blokke kan løses med det samme.</translation>
    </message>
    <message>
        <source>Error: Listening for incoming connections failed (listen returned error %d)</source>
        <translation>Fejl: Lytning efter indkommende forbindelser mislykkedes (lytning returnerede fejl %d)</translation>
    </message>
    <message>
        <source>Error: The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Fejl: Transaktionen blev afvist. Dette kan ske, hvis nogle af dine beginnercoins i din tegnebog allerede er brugt, som hvis du brugte en kopi af wallet.dat og dine beginnercoins er blevet brugt i kopien, men ikke er markeret som brugt her.</translation>
    </message>
    <message>
        <source>Error: This transaction requires a transaction fee of at least %s because of its amount, complexity, or use of recently received funds!</source>
        <translation>Fejl: Denne transaktion kræver et transaktionsgebyr på minimum %s pga. dens beløb, kompleksitet eller anvendelse af nyligt modtagne beginnercoins!</translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation>Udfør kommando, når en transaktion i tegnebogen ændres (%s i kommandoen erstattes med TxID)</translation>
    </message>
    <message>
        <source>Fees smaller than this are considered zero fee (for transaction creation) (default:</source>
        <translation>Gebyrer mindre end dette opfattes som nul-gebyr (for oprettelse af transaktioner) (standard:</translation>
    </message>
    <message>
        <source>Flush database activity from memory pool to disk log every &lt;n&gt; megabytes (default: 100)</source>
        <translation>Flyt databaseaktivitet fra hukommelsespulje til disklog hver &lt;n&gt; megabytes (standard: 100)</translation>
    </message>
    <message>
        <source>How thorough the block verification of -checkblocks is (0-4, default: 3)</source>
        <translation>Hvor gennemarbejdet blokverificeringen for -checkblocks er (0-4; standard: 3)</translation>
    </message>
    <message>
        <source>In this mode -genproclimit controls how many blocks are generated immediately.</source>
        <translation>I denne tilstand styrer -genproclimit hvor mange blokke, der genereres med det samme.</translation>
    </message>
    <message>
        <source>Set the number of script verification threads (%u to %d, 0 = auto, &lt;0 = leave that many cores free, default: %d)</source>
        <translation>Sæt antallet af scriptverificeringstråde (%u til %d, 0 = auto, &lt;0 = efterlad det antal kernet fri, standard: %d)</translation>
    </message>
    <message>
        <source>Set the processor limit for when generation is on (-1 = unlimited, default: -1)</source>
        <translation>Sæt processorbegrænsning for når generering er slået til (-1 = ubegrænset, standard: -1)</translation>
    </message>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation>Dette er en foreløbig testudgivelse - brug på eget ansvar - brug ikke til udvinding eller handelsprogrammer</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer. Beginnercoin Core is probably already running.</source>
        <translation>Ikke i stand til at tildele til %s på denne computer. Beginnercoin Core kører sansynligvis allerede.</translation>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services (default: -proxy)</source>
        <translation>Brug separat SOCS5-proxy for at nå andre knuder via Tor skjulte tjenester (standard: -proxy)</translation>
    </message>
    <message>
        <source>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Advarsel: -paytxfee er sat meget højt! Dette er det gebyr du vil betale, hvis du sender en transaktion.</translation>
    </message>
    <message>
        <source>Warning: Please check that your computer&apos;s date and time are correct! If your clock is wrong Beginnercoin will not work properly.</source>
        <translation>Advarsel: Undersøg venligst, at din computers dato og klokkeslæt er korrekt indstillet! Hvis der er fejl i disse, vil Beginnercoin ikke fungere korrekt.</translation>
    </message>
    <message>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation>Advarsel: Netværket ser ikke ud til at være fuldt ud enige! Enkelte minere ser ud til at opleve problemer.</translation>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation>Advarsel: Vi ser ikke ud til at være fuldt ud enige med andre noder! Du kan være nødt til at opgradere, eller andre noder kan være nødt til at opgradere.</translation>
    </message>
    <message>
        <source>Warning: error reading wallet.dat! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>Advarsel: fejl under læsning af wallet.dat! Alle nøgler blev læst korrekt, men transaktionsdata eller adressebogsposter kan mangle eller være forkerte.</translation>
    </message>
    <message>
        <source>Warning: wallet.dat corrupt, data salvaged! Original wallet.dat saved as wallet.{timestamp}.bak in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>Advarsel: wallet.dat ødelagt, data reddet! Oprindelig wallet.dat gemt som wallet.{timestamp}.bak i %s; hvis din saldo eller dine transaktioner er forkert, bør du genskabe fra en sikkerhedskopi.</translation>
    </message>
    <message>
        <source>(default: 1)</source>
        <translation>(standard: 1)</translation>
    </message>
    <message>
        <source>(default: wallet.dat)</source>
        <translation>(standard: wallet.dat)</translation>
    </message>
    <message>
        <source>&lt;category&gt; can be:</source>
        <translation>&lt;kategori&gt; kan være:</translation>
    </message>
    <message>
        <source>Attempt to recover private keys from a corrupt wallet.dat</source>
        <translation>Forsøg at genskabe private nøgler fra ødelagt wallet.dat</translation>
    </message>
    <message>
        <source>Beginnercoin Core Daemon</source>
        <translation>Beginnercoin Core-tjeneste</translation>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation>Blokoprettelsestilvalg:</translation>
    </message>
    <message>
        <source>Clear list of wallet transactions (diagnostic tool; implies -rescan)</source>
        <translation>Ryd liste over transaktioner i tegnebog (diagnoseværktøj; medfører -rescan)</translation>
    </message>
    <message>
        <source>Connect only to the specified node(s)</source>
        <translation>Tilslut kun til de(n) angivne knude(r)</translation>
    </message>
    <message>
        <source>Connect through SOCKS proxy</source>
        <translation>Forbind gennem SOCKS-proxy</translation>
    </message>
    <message>
        <source>Connect to JSON-RPC on &lt;port&gt; (default: 9744 or testnet: 19744)</source>
        <translation>Forbind til JSON-RPC på &lt;port&gt; (standard: 9744 eller testnetværk: 19744)</translation>
    </message>
    <message>
        <source>Connection options:</source>
        <translation>Tilvalg for forbindelser:</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>Ødelagt blokdatabase opdaget</translation>
    </message>
    <message>
        <source>Debugging/Testing options:</source>
        <translation>Tilvalg for fejlfinding/test:</translation>
    </message>
    <message>
        <source>Disable safemode, override a real safe mode event (default: 0)</source>
        <translation>Slå sikker tilstand fra, tilsidesæt hændelser fra sikker tilstand (standard: 0)</translation>
    </message>
    <message>
        <source>Discover own IP address (default: 1 when listening and no -externalip)</source>
        <translation>Find egen IP-adresse (standard: 1 når lytter og ingen -externalip)</translation>
    </message>
    <message>
        <source>Do not load the wallet and disable wallet RPC calls</source>
        <translation>Indlæs ikke tegnebogen og slå tegnebogs-RPC-kald fra</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Ønsker du at genbygge blokdatabasen nu?</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>Klargøring af blokdatabase mislykkedes</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>Klargøring af tegnebogsdatabasemiljøet %s mislykkedes!</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>Indlæsning af blokdatabase mislykkedes</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>Åbning af blokdatabase mislykkedes</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Fejl: Mangel på ledig diskplads!</translation>
    </message>
    <message>
        <source>Error: Wallet locked, unable to create transaction!</source>
        <translation>Fejl: Tegnebog låst, kan ikke oprette transaktion!</translation>
    </message>
    <message>
        <source>Error: system error: </source>
        <translation>Fejl: systemfejl: </translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Lytning på enhver port mislykkedes. Brug -listen=0, hvis du ønsker dette.</translation>
    </message>
    <message>
        <source>Failed to read block info</source>
        <translation>Læsning af blokinformation mislykkedes</translation>
    </message>
    <message>
        <source>Failed to read block</source>
        <translation>Læsning af blok mislykkedes</translation>
    </message>
    <message>
        <source>Failed to sync block index</source>
        <translation>Synkronisering af blokindeks mislykkedes</translation>
    </message>
    <message>
        <source>Failed to write block index</source>
        <translation>Skrivning af blokindeks mislykkedes</translation>
    </message>
    <message>
        <source>Failed to write block info</source>
        <translation>Skrivning af blokinformation mislykkedes</translation>
    </message>
    <message>
        <source>Failed to write block</source>
        <translation>Skrivning af blok mislykkedes</translation>
    </message>
    <message>
        <source>Failed to write file info</source>
        <translation>Skriving af filinformation mislykkedes</translation>
    </message>
    <message>
        <source>Failed to write to coin database</source>
        <translation>Skrivning af beginnercoin-database mislykkedes</translation>
    </message>
    <message>
        <source>Failed to write transaction index</source>
        <translation>Skrivning af transaktionsindeks mislykkedes</translation>
    </message>
    <message>
        <source>Failed to write undo data</source>
        <translation>Skrivning af genskabelsesdata mislykkedes</translation>
    </message>
    <message>
        <source>Fee per kB to add to transactions you send</source>
        <translation>Føj gebyr pr. kB til transaktioner, du sender</translation>
    </message>
    <message>
        <source>Fees smaller than this are considered zero fee (for relaying) (default:</source>
        <translation>Gebyrer mindre end dette opfattes som nul-gebyr (for videreførsler) (standard:</translation>
    </message>
    <message>
        <source>Find peers using DNS lookup (default: 1 unless -connect)</source>
        <translation>Find andre knuder ved DNS-opslag (standard: 1 hvis ikke -connect)</translation>
    </message>
    <message>
        <source>Force safe mode (default: 0)</source>
        <translation>Gennemtving sikker tilstand (standard: 0)</translation>
    </message>
    <message>
        <source>Generate coins (default: 0)</source>
        <translation>Generér beginnercoins (standard: 0)</translation>
    </message>
    <message>
        <source>How many blocks to check at startup (default: 288, 0 = all)</source>
        <translation>Antal blokke som tjekkes ved opstart (standard: 288, 0=alle)</translation>
    </message>
    <message>
        <source>If &lt;category&gt; is not supplied, output all debugging information.</source>
        <translation>Hvis &lt;kategori&gt; ikke angives, udskriv al fejlsøgningsinformation.</translation>
    </message>
    <message>
        <source>Importing...</source>
        <translation>Importerer …</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>Ukorrekt eller ingen tilblivelsesblok fundet. Forkert datamappe for netværk?</translation>
    </message>
    <message>
        <source>Invalid -onion address: &apos;%s&apos;</source>
        <translation>Ugyldig -onion adresse: &quot;%s&quot;</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>For få tilgængelige fildeskriptorer.</translation>
    </message>
    <message>
        <source>Prepend debug output with timestamp (default: 1)</source>
        <translation>Føj tidsstempel foran fejlsøgningsoutput (standard: 1)</translation>
    </message>
    <message>
        <source>RPC client options:</source>
        <translation>Tilvalg for RPC-klient:</translation>
    </message>
    <message>
        <source>Rebuild block chain index from current blk000??.dat files</source>
        <translation>Genbyg blokkædeindeks fra nuværende blk000??.dat filer</translation>
    </message>
    <message>
        <source>Select SOCKS version for -proxy (4 or 5, default: 5)</source>
        <translation>Vælg SOCKS-version for -proxy (4 eller 5, standard: 5)</translation>
    </message>
    <message>
        <source>Set database cache size in megabytes (%d to %d, default: %d)</source>
        <translation>Sæt cache-størrelse for database i megabytes (%d til %d; standard: %d)</translation>
    </message>
    <message>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation>Sæt maksimum blokstørrelse i byte (standard: %d)</translation>
    </message>
    <message>
        <source>Set the number of threads to service RPC calls (default: 4)</source>
        <translation>Angiv antallet af tråde til at håndtere RPC-kald (standard: 4)</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>Angiv tegnebogsfil (inden for datamappe)</translation>
    </message>
    <message>
        <source>Spend unconfirmed change when sending transactions (default: 1)</source>
        <translation>Brug ubekræftede byttepenge under afsendelse af transaktioner (standard: 1)</translation>
    </message>
    <message>
        <source>This is intended for regression testing tools and app development.</source>
        <translation>This is intended for regression testing tools and app development.</translation>
    </message>
    <message>
        <source>Usage (deprecated, use beginnercoin-cli):</source>
        <translation>Brug (forældet, brug beginnercoin-cli):</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>Verificerer blokke …</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>Verificerer tegnebog …</translation>
    </message>
    <message>
        <source>Wait for RPC server to start</source>
        <translation>Vent på opstart af RPC-server</translation>
    </message>
    <message>
        <source>Wallet %s resides outside data directory %s</source>
        <translation>Tegnebog %1 findes uden for datamappe %s</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>Tilvalg for tegnebog:</translation>
    </message>
    <message>
        <source>Warning: Deprecated argument -debugnet ignored, use -debug=net</source>
        <translation>Advarsel: Forældet argument -debugnet ignoreret; brug -debug=net</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to change -txindex</source>
        <translation>Du er nødt til at genopbygge databasen ved hjælp af -reindex for at ændre -txindex</translation>
    </message>
    <message>
        <source>Imports blocks from external blk000??.dat file</source>
        <translation>Importerer blokke fra ekstern blk000??.dat fil</translation>
    </message>
    <message>
        <source>Cannot obtain a lock on data directory %s. Beginnercoin Core is probably already running.</source>
        <translation>Kan ikke opnå en lås på datamappe %s. Beginnercoin Core kører sansynligvis allerede.</translation>
    </message>
    <message>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation>Udfør kommando, når en relevant alarm modtages eller vi ser en virkelig lang udsplitning (%s i cmd erstattes af besked)</translation>
    </message>
    <message>
        <source>Output debugging information (default: 0, supplying &lt;category&gt; is optional)</source>
        <translation>Udskriv fejlsøgningsinformation (standard: 0, angivelse af &lt;kategori&gt; er valgfri)</translation>
    </message>
    <message>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: %d)</source>
        <translation>Sæt maksimumstørrelse for højprioritet/lavgebyr-transaktioner i byte (standard: %d)</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <source>Invalid amount for -minrelaytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Ugyldigt beløb til -minrelaytxfee=&lt;beløb&gt;: &quot;%s&quot;</translation>
    </message>
    <message>
        <source>Invalid amount for -mintxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Ugyldigt beløb til -mintxfee=&lt;beløb&gt;: &quot;%s&quot;</translation>
    </message>
    <message>
        <source>Limit size of signature cache to &lt;n&gt; entries (default: 50000)</source>
        <translation>Begræns størrelsen på signaturcache til &lt;n&gt; indgange (standard: 50000)</translation>
    </message>
    <message>
        <source>Log transaction priority and fee per kB when mining blocks (default: 0)</source>
        <translation>Prioritet for transaktionslog og gebyr pr. kB under udvinding af blokke (standard: 0)</translation>
    </message>
    <message>
        <source>Maintain a full transaction index (default: 0)</source>
        <translation>Vedligehold et komplet transaktionsindeks (standard: 0)</translation>
    </message>
    <message>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: 5000)</source>
        <translation>Maksimum for modtagelsesbuffer pr. forbindelse, &lt;n&gt;*1000 byte (standard: 5000)</translation>
    </message>
    <message>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: 1000)</source>
        <translation>Maksimum for afsendelsesbuffer pr. forbindelse, &lt;n&gt;*1000 byte (standard: 1000)</translation>
    </message>
    <message>
        <source>Only accept block chain matching built-in checkpoints (default: 1)</source>
        <translation>Acceptér kun blokkæde, som matcher indbyggede kontrolposter (standard: 1)</translation>
    </message>
    <message>
        <source>Only connect to nodes in network &lt;net&gt; (IPv4, IPv6 or Tor)</source>
        <translation>Tilslut kun til knuder i netværk &lt;net&gt; (IPv4, IPv6 eller Tor)</translation>
    </message>
    <message>
        <source>Print block on startup, if found in block index</source>
        <translation>Udskriv blok under opstart, hvis den findes i blokindeks</translation>
    </message>
    <message>
        <source>Print block tree on startup (default: 0)</source>
        <translation>Udskriv bloktræ under startop (standard: 0)</translation>
    </message>
    <message>
        <source>RPC SSL options: (see the Beginnercoin Wiki for SSL setup instructions)</source>
        <translation>Tilvalg for RPC SSL: (se Beginnercoin Wiki for instruktioner i SSL-opstart)</translation>
    </message>
    <message>
        <source>RPC server options:</source>
        <translation>Tilvalg for RPC-server:</translation>
    </message>
    <message>
        <source>Randomly drop 1 of every &lt;n&gt; network messages</source>
        <translation>Drop tilfældigt 1 ud af hver &lt;n&gt; netværksbeskeder</translation>
    </message>
    <message>
        <source>Randomly fuzz 1 of every &lt;n&gt; network messages</source>
        <translation>Slør tilfældigt 1 ud af hver &lt;n&gt; netværksbeskeder</translation>
    </message>
    <message>
        <source>Run a thread to flush wallet periodically (default: 1)</source>
        <translation>Kør en tråd for at rydde tegnebog periodisk (standard: 1)</translation>
    </message>
    <message>
        <source>SSL options: (see the Beginnercoin Wiki for SSL setup instructions)</source>
        <translation>SSL-indstillinger: (se Beginnercoin Wiki for SSL-opsætningsinstruktioner)</translation>
    </message>
    <message>
        <source>Send command to Beginnercoin Core</source>
        <translation>Send kommando til Beginnercoin Core</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Send sporings-/fejlsøgningsinformation til konsollen i stedet for debug.log filen</translation>
    </message>
    <message>
        <source>Set minimum block size in bytes (default: 0)</source>
        <translation>Angiv minimumsblokstørrelse i byte (standard: 0)</translation>
    </message>
    <message>
        <source>Sets the DB_PRIVATE flag in the wallet db environment (default: 1)</source>
        <translation>Sætter DB_PRIVATE-flaget i tegnebogens db-miljø (standard: 1)</translation>
    </message>
    <message>
        <source>Show all debugging options (usage: --help -help-debug)</source>
        <translation>Vis alle tilvalg for fejlsøgning (brug: --help -help-debug)</translation>
    </message>
    <message>
        <source>Show benchmark information (default: 0)</source>
        <translation>Vis information om ydelsesmåling (standard: 0)</translation>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>Formindsk debug.log filen ved klientopstart (standard: 1 hvis ikke -debug)</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>Underskrift af transaktion mislykkedes</translation>
    </message>
    <message>
        <source>Specify connection timeout in milliseconds (default: 5000)</source>
        <translation>Angiv tilslutningstimeout i millisekunder (standard: 5000)</translation>
    </message>
    <message>
        <source>Start Beginnercoin Core Daemon</source>
        <translation>Start Beginnercoin Core-tjeneste</translation>
    </message>
    <message>
        <source>System error: </source>
        <translation>Systemfejl: </translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>Transaktionsbeløb er for lavt</translation>
    </message>
    <message>
        <source>Transaction amounts must be positive</source>
        <translation>Transaktionsbeløb skal være positive</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>Transaktionen er for stor</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 0)</source>
        <translation>Brug UPnP til at konfigurere den lyttende port (standard: 0)</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 1 when listening)</source>
        <translation>Brug UPnP til at konfigurere den lyttende port (standard: 1 under lytning)</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Brugernavn til JSON-RPC-forbindelser</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <source>Warning: This version is obsolete, upgrade required!</source>
        <translation>Advarsel: Denne version er forældet, opgradering påkrævet!</translation>
    </message>
    <message>
        <source>Zapping all transactions from wallet...</source>
        <translation>Zapper alle transaktioner fra tegnebog …</translation>
    </message>
    <message>
        <source>on startup</source>
        <translation>under opstart</translation>
    </message>
    <message>
        <source>version</source>
        <translation>version</translation>
    </message>
    <message>
        <source>wallet.dat corrupt, salvage failed</source>
        <translation>wallet.dat ødelagt, redning af data mislykkedes</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Adgangskode til JSON-RPC-forbindelser</translation>
    </message>
    <message>
        <source>Allow JSON-RPC connections from specified IP address</source>
        <translation>Tillad JSON-RPC-forbindelser fra bestemt IP-adresse</translation>
    </message>
    <message>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</source>
        <translation>Send kommandoer til knude, der kører på &lt;ip&gt; (standard: 127.0.0.1)</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>Udfør kommando, når den bedste blok ændres (%s i kommandoen erstattes med blokhash)</translation>
    </message>
    <message>
        <source>Upgrade wallet to latest format</source>
        <translation>Opgrader tegnebog til seneste format</translation>
    </message>
    <message>
        <source>Set key pool size to &lt;n&gt; (default: 100)</source>
        <translation>Angiv nøglepoolstørrelse til &lt;n&gt; (standard: 100)</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Gennemsøg blokkæden for manglende tegnebogstransaktioner</translation>
    </message>
    <message>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>Brug OpenSSL (https) for JSON-RPC-forbindelser</translation>
    </message>
    <message>
        <source>Server certificate file (default: server.cert)</source>
        <translation>Servercertifikat-fil (standard: server.cert)</translation>
    </message>
    <message>
        <source>Server private key (default: server.pem)</source>
        <translation>Serverens private nøgle (standard: server.pem)</translation>
    </message>
    <message>
        <source>This help message</source>
        <translation>Denne hjælpebesked</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer (bind returned error %d, %s)</source>
        <translation>Kunne ikke tildele %s på denne computer (bind returnerede fejl %d, %s)</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Tillad DNS-opslag for -addnode, -seednode og -connect</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Indlæser adresser …</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Fejl ved indlæsning af wallet.dat: Tegnebog ødelagt</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet requires newer version of Beginnercoin</source>
        <translation>Fejl ved indlæsning af wallet.dat: Tegnebog kræver en nyere version af Beginnercoin</translation>
    </message>
    <message>
        <source>Wallet needed to be rewritten: restart Beginnercoin to complete</source>
        <translation>Det var nødvendigt at genskrive tegnebogen: genstart Beginnercoin for at gennemføre</translation>
    </message>
    <message>
        <source>Error loading wallet.dat</source>
        <translation>Fejl ved indlæsning af wallet.dat</translation>
    </message>
    <message>
        <source>Invalid -proxy address: &apos;%s&apos;</source>
        <translation>Ugyldig -proxy adresse: &quot;%s&quot;</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: &apos;%s&apos;</source>
        <translation>Ukendt netværk anført i -onlynet: &quot;%s&quot;</translation>
    </message>
    <message>
        <source>Unknown -socks proxy version requested: %i</source>
        <translation>Ukendt -socks proxy-version: %i</translation>
    </message>
    <message>
        <source>Cannot resolve -bind address: &apos;%s&apos;</source>
        <translation>Kan ikke finde -bind adressen: &quot;%s&quot;</translation>
    </message>
    <message>
        <source>Cannot resolve -externalip address: &apos;%s&apos;</source>
        <translation>Kan ikke finde -externalip adressen: &quot;%s&quot;</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Ugyldigt beløb for -paytxfee=&lt;beløb&gt;: &quot;%s&quot;</translation>
    </message>
    <message>
        <source>Invalid amount</source>
        <translation>Ugyldigt beløb</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Manglende dækning</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Indlæser blokindeks …</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Tilføj en knude til at forbinde til og forsøg at holde forbindelsen åben</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Indlæser tegnebog …</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Kan ikke nedgradere tegnebog</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>Kan ikke skrive standardadresse</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Genindlæser …</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Indlæsning gennemført</translation>
    </message>
    <message>
        <source>To use the %s option</source>
        <translation>For at bruge %s mulighed</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fejl</translation>
    </message>
    <message>
        <source>You must set rpcpassword=&lt;password&gt; in the configuration file:
%s
If the file does not exist, create it with owner-readable-only file permissions.</source>
        <translation>Du skal angive rpcpassword=&lt;adgangskode&gt; i konfigurationsfilen:
%s
Hvis filen ikke eksisterer, opret den og giv ingen andre end ejeren læserettighed.</translation>
    </message>
</context>
</TS>