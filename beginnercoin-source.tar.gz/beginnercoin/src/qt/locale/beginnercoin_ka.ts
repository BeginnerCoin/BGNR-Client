<?xml version="1.0" ?><!DOCTYPE TS><TS language="ka" version="2.1">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About Beginnercoin Core</source>
        <translation>Beginnercoin Core-ს შესახებ</translation>
    </message>
    <message>
        <source>&lt;b&gt;Beginnercoin Core&lt;/b&gt; version</source>
        <translation>&lt;b&gt;Beginnercoin Core&lt;/b&gt;-ს ვერსია</translation>
    </message>
    <message>
        <source>
This is experimental software.

Distributed under the MIT/X11 software license, see the accompanying file COPYING or http://www.opensource.org/licenses/mit-license.php.

This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (http://www.openssl.org/) and cryptographic software written by Eric Young (eay@cryptsoft.com) and UPnP software written by Thomas Bernard.</source>
        <translation>
პროგრამა ექსპერიმენტულია.

ვრცელდება MIT/X11 ლიცენზიით, იხილე თანდართული ფაილი COPYING ან http://www.opensource.org/licenses/mit-license.php.

პროდუქტი შეიცავს OpenSSL პროექტის ფარგლებში შემუშავებულ პროგრამულ უზრუნველყოფას OpenSSL Toolkit-ში გამოყენებისათვის (http://www.openssl.org/), კრიპტოგრაფიულ პროგრამას, ავტორი ერიქ იანგი (Eric Young, eay@cryptsoft.com) და UPnP-პროგრამას, ავტორი თომას ბერნარდი (Thomas Bernard).</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>საავტორო უფლებები</translation>
    </message>
    <message>
        <source>The Beginnercoin Core developers</source>
        <translation>Beginnercoin Core-ს ავტორები</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Double-click to edit address or label</source>
        <translation>დააკლიკეთ ორჯერ მისამართის ან ნიშნულის შესაცვლელად</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>ახალი მისამართის შექმნა</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>შექმ&amp;ნა</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>მონიშნული მისამართის კოპირება სისტემურ კლიპბორდში</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;კოპირება</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;დახურვა</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>&amp;მისამართის კოპირება</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>მონიშნული მისამართის წაშლა სიიდან</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>ამ ბარათიდან მონაცემების ექსპორტი ფაილში</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;ექსპორტი</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;წაშლა</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>აირჩიეთ მონეტების გაგზავნის მისამართი</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>აირჩიეთ მონეტების მიღების მისამართი</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>&amp;არჩევა</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>გაგზავნის მისამართი</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>მიღების მისამართი</translation>
    </message>
    <message>
        <source>These are your Beginnercoin addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>ეს არის თქვენი Beginnercoin-მისამართები გადახდების შესასრულებლად. მონეტების გაგზავნამდე ყოველთვის შეამოწმეთ თანხა და მიმღების მისამართი.</translation>
    </message>
    <message>
        <source>These are your Beginnercoin addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>ეს არის თქვენი Beginnercoin-მისამართები გადახდების მისაღებად. რეკომენდებულია ყოველი ტრანსაქციისათვის ახალი მიღების მისამართის გამოყენება.</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>ნიშნუ&amp;ლის კოპირება</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>რ&amp;ედაქტირება</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>მისამართების სიის ექსპორტი</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>CSV-ფაილი (*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>ექსპორტი ვერ განხორციელდა</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1.</source>
        <translation>შეცდომა მისამართების სიის %1-ში შენახვის მცდელობისას.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>ნიშნული</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>მისამართი</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(არ არის ნიშნული)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>ფრაზა-პაროლის დიალოგი</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>შეიყვანეთ ფრაზა-პაროლი</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>ახალი ფრაზა-პაროლი</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>გაიმეორეთ ახალი ფრაზა-პაროლი</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>შეიყვანეთ საფულის ახალი ფრაზა-პაროლი.&lt;br/&gt;ფრაზა-პაროლი შეადგინეთ &lt;b&gt;არანაკლებ 10 შემთხვევითი სიმბოლოსაგან&lt;/b&gt;, ან &lt;b&gt;რვა და მეტი სიტყვისაგან&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>საფულის დაშიფრვა</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>ეს ოპერაცია მოითხოვს თქვენი საფულის ფრაზა-პაროლს საფულის განსაბლოკად.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>საფულის განბლოკვა</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>ეს ოპერაცია მოითხოვს თქვენი საფულის ფრაზა-პაროლს საფულის გასაშიფრად.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>საფულის გაშიფრვა</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>ფრაზა-პაროლის შეცვლა</translation>
    </message>
    <message>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>შეიყვანეთ საფულის ძველი და ახალი ფრაზა-პაროლი.</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>დაადასტურეთ საფულის დაშიფრვა</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR BEGINNERCOINS&lt;/b&gt;!</source>
        <translation>ყურადღება: საფულის დაშიფრვის შემდეგ თუ თქვენ დაკარგავთ ფრაზა-პაროლს,  &lt;b&gt;ყველა ბიტქოინი დაგეკარგებათ&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>დარწმუნებული ხართ, რომ გინდათ საფულის დაშიფრვა?</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>მნიშვნელოვანია: თქვენი საფულის ყველა ადრინდელი არქივი შეიცვლება ახლადგენერირებული დაშიფრული საფულის ფაილით. უსაფრთხოების მოსაზრებებით დაუშიფრავი საფულის ძველი არქივები ძალას დაკარგავს, როგორც კი დაიწყებთ ახალი, დაშიფრული საფულის გამოყენებას.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>ყურადღება: ჩართულია Caps Lock რეჟიმი!</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>საფულე დაშიფრულია</translation>
    </message>
    <message>
        <source>Beginnercoin will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your beginnercoins from being stolen by malware infecting your computer.</source>
        <translation>ახლა Beginnercoin დაიხურება დაშიფრვის პროცესის დასასრულებლად. გაითვალისწინეთ, რომ დაშიფრვა სრულად ვერ დაიცავს თქვენს ბითქოინებს თქვენს კომპიუტერში შემოპარული მავნე პროგრამების საშუალებით დატაცებისაგან.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>ვერ მოხერხდა საფულის დაშიფრვა</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>საფულის დაშიფრვა ვერ მოხერხდა სისტემაში შეცდომის გამო. თქვენი საფულე არ არის დაშფრული.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>ფრაზა-პაროლები არ ემთხვევა ერთმანეთს.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>საფულის განბლოკვა ვერ მოხერხდა</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>საფულის განშიფრვის ფრაზა-პაროლი არაწორია</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>საფულის განშიფრვა ვერ მოხერხდა</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>საფულის ფრაზა-პაროლი შეცვლილია.</translation>
    </message>
</context>
<context>
    <name>BeginnercoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>ხელ&amp;მოწერა</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>ქსელთან სინქრონიზება...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>მიმ&amp;ოხილვა</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>კვანძი</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>საფულის ზოგადი მიმოხილვა</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;ტრანსაქციები</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>ტრანსაქციების ისტორიის დათვალიერება</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;გასვლა</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>გასვლა</translation>
    </message>
    <message>
        <source>Show information about Beginnercoin</source>
        <translation>ინფორმაცია Beginnercoin-ის შესახებ</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>&amp;Qt-ს შესახებ</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>ინფორმაცია Qt-ს შესახებ</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;ოპციები</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>საფულის &amp;დაშიფრვა</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>საფულის &amp;არქივირება</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>ფრაზა-პაროლის შე&amp;ცვლა</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>გაგზავნის მი&amp;სამართი</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>მიღების მისამა&amp;რთი</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>&amp;URI-ის გახსნა...</translation>
    </message>
    <message>
        <source>Importing blocks from disk...</source>
        <translation>ბლოკების იმპორტი დისკიდან...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>დისკზე ბლოკების რეინდექსაცია...</translation>
    </message>
    <message>
        <source>Send coins to a Beginnercoin address</source>
        <translation>მონეტების გაგზავნა Beginnercoin-მისამართზე</translation>
    </message>
    <message>
        <source>Modify configuration options for Beginnercoin</source>
        <translation>Beginnercoin-ის საკონფიგურაციო პარამეტრების ცვლილება</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>საფულის არქივირება სხვა ადგილზე</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>საფულის დაშიფრვის ფრაზა-პაროლის შეცვლა</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>და&amp;ხვეწის ფანჯარა</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>დახვეწისა და გიაგნოსტიკის კონსოლის გაშვება</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;ვერიფიკაცია</translation>
    </message>
    <message>
        <source>Beginnercoin</source>
        <translation>Beginnercoin</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>საფულე</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;გაგზავნა</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>&amp;მიღება</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;ჩვენება/დაფარვა</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>მთავარი ფანჯრის ჩვენება/დაფარვა</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>თქვენი საფულის პირადი გასაღებების დაშიფრვა</translation>
    </message>
    <message>
        <source>Sign messages with your Beginnercoin addresses to prove you own them</source>
        <translation>მესიჯებზე ხელმოწერა თქვენი Beginnercoin-მისამართებით იმის დასტურად, რომ ის თქვენია</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Beginnercoin addresses</source>
        <translation>შეამოწმეთ, რომ მესიჯები ხელმოწერილია მითითებული Beginnercoin-მისამართით</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;ფაილი</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;პარამეტრები</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;დახმარება</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>ბარათების პანელი</translation>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
    <message>
        <source>Beginnercoin Core</source>
        <translation>Beginnercoin Core</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and beginnercoin: URIs)</source>
        <translation>გადახდის მოთხოვნა (შეიქმნება QR-კოდები და beginnercoin: ბმულები)</translation>
    </message>
    <message>
        <source>&amp;About Beginnercoin Core</source>
        <translation>Beginnercoin Core-ს შეს&amp;ახებ</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>გამოყენებული გაგზავნის მისამართებისა და ნიშნულების სიის ჩვენება</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>გამოყენებული მიღების მისამართებისა და ნიშნულების სიის ჩვენება</translation>
    </message>
    <message>
        <source>Open a beginnercoin: URI or payment request</source>
        <translation>beginnercoin: URI-ის ან გადახდის მოთხოვნის გახსნა</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>საკომანდო სტრიქონის ოპ&amp;ციები</translation>
    </message>
    <message>
        <source>Show the Beginnercoin Core help message to get a list with possible Beginnercoin command-line options</source>
        <translation>Beginnercoin Core-ს დახმარების ჩვენება Beginnercoin-ის საკომანდო სტრიქონის დასაშვები ოპციების სანახავად</translation>
    </message>
    <message>
        <source>Beginnercoin client</source>
        <translation>Beginnercoin-კლიენტი</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Beginnercoin network</source>
        <translation><numerusform>აქტიური მიერთებები ბითქოინის ქსელთან: %n</numerusform></translation>
    </message>
    <message>
        <source>No block source available...</source>
        <translation>ბლოკების წყარო მიუწვდომელია...</translation>
    </message>
    <message>
        <source>Processed %1 of %2 (estimated) blocks of transaction history.</source>
        <translation>დამუშავებულია ტრანსაქციების ისტორიის %2-დან (სავარაუდოდ) %1 ბლოკი.</translation>
    </message>
    <message>
        <source>Processed %1 blocks of transaction history.</source>
        <translation>დამუშავებულია ტრანსაქციების ისტორიის %1 ბლოკი.</translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation><numerusform>%n საათი</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation><numerusform>%n დღე</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation><numerusform>%n კვირა</numerusform></translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 და %2</translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation><numerusform>%n წელი</numerusform></translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>%1 გავლილია</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>ბოლო მიღებული ბლოკის გენერირებიდან გასულია %1</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>შემდგომი ტრანსაქციები ნაჩვენები ჯერ არ იქნება.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>შეცდომა</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>გაფრთხილება</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>ინფორმაცია</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>განახლებულია</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>ჩართვა...</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>გაგზავნილი ტრანსაქციები</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>მიღებული ტრანსაქციები</translation>
    </message>
    <message>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>თარიღი: %1
თანხა: %2
ტიპი: %3
მისამართი: %4
</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>საფულე &lt;b&gt;დაშიფრულია&lt;/b&gt; და ამჟამად &lt;b&gt;განბლოკილია&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>საფულე &lt;b&gt;დაშიფრულია&lt;/b&gt; და ამჟამად &lt;b&gt;დაბლოკილია&lt;/b&gt;</translation>
    </message>
    <message>
        <source>A fatal error occurred. Beginnercoin can no longer continue safely and will quit.</source>
        <translation>ფატალური შეცდომა. Beginnercoin ვერ უზრუნველყოფს უსაფრთხო გაგრძელებას, ამიტომ იხურება.</translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <source>Network Alert</source>
        <translation>ქსელური განგაში</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Control Address Selection</source>
        <translation>მონეტების კონტროლის მისამართის არჩევა</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>რაოდენობა:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>ბაიტები:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>თანხა:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>პრიორიტეტი:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>საკომისიო:</translation>
    </message>
    <message>
        <source>Low Output:</source>
        <translation>ქვედა ზღვარი:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>დამატებითი საკომისიო:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>ხურდა:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>ყველას მონიშვნა/(მოხსნა)</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>განტოტვილი</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>სია</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>რაოდენობა</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>მისამართი</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>თარიღი</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>დადასტურება</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>დადასტურებულია</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>პრიორიტეტი</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>მისამართის კოპირება</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>ნიშნულის კოპირება</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>თანხის კოპირება</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>ტრანსაქციის ID-ს კოპირება</translation>
    </message>
    <message>
        <source>Lock unspent</source>
        <translation>დაუხარჯავის დაბლოკვა</translation>
    </message>
    <message>
        <source>Unlock unspent</source>
        <translation>დაუხარჯავის განბლოკვა</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>რაოდენობის კოპირება</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>საკომისიოს კოპირება</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>დამატებითი საკომისიოს კოპირება</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>ბაიტების კოპირება</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>პრიორიტეტის კოპირება</translation>
    </message>
    <message>
        <source>Copy low output</source>
        <translation>ქვედა ზღვრის კოპირება</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>ხურდის კოპირება</translation>
    </message>
    <message>
        <source>highest</source>
        <translation>უმაღლესი</translation>
    </message>
    <message>
        <source>higher</source>
        <translation>უფრო მაღალი</translation>
    </message>
    <message>
        <source>high</source>
        <translation>მაღალი</translation>
    </message>
    <message>
        <source>medium-high</source>
        <translation>საშუალოზე მაღალი</translation>
    </message>
    <message>
        <source>medium</source>
        <translation>საშუალო</translation>
    </message>
    <message>
        <source>low-medium</source>
        <translation>საშუალოზე დაბალი</translation>
    </message>
    <message>
        <source>low</source>
        <translation>დაბალი</translation>
    </message>
    <message>
        <source>lower</source>
        <translation>უფრო დაბალი</translation>
    </message>
    <message>
        <source>lowest</source>
        <translation>უდაბლესი</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation>(%1 დაბლოკილია)</translation>
    </message>
    <message>
        <source>none</source>
        <translation>ცარიელი</translation>
    </message>
    <message>
        <source>Dust</source>
        <translation>მტვერი</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>კი</translation>
    </message>
    <message>
        <source>no</source>
        <translation>არა</translation>
    </message>
    <message>
        <source>This label turns red, if the transaction size is greater than 1000 bytes.</source>
        <translation>ნიშნული წითლდება, როცა ტრანსაქციის ზომა 1000 ბაიტზე მეტია.</translation>
    </message>
    <message>
        <source>This means a fee of at least %1 per kB is required.</source>
        <translation>ეს ნიშნავს, რომ კილობაიტზე საკომისიო იქნება მინიმუმ %1</translation>
    </message>
    <message>
        <source>Can vary +/- 1 byte per input.</source>
        <translation>შეიძლება იყოს +/- 1 ბაიტი ყოველ შესავალზე.</translation>
    </message>
    <message>
        <source>Transactions with higher priority are more likely to get included into a block.</source>
        <translation>მეტი პრიორიტეტის ტრანსაქციებს მეტი შანსი აქვს მოხვდეს ბლოკში.</translation>
    </message>
    <message>
        <source>This label turns red, if the priority is smaller than &quot;medium&quot;.</source>
        <translation>ნიშნული წითლდება, როცა პრიორიტეტი &quot;საშუალო&quot;-ზე დაბალია.</translation>
    </message>
    <message>
        <source>This label turns red, if any recipient receives an amount smaller than %1.</source>
        <translation>ნიშნული წითლდება, როცა რომელიმე რეციპიენტი მიიღებს %1-ზე ნაკლებს.</translation>
    </message>
    <message>
        <source>This means a fee of at least %1 is required.</source>
        <translation>ეს ნიშნავს, რომ საკომისიო იქნება მინიმუმ %1.</translation>
    </message>
    <message>
        <source>Amounts below 0.546 times the minimum relay fee are shown as dust.</source>
        <translation>რეტრანსლაციის მინიმალური საკომისიოს 0.546-ზე ნაკლები თანხები ნაჩვენები იქნება როგორც მტვერი.</translation>
    </message>
    <message>
        <source>This label turns red, if the change is smaller than %1.</source>
        <translation>ნიშნული წითლდება, როცა ხურდა ნაკლებია %1-ზე.</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(არ არის ნიშნული)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation>ხურდა %1-დან (%2)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation>(ხურდა)</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>მისამართის შეცვლა</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>ნიშნუ&amp;ლი</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>მისამართების სიის ამ ჩანაწერთან ასოცირებული ნიშნული</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>მისამართების სიის ამ ჩანაწერთან მისამართი ასოცირებული. მისი შეცვლა შეიძლება მხოლოდ გაგზავნის მისამართის შემთხვევაში.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>მის&amp;ამართი</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>ახალი მიღების მისამართი</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>ახალი გაგზავნის მისამართი</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>მიღების მისამართის შეცვლა</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>გაგზავნის მისამართის შეცვლა</translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>მისამართი &quot;%1&quot; უკვე არის მისამართების წიგნში.</translation>
    </message>
    <message>
        <source>The entered address &quot;%1&quot; is not a valid Beginnercoin address.</source>
        <translation>შეყვანილი მისამართი &quot;%1&quot; არ არის ვალიდური Beginnercoin-მისამართი.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>საფულის განბლოკვა ვერ მოხერხდა.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>ახალი გასაღების გენერირება ვერ მოხერხდა</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>შეიქმნება ახალი მონაცემთა კატალოგი.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>სახელი</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>კატალოგი უკვე არსებობს. დაამატეთ %1 თუ გინდათ ახალი კატალოგის აქვე შექმნა.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>მისამართი უკვე არსებობს და არ წარმოადგენს კატალოგს.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>კატალოგის აქ შექმნა შეუძლებელია.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>Beginnercoin Core - Command-line options</source>
        <translation>Beginnercoin Core - საკომანდო სტრიქონის ოპციები</translation>
    </message>
    <message>
        <source>Beginnercoin Core</source>
        <translation>Beginnercoin Core</translation>
    </message>
    <message>
        <source>version</source>
        <translation>ვერსია</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>გამოყენება:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>კომანდების ზოლის ოპციები</translation>
    </message>
    <message>
        <source>UI options</source>
        <translation>ინტერფეისის პარამეტრები</translation>
    </message>
    <message>
        <source>Set language, for example &quot;de_DE&quot; (default: system locale)</source>
        <translation>აირჩიეთ ენა, მაგალითად &quot;de_DE&quot; (ნაგულისხმევია სისტემური ლოკალი)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>გაშვება მინიმიზებული ეკრანით</translation>
    </message>
    <message>
        <source>Set SSL root certificates for payment request (default: -system-)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show splash screen on startup (default: 1)</source>
        <translation>მისალმების ეკრანის ჩვენება გაშვებისას (ნაგულისხმევი:1)</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: 0)</source>
        <translation>მონაცემთა კატალოგის მითითება ყოველი გაშვებისას (ნაგულისხმევი: 0)</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>მოგესალმებით</translation>
    </message>
    <message>
        <source>Welcome to Beginnercoin Core.</source>
        <translation>მოგესალმებათ Beginnercoin Core.</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where Beginnercoin Core will store its data.</source>
        <translation>ეს პროგრამის პირველი გაშვებაა; შეგიძლიათ მიუთითოთ, სად შეინახოს მონაცემები Beginnercoin Core-მ.</translation>
    </message>
    <message>
        <source>Beginnercoin Core will download and store a copy of the Beginnercoin block chain. At least %1GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</source>
        <translation>Beginnercoin Core გადმოტვირთავს და შეინახავს Beginnercoin-ის ბლოკთა ჯაჭვს. მითითებულ კატალოგში დაგროვდება სულ ცოტა 1 გბ მონაცემები, და მომავალში უფრო გაიზრდება. საფულეც ამავე კატალოგში შეინახება.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>ნაგულისხმევი კატალოგის გამოყენება</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>მითითებული კატალოგის გამოყენება:</translation>
    </message>
    <message>
        <source>Beginnercoin</source>
        <translation>Beginnercoin</translation>
    </message>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; can not be created.</source>
        <translation>შეცდომა: მითითებული მონაცემთა კატალოგი &quot;%1&quot; ვერ შეიქმნა.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>შეცდომა</translation>
    </message>
    <message>
        <source>GB of free space available</source>
        <translation>გიგაბაიტია თავისუფალი</translation>
    </message>
    <message>
        <source>(of %1GB needed)</source>
        <translation>(საჭიროა  %1GB)</translation>
    </message>
</context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>URI-ის გახსნა</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>გადახდის მოთხოვნის შექმნა URI-იდან ან ფაილიდან</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>გადახდის მოთხოვნის ფაილის არჩევა</translation>
    </message>
    <message>
        <source>Select payment request file to open</source>
        <translation>გადახდის მოთხოვნის ფაილის არჩევა გასახსნელად</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>ოპციები</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;მთავარი</translation>
    </message>
    <message>
        <source>Optional transaction fee per kB that helps make sure your transactions are processed quickly. Most transactions are 1 kB.</source>
        <translation>დამატებითი საკომისიო თითო კილობაიტზე; აჩქარებს ტრანსაქციის შესრულებას. ტრანსაქციების უმეტესობა არის 1 კბ.</translation>
    </message>
    <message>
        <source>Pay transaction &amp;fee</source>
        <translation>ტრანსაქციის სა&amp;ფასურის გადახდა</translation>
    </message>
    <message>
        <source>Automatically start Beginnercoin after logging in to the system.</source>
        <translation>სისტემაში შესვლის შემდეგ Beginnercoin-ის ავტომატური გაშვება.</translation>
    </message>
    <message>
        <source>&amp;Start Beginnercoin on system login</source>
        <translation>&amp;სისტემაში შესვლისას გაშვება</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>მონაცემთა ბაზის კეშის სი&amp;დიდე</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation>სკრიპტის &amp;ვერიფიცირების ნაკადების რაოდენობა</translation>
    </message>
    <message>
        <source>Connect to the Beginnercoin network through a SOCKS proxy.</source>
        <translation>Beginnercoin-ქსელზე მიერთება SOCKS-პროქსით.</translation>
    </message>
    <message>
        <source>&amp;Connect through SOCKS proxy (default proxy):</source>
        <translation>SO&amp;CKS (ნაგულისხმევი) პროქსი მიერთებისათვის:</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>პროქსის IP-მისამართი (მაგ.: IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Third party URLs (e.g. a block explorer) that appear in the transactions tab as context menu items. %s in the URL is replaced by transaction hash. Multiple URLs are separated by vertical bar |.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Third party transaction URLs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Active command-line options that override above options:</source>
        <translation>საკომანდო სტრიქონის აქტიური ოპციები, რომლებიც გადაფარავენ ზემოთნაჩვენებს:</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>კლიენტის ყველა პარამეტრის დაბრუნება ნაგულისხმევ მნიშვნელობებზე.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>დაბ&amp;რუნების ოპციები</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;ქსელი</translation>
    </message>
    <message>
        <source>(0 = auto, &lt;0 = leave that many cores free)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>ს&amp;აფულე</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction cannot be used until that transaction has at least one confirmation. This also affects how your balance is computed.</source>
        <translation>დაუდასტურებელი ხურდის გამოყენების აკრძალვის შემდეგ მათი გამოყენება შეუძლებელი იქნება, სანამ ტრანსაქციას არ ექნება ერთი დასტური მაინც. ეს აისახება თქვენი ნაშთის დათვლაზეც.</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Automatically open the Beginnercoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>როუტერში Beginnercoin-კლიენტის პორტის ავტომატური გახსნა. მუშაობს, თუ თქვენს როუტერს ჩართული აქვს UPnP.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>პორტის გადამისამართება &amp;UPnP-ით</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>პროქსის &amp;IP:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;პორტი</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>პროქსის პორტი (მაგ.: 9050)</translation>
    </message>
    <message>
        <source>SOCKS &amp;Version:</source>
        <translation>SOCKS &amp;ვერსია:</translation>
    </message>
    <message>
        <source>SOCKS version of the proxy (e.g. 5)</source>
        <translation>პროქსის SOCKS-ვერსია (მაგ.: 5)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;ფანჯარა</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>ფანჯრის მინიმიზებისას მხოლოდ იკონა სისტემურ ზონაში</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;მინიმიზება სისტემურ ზონაში პროგრამების პანელის ნაცვლად</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>პროგრამის მინიმიზება ფანჯრის დახურვისას. ოპციის ჩართვის შემდეგ პროგრამის დახურვა შესაძლებელი იქნება მხოლოდ მენიუდან - პუნქტი &quot;გასვლა&quot;.</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>მ&amp;ინიმიზება დახურვისას</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;ჩვენება</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>სამომხმარებ&amp;ლო ენა:</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting Beginnercoin.</source>
        <translation>აქ შეგიძლიათ აირჩიოთ სამომხმარებლო ენა. ძალაში შევა Beginnercoin-ის რესტარტის შემდეგ.</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>ერთეუ&amp;ლი:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>აირჩიეთ გასაგზავნი თანხის ნაგულისხმევი ერთეული.</translation>
    </message>
    <message>
        <source>Whether to show Beginnercoin addresses in the transaction list or not.</source>
        <translation>ტრანსაქციების სიაში იყოს თუ არა ნაჩვენები Beginnercoin-მისამართები.</translation>
    </message>
    <message>
        <source>&amp;Display addresses in transaction list</source>
        <translation>მისამართების &amp;ჩვენება სიაში</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>ვაჩვენოთ თუ არა მონეტების მართვის პარამეტრები.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;გაუქმება</translation>
    </message>
    <message>
        <source>default</source>
        <translation>ნაგულისხმევი</translation>
    </message>
    <message>
        <source>none</source>
        <translation>ცარიელი</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>დაადასტურეთ პარამეტრების დაბრუნება ნაგულისხმევზე</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>ცვლილებები ძალაში შევა კლიენტის ხელახალი გაშვების შემდეგ.</translation>
    </message>
    <message>
        <source>Client will be shutdown, do you want to proceed?</source>
        <translation>კლიენტი დაიხურება, გავაგრძელოთ?</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>ამ ცვლილებების ძალაში შესასვლელად საჭიროა კლიენტის დახურვა და ხელახალი გაშვება.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>პროქსის მისამართი არასწორია.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>ფორმა</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Beginnercoin network after a connection is established, but this process has not completed yet.</source>
        <translation>ნაჩვენები ინფორმაცია შეიძლება მოძველებული იყოს. თქვენი საფულე ავტომატურად სინქრონიზდება Beginnercoin-ის ქსელთან კავშირის დამყარების შემდეგ, ეს პროცესი ჯერ არ არის დასრულებული.</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>საფულე</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>ხელმისაწვდომია:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>თქვენი ხელმისაწვდომი ნაშთი</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>იგზავნება:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>დასადასტურებელი ტრანსაქციების საერთო რაოდენობა, რომლებიც ჯერ არ არის ასახული ბალანსში</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>მოუმზადებელია:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>მოპოვებული თანხა, რომელიც ჯერ არ არის მზადყოფნაში</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>სულ:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>თქვენი სრული მიმდინარე ბალანსი</translation>
    </message>
    <message>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;ბოლო ტრანსაქციები&lt;/b&gt;</translation>
    </message>
    <message>
        <source>out of sync</source>
        <translation>არ არის სინქრონიზებული</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>URI handling</source>
        <translation>URI-ების დამუშავება</translation>
    </message>
    <message>
        <source>URI can not be parsed! This can be caused by an invalid Beginnercoin address or malformed URI parameters.</source>
        <translation>URI-ის დამუშავება ვერ მოხერხდა. შესაძლოა არასწორია Beginnercoin-მისამართი ან  URI-ის პარამეტრები.</translation>
    </message>
    <message>
        <source>Requested payment amount of %1 is too small (considered dust).</source>
        <translation>მოთხოვნილი გადახდის %1 მოცულობა ძალიან მცირეა (ითვლება &quot;მტვრად&quot;)</translation>
    </message>
    <message>
        <source>Payment request error</source>
        <translation>გადახდის მოთხოვნის შეცდომა</translation>
    </message>
    <message>
        <source>Cannot start beginnercoin: click-to-pay handler</source>
        <translation>ვერ გაიშვა beginnercoin: click-to-pay</translation>
    </message>
    <message>
        <source>Net manager warning</source>
        <translation>გაფრთხილება ქსელის მენეჯერისაგან</translation>
    </message>
    <message>
        <source>Your active proxy doesn&apos;t support SOCKS5, which is required for payment requests via proxy.</source>
        <translation>თქვენს აქტიურ პროქსის არა აქვს SOCKS5-ის მხარდაჭერა, რაც საჭიროა გადახდების პროქსით განხორციელებისათვის.</translation>
    </message>
    <message>
        <source>Payment request fetch URL is invalid: %1</source>
        <translation>არასწორია გადახდის მოთხოვნის URL: %1</translation>
    </message>
    <message>
        <source>Payment request file handling</source>
        <translation>გადახდის მოთხოვნის ფაილის დამუშავება</translation>
    </message>
    <message>
        <source>Payment request file can not be read or processed! This can be caused by an invalid payment request file.</source>
        <translation>ვერ ხერხდება გადახდის მოთხოვნის ფაილის წაკითხვა ან დამუშავება! შესაძლოა დაზიანებულია გადახდის მოთხოვნის ფაილი.</translation>
    </message>
    <message>
        <source>Unverified payment requests to custom payment scripts are unsupported.</source>
        <translation>არავერიფიცირებული გადახდის მოთხოვნები გადახდის სამომხმარებლო სკრიპტებისათვის არ არის მხარდაჭერილი.</translation>
    </message>
    <message>
        <source>Refund from %1</source>
        <translation>დაბრუნება %1-საგან</translation>
    </message>
    <message>
        <source>Error communicating with %1: %2</source>
        <translation>ვერ გამოდის კავშირზე %1: %2</translation>
    </message>
    <message>
        <source>Payment request can not be parsed or processed!</source>
        <translation>ვერ ხერხდება გადახდის მოთხოვნის გარჩევა ან დამუშავება!</translation>
    </message>
    <message>
        <source>Bad response from server %1</source>
        <translation>ცუდი პასუხი სერვერისაგან %1</translation>
    </message>
    <message>
        <source>Payment acknowledged</source>
        <translation>გადახდა მიღებულია</translation>
    </message>
    <message>
        <source>Network request error</source>
        <translation>ქსელური მოთხოვნის შეცდომა</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Beginnercoin</source>
        <translation>Beginnercoin</translation>
    </message>
    <message>
        <source>Error: Specified data directory &quot;%1&quot; does not exist.</source>
        <translation>შეცდომა: მითითებული მონაცემთა კატალოგი &quot;%1&quot; არ არსებობს.</translation>
    </message>
    <message>
        <source>Error: Cannot parse configuration file: %1. Only use key=value syntax.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Error: Invalid combination of -regtest and -testnet.</source>
        <translation>შეცდომა: -regtest-ისა და -testnet-ის დაუშვებელი კომბინაცია.</translation>
    </message>
    <message>
        <source>Beginnercoin Core didn&apos;t yet exit safely...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Enter a Beginnercoin address (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>შეიყვანეთ ბიტკოინ-მისამართი (მაგ. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>გამო&amp;სახულების შენახვა</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation>გამოსახულების &amp;კოპირება</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation>QR-კოდის შენახვა</translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation>PNG სურათი (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Client name</source>
        <translation>კლიენტი</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>მიუწვდ.</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>კლიენტის ვერსია</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;ინფორმაცია</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>დახვეწის ფანჯარა</translation>
    </message>
    <message>
        <source>General</source>
        <translation>საერთო</translation>
    </message>
    <message>
        <source>Using OpenSSL version</source>
        <translation>OpenSSL-ის ვერსია</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>სტარტის დრო</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>ქსელი</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>სახელი</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>შეერთებების რაოდენობა</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>ბლოკთა ჯაჭვი</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>ბლოკების მიმდინარე რაოდენობა</translation>
    </message>
    <message>
        <source>Estimated total blocks</source>
        <translation>ბლოკების სავარაუდო რაოდენობა</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>ბოლო ბლოკის დრო</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;შექმნა</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;კონსოლი</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>&amp;ქსელის ტრაფიკი</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;წაშლა</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>ჯამი</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>შემომავალი:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>გამავალი:</translation>
    </message>
    <message>
        <source>Build date</source>
        <translation>შექმნის დრო</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>დახვეწის ლოგ-ფაილი</translation>
    </message>
    <message>
        <source>Open the Beginnercoin debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>გახსენით Beginnercoin-ის დახვეწის ლოგ-ფაილი მიმდინარე კატალოგიდან. დიდი ლოგ-ფაილის შემთხვევაში ამას შეიძლება რამდენიმე წამი მოუნდეს.</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>კონსოლის გასუფთავება</translation>
    </message>
    <message>
        <source>Welcome to the Beginnercoin RPC console.</source>
        <translation>მოგესალმებათ Beginnercoin-ის RPC კონსოლი.</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>კლავიშები &quot;ზევით&quot; და &quot;ქვევით&quot; - ისტორიაში მოძრაობა, &lt;b&gt;Ctrl-L&lt;/b&gt; - ეკრანის გასუფთავება.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>აკრიფეთ &lt;b&gt;help&lt;/b&gt; ფაშვებული ბრძანებების სანახავად.</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 წთ</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 სთ</translation>
    </message>
    <message>
        <source>%1 h %2 m</source>
        <translation>%1 სთ %2 წთ</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>თ&amp;ანხა:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>ნიშნუ&amp;ლი:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;მესიჯი:</translation>
    </message>
    <message>
        <source>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</source>
        <translation>რომელიმე ადრე გამოყენებული მიღების მისამართის გამოყენება. ეს ამცირებს უსაფრთხოებასა და პრივატულობას. ნუ გამოიყენებთ ამ ოპციას, თუ არ ახდენთ ადრე მოთხოვნილი გადახდის ხელახლა გენერირებას.</translation>
    </message>
    <message>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation>ად&amp;რე გამოყენებული მიღების მისამართის გამოყენება (არ არის რეკომენდებული)</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Beginnercoin network.</source>
        <translation>არააუცილებელი მესიჯი, რომელიც ერთვის გადახდის მოთხოვნას და ნაჩვენები იქნება მოთხოვნის გახსნისას. შენიშვნა: მესიჯი არ გაყვება გადახდას ბითქოინის ქსელში.</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation>არააუცილებელი ნიშნული ახალ მიღების მისამართთან ასოცირებისათვის.</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>გამოიყენეთ ეს ფორმა გადახდის მოთხოვნისათვის. ყველა ველი &lt;b&gt;არააუცილებელია&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation>მოთხოვნის მოცულობა. არააუცილებელია. ჩაწერეთ 0 ან დატოვეთ ცარიელი, თუ არ მოითხოვება კონკრეტული მოცულობა.</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>ფორმის ყველა ველის წაშლა</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>წაშლა</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>მოთხოვნილი გადახდების ისტორია</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>&amp;გადახდის მოთხოვნა</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation>არჩეული მოთხოვნის ჩვენება (იგივეა, რაც ჩანაწერზე ორჯერ ჩხვლეტა)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>ჩვენება</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation>მონიშნული ჩანაწერების წაშლა სიიდან</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>წაშლა</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>ნიშნულის კოპირება</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>მესიჯის კოპირება</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>თანხის კოპირება</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR-კოდი</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>&amp;URI-ის კოპირება</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>მის&amp;ამართის კოპირება</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>გამო&amp;სახულების შენახვა...</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation>%1-ის გადაზდის მოთხოვნა</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>ინფორმაცია გადახდის შესახებ</translation>
    </message>
    <message>
        <source>URI</source>
        <translation>URI</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>მისამართი</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>რაოდენობა</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>ნიშნული</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>მესიჯი</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>URI ძალიან გრძელი გამოდის, შეამოკლეთ ნიშნულის/მესიჯის ტექსტი.</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation>შედომა URI-ის QR-კოდში გადაყვანისას.</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>თარიღი</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>ნიშნული</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>მესიჯი</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>რაოდენობა</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(არ არის ნიშნული)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>(მესიჯები არ არის)</translation>
    </message>
    <message>
        <source>(no amount)</source>
        <translation>(თანხა არ არის)</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>მონეტების გაგზავნა</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>მონეტების კონტროლის პარამეტრები</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>ხარჯები...</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>არჩეულია ავტომატურად</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>არ არის საკმარისი თანხა!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>რაოდენობა:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>ბაიტები:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>თანხა:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>პრიორიტეტი:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>საკომისიო:</translation>
    </message>
    <message>
        <source>Low Output:</source>
        <translation>ქვედა ზღვარი:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>დამატებითი საკომისიო:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>ხურდა:</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation>ამის გააქტიურებისას თუ ხურდის მისამართი ცარიელია ან არასწორია, ხურდა გაიგზავნება ახლად გენერირებულ მისამართებზე.</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation>ხურდის მისამართი</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>გაგზავნა რამდენიმე რეციპიენტთან ერთდროულად</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>&amp;რეციპიენტის დამატება</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>ფორმის ყველა ველის წაშლა</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>გ&amp;ასუფთავება</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>ბალანსი:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>გაგზავნის დადასტურება</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>გაგ&amp;ზავნა</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>მონეტების გაგზავნის დადასტურება</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation>%1-დან %2-ში</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>რაოდენობის კოპირება</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>თანხის კოპირება</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>საკომისიოს კოპირება</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>დამატებითი საკომისიოს კოპირება</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>ბაიტების კოპირება</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>პრიორიტეტის კოპირება</translation>
    </message>
    <message>
        <source>Copy low output</source>
        <translation>ქვედა ზღვრის კოპირება</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>ხურდის კოპირება</translation>
    </message>
    <message>
        <source>Total Amount %1 (= %2)</source>
        <translation>ჯამური თანხა %1 (= %2)</translation>
    </message>
    <message>
        <source>or</source>
        <translation>ან</translation>
    </message>
    <message>
        <source>The recipient address is not valid, please recheck.</source>
        <translation>მიმღების მისამართი არასწორია, შეამოწმეთ.</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>გადახდის მოცულობა 0-ზე მეტი უნდა იყოს</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>თანხა აღემატება თქვენს ბალანსს</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>საკომისიო 1%-ის დამატების შემდეგ თანხა აჭარბებს თქვენს ბალანსს</translation>
    </message>
    <message>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation>მისამართები დუბლირებულია, დაშვებულია ერთ ჯერზე თითო მისამართზე ერთხელ გაგზავნა.</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation>შეცდომა ტრანსაქციის შექმნისას!</translation>
    </message>
    <message>
        <source>The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>ტრანსაქცია უარყოფილია! შესაძლოა მონეტების ნაწილი თქვენი საფულიდან უკვე გამოყენებულია, რაც შეიძლება მოხდეს wallet.dat-ის ასლის გამოყენებისას, როცა მონეტები გაიგზავნა სხვა ასლიდან, აქ კი არ არის გაგზავნილად მონიშნული.</translation>
    </message>
    <message>
        <source>Warning: Invalid Beginnercoin address</source>
        <translation>ყურადღება: არასწორია Beginnercoin-მისამართი</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(არ არის ნიშნული)</translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation>ყურადღება: უცნობია ხურდის მისამართი</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>დარწმუნებული ხართ, რომ გინდათ გაგზავნა?</translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation>დამატებულია საკომისიო</translation>
    </message>
    <message>
        <source>Payment request expired</source>
        <translation>გადახდის მოთხოვნას ვადა გაუვიდა</translation>
    </message>
    <message>
        <source>Invalid payment address %1</source>
        <translation>გადახდის მისამართი არასწორია: %1</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>&amp;რაოდენობა</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>ადრესა&amp;ტი:</translation>
    </message>
    <message>
        <source>The address to send the payment to (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>მისამართი, რომლითაც ასრულებთ გადახდას (მაგ.: 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>შეიყვანეთ ამ მისამართის ნიშნული მისამართების წიგნში დასამატებლად</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>ნიშნუ&amp;ლი:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>აირჩიეთ ადრე გამოყენებული მისამართი</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>ეს არის ჩვეულებრივი გადახდა.</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>მისამართის ჩასმა კლიპბორდიდან</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>ჩანაწერის წაშლა</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>მესიჯი:</translation>
    </message>
    <message>
        <source>This is a verified payment request.</source>
        <translation>ეს არის ვერიფიცირებული გადახდის მოთხოვნა.</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation>შეიყვანეთ ამ მისამართის ნიშნული გამოყენებული მისამართების სიაში დასამატებლად</translation>
    </message>
    <message>
        <source>A message that was attached to the beginnercoin: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Beginnercoin network.</source>
        <translation>მესიჯი, რომელიც თან ერთვის მონეტებს:  URI, რომელიც შეინახება ტრანსაქციასთან ერთად თქვენთვის. შენიშვნა: მესიჯი არ გაყვება გადახდას ბითქოინის ქსელში.</translation>
    </message>
    <message>
        <source>This is an unverified payment request.</source>
        <translation>ეს არის არავერიფიცირებული გადახდის მოთხოვნა.</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>ადრესატი:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>შენიშვნა:</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>Beginnercoin Core is shutting down...</source>
        <translation>Beginnercoin Core იხურება...</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>არ გამორთოთ კომპიუტერი ამ ფანჯრის გაქრობამდე.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>ხელმოწერები - მესიჯის ხელმოწერა/ვერიფიკაცია</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>მე&amp;სიჯის ხელმოწერა</translation>
    </message>
    <message>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>ხელმოწერით თქვენ ადასტურებთ, რომ მესიჯი თქვენია. ფრთხილად - არ მოაწეროთ ხელი რაიმე საეჭვოს: ფიშინგური ხრიკებით შეიძლება ის თქვენს მესიჯად გაასაღონ. მოაწერეთ ხელი მხოლოდ იმას, რასაც ყველა წვრილმანში ეთანხმებით.</translation>
    </message>
    <message>
        <source>The address to sign the message with (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>მისამართი, რომლითაც ხელს აწერთ (მაგ.: 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>აირჩიეთ ადრე გამოყენებული მისამართი</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>მისამართის ჩასმა კლიპბორდიდან</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>აკრიფეთ ხელმოსაწერი მესიჯი</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>ხელმოწერა</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>მიმდინარე ხელმოწერის კოპირება კლიპბორდში</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Beginnercoin address</source>
        <translation>მოაწერეთ ხელი იმის დასადასტურებლად, რომ ეს მისამართი თქვენია</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>&amp;მესიჯის ხელმოწერა</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>ხელმოწერის ყველა ველის წაშლა</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>გ&amp;ასუფთავება</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>მესიჯის &amp;ვერიფიკაცია</translation>
    </message>
    <message>
        <source>Enter the signing address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack.</source>
        <translation>შეიყვანეთ ხელმოწერის მისამართი, მესიჯი (დაუკვირდით, რომ ზუსტად იყოს კოპირებული სტრიქონის გადატანები, ჰარები, ტაბულაციები და სხვ) და ხელმოწერა მესიჯის ვერიფიკაციისათვის. მიაქციეთ ყურადღება, რომ რაიმე ზედმეტი არ გაგყვეთ კოპირებისას, რათა არ გახდეთ &quot;man-in-the-middle&quot; შეტევის ობიექტი.</translation>
    </message>
    <message>
        <source>The address the message was signed with (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>მისამართი, რომლითაც ხელმოწერილია მესიჯი (მაგ.: 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Beginnercoin address</source>
        <translation>შეამოწმეთ, რომ მესიჯი ხელმოწერილია მითითებული Beginnercoin-მისამართით</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>&amp;მესიჯის ვერიფიკაცია</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>ვერიფიკაციის ყველა ველის წაშლა</translation>
    </message>
    <message>
        <source>Enter a Beginnercoin address (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>შეიყვანეთ ბიტკოინ-მისამართი (მაგ. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <source>Click &quot;Sign Message&quot; to generate signature</source>
        <translation>ხელმოწერის გენერირებისათვის დააჭირეთ &quot;მესიჯის ხელმოწერა&quot;-ს</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>შეყვანილი მისამართი არასწორია.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>შეამოწმეთ მისამართი და სცადეთ ხელახლა.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>შეყვანილი მისამართი არ არის კავშირში გასაღებთან.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>საფულის განბლოკვა შეწყვეტილია.</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>ამ მისამართისათვის პირადი გასაღები მიუწვდომელია.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation>ვერ მოხერხდა მესიჯის ხელმოწერა.</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>მესიჯი ხელმოწერილია.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>ხელმოწერის დეკოდირება ვერ ხერხდება.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>შეამოწმეთ ხელმოწერა და სცადეთ ხელახლა.</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation>ხელმოწერა არ შეესაბამება მესიჯის დაიჯესტს.</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation>მესიჯის ვერიფიკაცია ვერ მოხერხდა.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>მესიჯი ვერიფიცირებულია.</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>Beginnercoin Core</source>
        <translation>Beginnercoin Core</translation>
    </message>
    <message>
        <source>The Beginnercoin Core developers</source>
        <translation>Beginnercoin Core-ს ავტორები</translation>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>ღია იქნება სანამ %1</translation>
    </message>
    <message>
        <source>conflicted</source>
        <translation>კონფლიქტშია</translation>
    </message>
    <message>
        <source>%1/offline</source>
        <translation>%1/გათიშულია</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/დაუდასტურებელია</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 დადასტურებულია</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>სტატუსი</translation>
    </message>
    <message numerus="yes">
        <source>, broadcast through %n node(s)</source>
        <translation><numerusform>, დაგზავნილია %n კვანძისათვის</numerusform></translation>
    </message>
    <message>
        <source>Date</source>
        <translation>თარიღი</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>წყარო</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>გენერირებულია</translation>
    </message>
    <message>
        <source>From</source>
        <translation>გამგზავნი</translation>
    </message>
    <message>
        <source>To</source>
        <translation>მიმღები</translation>
    </message>
    <message>
        <source>own address</source>
        <translation>საკუთარი მისამართი</translation>
    </message>
    <message>
        <source>label</source>
        <translation>ნიშნული</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation>კრედიტი</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation><numerusform>მზად იქნება %n ბლოკის შემდეგ</numerusform></translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation>უარყოფილია</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>დებიტი</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>ტრანსაქციის საფასური - საკომისიო</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation>სუფთა თანხა</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>მესიჯი</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>შენიშვნა</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation>ტრანსაქციის ID</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation>გამყიდველი</translation>
    </message>
    <message>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to &quot;not accepted&quot; and it won&apos;t be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>გენერირებული მონეტები გასაგზავნად მომწიფდება %1 ბლოკის შემდეგ. ეს ბლოკი გენერირების შემდეგ გავრცელებულ იქნა ქსელში ბლოკთა ჯაჭვზე დასამატებლად. თუ ის ვერ ჩაჯდა ჯაჭვში, მიეცემა სტატუსი &quot;უარყოფილია&quot; და ამ მონეტებს ვერ გამოიყენებთ. ასეთი რამ შეიძლება მოხდეს, თუ რომელიმე კვანძმა რამდენიმე წამით დაგასწროთ ბლოკის გენერირება.</translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation>დახვეწის ინფორმაცია</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation>ტრანსაქცია</translation>
    </message>
    <message>
        <source>Inputs</source>
        <translation>ხარჯები</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>თანხა</translation>
    </message>
    <message>
        <source>true</source>
        <translation>ჭეშმარიტი</translation>
    </message>
    <message>
        <source>false</source>
        <translation>მცდარი</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>, დაგზავნა არ არის წარმატებით დასრულებული</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation><numerusform>ღიაა კიდევ %n ბლოკისათვის</numerusform></translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>უცნობია</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>ტრანსაქციის დეტალები</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>ტრანსაქციის დაწვრილებითი აღწერილობა</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>თარიღი</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>ტიპი</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>მისამართი</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>რაოდენობა</translation>
    </message>
    <message>
        <source>Immature (%1 confirmations, will be available after %2)</source>
        <translation>არ არის მომწიფებული (%1 დასტური, საჭიროა სულ %2)</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation><numerusform>ღიაა კიდევ %n ბლოკისათვის</numerusform></translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>ღია იქნება სანამ %1</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>დადასტურებულია (%1დასტური)</translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>ეს ბლოკი არ არის მიღებული არცერთი კვანძის მიერ და სავარაუდოდ უარყოფილია!</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>გენერირებულია, მაგრამ უარყოფილია</translation>
    </message>
    <message>
        <source>Offline</source>
        <translation>ოფლაინშია</translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation>დაუდასტურებელია</translation>
    </message>
    <message>
        <source>Confirming (%1 of %2 recommended confirmations)</source>
        <translation>დადასტურებულია (%1,  რეკომენდებულია %2)</translation>
    </message>
    <message>
        <source>Conflicted</source>
        <translation>კონფლიქტშია</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>მიღებულია</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>გამომგზავნი</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>გაგზავნილია ადრესატთან</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>გადახდილია საკუთარი თავისათვის</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>მოპოვებულია</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(მიუწვდ.)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>ტრანსაქციის სტატუსი. ველზე კურსორის შეყვანისას გამოჩნდება დასტურების რაოდენობა.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>ტრანსაქციის მიღების თარიღი და დრო.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>ტრანსაქციის ტიპი.</translation>
    </message>
    <message>
        <source>Destination address of transaction.</source>
        <translation>ტრანსაქიის დანიშნულების მისამართი.</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>ბალანსიდან მოხსნილი ან დამატებული თანხა.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>ყველა</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>დღეს</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>ამ კვირის</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>ამ თვის</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>ბოლო თვის</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>ამ წლის</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>შუალედი...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>შემოსულია</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>გაგზავნილია</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>საკუთარი თავისათვის</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>მოპოვებულია</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>სხვა</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>შეიყვანეთ საძებნი მისამართი ან ნიშნული</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>მინ. თანხა</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>მისამართის კოპირება</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>ნიშნულის კოპირება</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>თანხის კოპირება</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>ტრანსაქციის ID-ს კოპირება</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>ნიშნულის რედაქტირება</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>ტრანსაქციის დეტალების ჩვენება</translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation>ტრანსაქციების ისტორიის ექსპორტი</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>ექსპორტი ვერ განხორციელდა</translation>
    </message>
    <message>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation>შეცდომა %1-ში ტრანსაქციების შენახვის მცდელობისას.</translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation>ეხპორტი განხორციელებულია</translation>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation>ტრანსაქციების ისტორია შენახულია %1-ში.</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>CSV-ფაილი (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>დადასტურებულია</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>თარიღი</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>ტიპი</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>ნიშნული</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>მისამართი</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>თანხა</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>შუალედი:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>-</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.</source>
        <translation>არ არის ჩატვირთული საფულე.</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>მონეტების გაგზავნა</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;ექსპორტი</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>ამ ბარათიდან მონაცემების ექსპორტი ფაილში</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>საფულის არქივირება</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>საფულის მონაცემები (*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>არქივირება ვერ მოხერხდა</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation>შეცდომა %1-ში საფულის მონაცემების შენახვის მცდელობისას.</translation>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation>საფულის მონაცემები შენახულია %1-ში.</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation>არქივირება შესრულებულია</translation>
    </message>
</context>
<context>
    <name>beginnercoin-core</name>
    <message>
        <source>Usage:</source>
        <translation>გამოყენება:</translation>
    </message>
    <message>
        <source>List commands</source>
        <translation>ბრძანებები</translation>
    </message>
    <message>
        <source>Get help for a command</source>
        <translation>ბრძანების აღწერილობა</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>ოპციები:</translation>
    </message>
    <message>
        <source>Specify configuration file (default: beginnercoin.conf)</source>
        <translation>მიუთითეთ საკონფიგურაციო ფაილი (ნაგულისხმევია: beginnercoin.conf)</translation>
    </message>
    <message>
        <source>Specify pid file (default: beginnercoind.pid)</source>
        <translation>მიუთითეთ pid ფაილი (ნაგულისხმევია: beginnercoind.pid)</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>მიუთითეთ მონაცემთა კატალოგი</translation>
    </message>
    <message>
        <source>Listen for connections on &lt;port&gt; (default: 9844 or testnet: 19844)</source>
        <translation>მიყურადება პორტზე &lt;port&gt; (ნაგულისხმევი: 9844 ან სატესტო ქსელში: 19844)</translation>
    </message>
    <message>
        <source>Maintain at most &lt;n&gt; connections to peers (default: 125)</source>
        <translation>არაუმეტეს &lt;n&gt; შეერთებისა პირებზე (ნაგულისხმევი: 125)</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>მიერთება კვანძთან, პირების მისამართების მიღება და გათიშვა</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>მიუთითეთ თქვენი საჯარო მისამართი</translation>
    </message>
    <message>
        <source>Threshold for disconnecting misbehaving peers (default: 100)</source>
        <translation>არასწორად მოქმედი პირების გათიშვის ზღვარი (ნაგულისხმევი:100)</translation>
    </message>
    <message>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: 86400)</source>
        <translation>არასწორად მოქმედი პირების ბლოკირების დრო წამებში (ნაგულისხმევი: 86400)</translation>
    </message>
    <message>
        <source>An error occurred while setting up the RPC port %u for listening on IPv4: %s</source>
        <translation>შეცდომა %u RPC-პორტის მიყურადების ჩართვისას IPv4 მისამართზე: %s</translation>
    </message>
    <message>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: 9744 or testnet: 19744)</source>
        <translation> JSON-RPC-შეერთებების მიყურადება პორტზე &lt;port&gt; (ნაგულისხმევი: 9744 ან სატესტო ქსელში: 19744)</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>საკომანდო სტრიქონისა და JSON-RPC-კომამდების ნებართვა</translation>
    </message>
    <message>
        <source>Beginnercoin Core RPC client version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>რეზიდენტულად გაშვება და კომანდების მიღება</translation>
    </message>
    <message>
        <source>Use the test network</source>
        <translation>სატესტო ქსელის გამოყენება</translation>
    </message>
    <message>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation>გარედან შეერთებების დაშვება (ნაგულისხმევი: 1 თუ არ გამოიყენება -proxy ან -connect)</translation>
    </message>
    <message>
        <source>%s, you must set a rpcpassword in the configuration file:
%s
It is recommended you use the following random password:
rpcuser=beginnercoinrpc
rpcpassword=%s
(you do not need to remember this password)
The username and password MUST NOT be the same.
If the file does not exist, create it with owner-readable-only file permissions.
It is also recommended to set alertnotify so you are notified of problems;
for example: alertnotify=echo %%s | mail -s &quot;Beginnercoin Alert&quot; admin@foo.com
</source>
        <translation>%s, მიუთითეთ rpcpassword საკონფიგურაციო ფაილში:
%s
რეკომენდებულია შემდეგი შემთხვევითი პაროლი:
rpcuser=beginnercoinrpc
rpcpassword=%s
(ამის დამახსოვრება არ გჭირდებათ)
სახელი და პაროლი ერთმანეთს არ უნდა ემთხვეოდეს.
თუ ფაილი არ არსებობს, შექმენით იგი უფლებებით owner-readable-only.
ასევე რეკომენდებულია დააყენოთ alertnotify რათა მიიღოთ შეტყობინებები პრობლემების შესახებ;
მაგალითად: alertnotify=echo %%s | mail -s &quot;Beginnercoin Alert&quot; admin@foo.com
</translation>
    </message>
    <message>
        <source>Acceptable ciphers (default: TLSv1.2+HIGH:TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!3DES:@STRENGTH)</source>
        <translation>დაშვებული ალგორითმები (ნაგულისხმევი: TLSv1.2+HIGH:TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!3DES:@STRENGTH)</translation>
    </message>
    <message>
        <source>An error occurred while setting up the RPC port %u for listening on IPv6, falling back to IPv4: %s</source>
        <translation>შეცდომა %u RPC-პორტის მიყურადების ჩართვისას IPv6 მისამართზე, ვბრუნდებით IPv4-ზე : %s</translation>
    </message>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>მოცემულ მისამართზე მიჯაჭვა მუდმივად მასზე მიყურადებით. გამოიყენეთ [host]:port ფორმა IPv6-სათვის</translation>
    </message>
    <message>
        <source>Continuously rate-limit free transactions to &lt;n&gt;*1000 bytes per minute (default:15)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Enter regression test mode, which uses a special chain in which blocks can be solved instantly. This is intended for regression testing tools and app development.</source>
        <translation>შესვლა რეგრესული ტესტირების რეჟიმში; სპეციალური ჯაჭვის გამოყენებით ბლოკების პოვნა ხდება დაუყოვნებლივ. გამოიყენება რეგრესული ტესტირების ინსტრუმენტებისა და პროგრამების შემუშავებისას.</translation>
    </message>
    <message>
        <source>Enter regression test mode, which uses a special chain in which blocks can be solved instantly.</source>
        <translation>გადასვლა რეგრესული ტესტირების რეჟიმში, რომელიც იყენებს სპეციალურ ჯაჭვს ბლოკების დაუყოვნებლივი პოვნის შესაძლებლობით.</translation>
    </message>
    <message>
        <source>Error: Listening for incoming connections failed (listen returned error %d)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Error: The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>შეცდომა: ტრანსაქცია უარყოფილია! შესაძლოა მონეტების ნაწილი თქვენი საფულიდან უკვე გამოყენებულია, რაც შეიძლება მოხდეს wallet.dat-ის ასლის გამოყენებისას, როცა მონეტები გაიგზავნა სხვა ასლიდან, აქ კი არ არის გაგზავნილად მონიშნული.</translation>
    </message>
    <message>
        <source>Error: This transaction requires a transaction fee of at least %s because of its amount, complexity, or use of recently received funds!</source>
        <translation>შეცდომა: ტრანსაქცია მოითხოვს საკომისიოს მინიმუმ %s რაოდენობის, სირთულის ან ბოლოს მიღებული თანხების შესაბამისად!</translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation>კომანდის შესრულება საფულის ტრანსაქციის ცვლილებისას (%s კომანდაში ჩანაცვლდება TxID-ით)</translation>
    </message>
    <message>
        <source>Fees smaller than this are considered zero fee (for transaction creation) (default:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Flush database activity from memory pool to disk log every &lt;n&gt; megabytes (default: 100)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>How thorough the block verification of -checkblocks is (0-4, default: 3)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>In this mode -genproclimit controls how many blocks are generated immediately.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Set the number of script verification threads (%u to %d, 0 = auto, &lt;0 = leave that many cores free, default: %d)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Set the processor limit for when generation is on (-1 = unlimited, default: -1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation>ეს არის წინასწარი სატესტო ვერსია - გამოიყენეთ საკუთარი რისკით - არ გამოიყენოთ მოპოვებისა ან კომერციული მიზნებისათვის</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer. Beginnercoin Core is probably already running.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services (default: -proxy)</source>
        <translation>ფარული Tor-სერვისებით პირების წვდომისათვის სხვა SOCKS5 პროქსის გამოყენება (ნაგულისხმევია: -proxy)</translation>
    </message>
    <message>
        <source>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</source>
        <translation>ყურადღება:  ძალიან მაღალია -paytxfee - საკომისო, რომელსაც თქვენ გადაიხდით ამ ტრანსაქციის გაგზავნის საფასურად.</translation>
    </message>
    <message>
        <source>Warning: Please check that your computer&apos;s date and time are correct! If your clock is wrong Beginnercoin will not work properly.</source>
        <translation>ყურადღება: შეამოწმეთ თქვენი კომპიუტერის სისტემური თარიღი და დრო! თუ ისინი არასწორია, Beginnercoin ვერ იმუშავებს კორექტულად.</translation>
    </message>
    <message>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation>ყურადღება: ქსელში შეუთანხმებლობაა. შესაძლოა ცალკეულ მომპოვებლებს პრობლემები ექმნებათ!</translation>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation>ყურადღება: ჩვენ არ ვეთანხმებით ყველა პირს. შესაძლოა თქვენ ან სხვა კვანძებს განახლება გჭირდებათ.</translation>
    </message>
    <message>
        <source>Warning: error reading wallet.dat! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>ყურადღება: არ იკითხება wallet.dat! ყველა გასაღები წაკითხულია, მაგრამ გამორჩენილი ან არასწორია ტრანსაქციის თარიღი ან ჩანაწერები მისამართების წიგნში.</translation>
    </message>
    <message>
        <source>Warning: wallet.dat corrupt, data salvaged! Original wallet.dat saved as wallet.{timestamp}.bak in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>ყურადღება: wallet.dat დაზიანებულია! ორიგინალური wallet.dat შენახულია როგორც wallet.{timestamp}.bak %s-ში; თუ შეამჩნიეთ უზუსტობა ნაშთში ან ტრანსაქციებში, აღადგინეთ არქივიდან.</translation>
    </message>
    <message>
        <source>(default: 1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>(default: wallet.dat)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>&lt;category&gt; can be:</source>
        <translation>&lt;category&gt; შეიძლება იყოს:</translation>
    </message>
    <message>
        <source>Attempt to recover private keys from a corrupt wallet.dat</source>
        <translation>პირადი გასაღებების აღდგენის მცდელობა wallet.dat-იდან</translation>
    </message>
    <message>
        <source>Beginnercoin Core Daemon</source>
        <translation>Beginnercoin Core დემონი</translation>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation>ბლოკის შექმნის ოპციები:</translation>
    </message>
    <message>
        <source>Clear list of wallet transactions (diagnostic tool; implies -rescan)</source>
        <translation>საფულის ტრანსაქციების სიის წაშლა (დიაგნოსტიკის საშუალება; მოიცავს -rescan-ს)</translation>
    </message>
    <message>
        <source>Connect only to the specified node(s)</source>
        <translation>შეერთება მხოლოდ მითითებულ კვანძ(ებ)თან</translation>
    </message>
    <message>
        <source>Connect through SOCKS proxy</source>
        <translation>შეერთება SOCKS-პროქსით</translation>
    </message>
    <message>
        <source>Connect to JSON-RPC on &lt;port&gt; (default: 9744 or testnet: 19744)</source>
        <translation> JSON-RPC-შეერთება პორტზე &lt;port&gt; (ნაგულისხმევი: 9744 ან სატესტო ქსელში: 19744)</translation>
    </message>
    <message>
        <source>Connection options:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>შენიშნულია ბლოკთა ბაზის დაზიანება</translation>
    </message>
    <message>
        <source>Debugging/Testing options:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Disable safemode, override a real safe mode event (default: 0)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Discover own IP address (default: 1 when listening and no -externalip)</source>
        <translation>საკუთარი IP-მისამართის განსაზღვრა (ნაგულისხმევი: 1 თუ ჩართულია მიყურადება და არ გამოიყენება -externalip)</translation>
    </message>
    <message>
        <source>Do not load the wallet and disable wallet RPC calls</source>
        <translation>არ ჩაიტვირთოს საფულე და აიკრძალოს საფულისადმი RPC-მიმართვები</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>გავუშვათ ბლოკთა ბაზის ხელახლა აგება ეხლა?</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>ვერ ინიციალიზდება ბლოკების ბაზა</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>ვერ ინიციალიზდება საფულის ბაზის გარემო %s!</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>არ იტვირთება ბლოკების ბაზა</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>ბლოკთა ბაზის შექმნა ვერ მოხერხდა</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>შეცდომა: დისზე არ არის ადგილი!</translation>
    </message>
    <message>
        <source>Error: Wallet locked, unable to create transaction!</source>
        <translation>შეცდომა: საფულე დაბლოკილია, ტრანსაქცია ვერ შეიქმნება!</translation>
    </message>
    <message>
        <source>Error: system error: </source>
        <translation>შეცდომა: სისტემური შეცდომა:</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>ვერ ხერხდება პორტების მიყურადება. თუ გსურთ, გამოიყენეთ -listen=0.</translation>
    </message>
    <message>
        <source>Failed to read block info</source>
        <translation>ბლოკის ინფორმაცია არ იკითხება</translation>
    </message>
    <message>
        <source>Failed to read block</source>
        <translation>ბლოკი არ იკითხება</translation>
    </message>
    <message>
        <source>Failed to sync block index</source>
        <translation>ბლოკების ინდექსის სინქრონიზება ვერ მოხერხდა</translation>
    </message>
    <message>
        <source>Failed to write block index</source>
        <translation>ბლოკების ინდექსის ჩაწერა ვერ მოხერხდა</translation>
    </message>
    <message>
        <source>Failed to write block info</source>
        <translation>ბლოკის ინფორმაციის ჩაწერა ვერ მოხერხდა</translation>
    </message>
    <message>
        <source>Failed to write block</source>
        <translation>ბლოკის ჩაწერა ვერ მოხერხდა</translation>
    </message>
    <message>
        <source>Failed to write file info</source>
        <translation>ფაილის ინფორმაციის ჩაწერა ვერ მოხერხდა</translation>
    </message>
    <message>
        <source>Failed to write to coin database</source>
        <translation>მონეტების ბაზის ჩაწერა ვერ მოხერხდა</translation>
    </message>
    <message>
        <source>Failed to write transaction index</source>
        <translation>ტრანსაქციების ინდექსის ჩაწერა ვერ მოხერხდა</translation>
    </message>
    <message>
        <source>Failed to write undo data</source>
        <translation>ცვლილებების გაუქმების მონაცემთა ჩაწერა ვერ მოხერხდა</translation>
    </message>
    <message>
        <source>Fee per kB to add to transactions you send</source>
        <translation>საკომისო კბ-ზე, რომელიც დაემატება გაგზავნილ ტრანსაქციას</translation>
    </message>
    <message>
        <source>Fees smaller than this are considered zero fee (for relaying) (default:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Find peers using DNS lookup (default: 1 unless -connect)</source>
        <translation>პირების ძებნა DNS-ით (ნაგულისხმევი: 1 გარდა -connect-ისა)</translation>
    </message>
    <message>
        <source>Force safe mode (default: 0)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Generate coins (default: 0)</source>
        <translation>მონეტების გენერირება (ნაგულისხმევი: 0)</translation>
    </message>
    <message>
        <source>How many blocks to check at startup (default: 288, 0 = all)</source>
        <translation>რამდენი ბლოკი შემოწმდეს გაშვებისას (ნაგულისხმევი: 288, 0 - ყველა)</translation>
    </message>
    <message>
        <source>If &lt;category&gt; is not supplied, output all debugging information.</source>
        <translation>თუ &lt;category&gt; არ არის მითითებული, ნაჩვენები იქნება სრული დახვეწის ინფორმაცია.</translation>
    </message>
    <message>
        <source>Importing...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>საწყისი ბლოკი არ არსებობს ან არასწორია. ქსელის მონაცემთა კატალოგი datadir ხომ არის არასწორი?</translation>
    </message>
    <message>
        <source>Invalid -onion address: &apos;%s&apos;</source>
        <translation>არასწორია მისამართი -onion: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>არ არის საკმარისი ფაილ-დესკრიპტორები.</translation>
    </message>
    <message>
        <source>Prepend debug output with timestamp (default: 1)</source>
        <translation>დაემატოს დახვეწის ინფორმაციას დროის ჭდეები (ნაგულისხმევი: 1)</translation>
    </message>
    <message>
        <source>RPC client options:</source>
        <translation>RPC კლიენტის ოპციები:</translation>
    </message>
    <message>
        <source>Rebuild block chain index from current blk000??.dat files</source>
        <translation>ბლოკთა ჯაჭვის ინდექსის  ხელახლა აგება blk000??.dat ფაილიდან</translation>
    </message>
    <message>
        <source>Select SOCKS version for -proxy (4 or 5, default: 5)</source>
        <translation> SOCKS-ვერსიის არჩევა -proxy-სათვის (4 ან 5, ნაგულისხმევი: 5)</translation>
    </message>
    <message>
        <source>Set database cache size in megabytes (%d to %d, default: %d)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation>ბლოკის მაქსიმალური ზომის განსაზღვრა ბაიტებში (ნადულისხმევი: %d)</translation>
    </message>
    <message>
        <source>Set the number of threads to service RPC calls (default: 4)</source>
        <translation>RPC-ნაკადების რაოდენობა (ნაგულისხმევი: 4)</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>მიუთითეთ საფულის ფაილი (კატალოგში)</translation>
    </message>
    <message>
        <source>Spend unconfirmed change when sending transactions (default: 1)</source>
        <translation>დაუდასტურებელი ხურდის გამოყენება ტრანსაქციის გაგზავნისას (ნაგულისხმევი: 1)</translation>
    </message>
    <message>
        <source>This is intended for regression testing tools and app development.</source>
        <translation>გამოიყენება რეგრესული ტესტირების ინსტრუმენტებისა და პროგრამების შემუშავებისას.</translation>
    </message>
    <message>
        <source>Usage (deprecated, use beginnercoin-cli):</source>
        <translation>გამოყენება (მოძველებულია, გამოიყენეთ beginnercoin-cli):</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>ბლოკების ვერიფიკაცია...</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>საფულის ვერიფიკაცია...</translation>
    </message>
    <message>
        <source>Wait for RPC server to start</source>
        <translation>RPC-სერვერის დალოდება გაშვებისათვის</translation>
    </message>
    <message>
        <source>Wallet %s resides outside data directory %s</source>
        <translation>საფულე %s მდებარეობს მონაცემთა კატალოგის %s გარეთ</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>სფულის ოპციები:</translation>
    </message>
    <message>
        <source>Warning: Deprecated argument -debugnet ignored, use -debug=net</source>
        <translation>ყურადღება: მოძველებული არგუმენტი -debugnet იგნორირდება. გამოიყენეთ -debug=net</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to change -txindex</source>
        <translation>საჭიროა ბაზის ხელახალი აგება, გამოიყენეთ -reindex რათა შეცვალოთ -txindex</translation>
    </message>
    <message>
        <source>Imports blocks from external blk000??.dat file</source>
        <translation>ბლოკების იმპორტი გარე blk000??.dat ფაილიდან</translation>
    </message>
    <message>
        <source>Cannot obtain a lock on data directory %s. Beginnercoin Core is probably already running.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation>ბრძანების შესრულება შესაბამისი უწყების მიღებისას ან როცა შეინიშნება საგრძნობი გახლეჩა (cmd-ში %s შეიცვლება მესიჯით)</translation>
    </message>
    <message>
        <source>Output debugging information (default: 0, supplying &lt;category&gt; is optional)</source>
        <translation>დახვეწის ინფორმაციის გამოყვანა (ნაგულისხმევი: 0, &lt;category&gt; - არააუცილებელი არგუმენტია)</translation>
    </message>
    <message>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: %d)</source>
        <translation>მაღალპრიორიტეტული/დაბალსაკომისიოიანი ტრანსაქციების მაქსიმალური ზომა ბაიტებში (ნაგულისხმევი: %d)</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>ინფორმაცია</translation>
    </message>
    <message>
        <source>Invalid amount for -minrelaytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>დაუშვებელი მნიშვნელობა -minrelaytxfee=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount for -mintxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>დაუშვებელი მნიშვნელობა -mintxfee=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Limit size of signature cache to &lt;n&gt; entries (default: 50000)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Log transaction priority and fee per kB when mining blocks (default: 0)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Maintain a full transaction index (default: 0)</source>
        <translation>ტრანსაქციის სრული ინდექსი (ნაგულისხმევი: 0)</translation>
    </message>
    <message>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: 5000)</source>
        <translation>მიღების ბუფერის მაქსიმალური ზომა შეერთებაზე, &lt;n&gt;*1000 ბაიტი (ნაგულისხმევი: 5000)</translation>
    </message>
    <message>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: 1000)</source>
        <translation>გაგზავნის ბუფერის მაქსიმალური ზომა შეერთებაზე, &lt;n&gt;*1000 ბაიტი (ნაგულისხმევი: 5000)</translation>
    </message>
    <message>
        <source>Only accept block chain matching built-in checkpoints (default: 1)</source>
        <translation>ბლოკთა ჯაჭვი მიიღეთ მხოლოდ მაშინ, თუ ემთხვევა შიდა ჩეკპოინტები (ნაგულისხმევი: 1)</translation>
    </message>
    <message>
        <source>Only connect to nodes in network &lt;net&gt; (IPv4, IPv6 or Tor)</source>
        <translation>შეერთება მხოლოდ &lt;net&gt; ქსელის კვანძებთან (IPv4, IPv6 ან Tor)</translation>
    </message>
    <message>
        <source>Print block on startup, if found in block index</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Print block tree on startup (default: 0)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>RPC SSL options: (see the Beginnercoin Wiki for SSL setup instructions)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>RPC server options:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Randomly drop 1 of every &lt;n&gt; network messages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Randomly fuzz 1 of every &lt;n&gt; network messages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Run a thread to flush wallet periodically (default: 1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>SSL options: (see the Beginnercoin Wiki for SSL setup instructions)</source>
        <translation>SSL ოპციები: (იხილე Beginnercoin Wiki-ში  SSL-ს მოწყობის ინსტრუქციები)</translation>
    </message>
    <message>
        <source>Send command to Beginnercoin Core</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>ტრასირების/დახვეწის ინფოს გაგზავნა კონსოლზე debug.log ფაილის ნაცვლად</translation>
    </message>
    <message>
        <source>Set minimum block size in bytes (default: 0)</source>
        <translation>დააყენეთ ბლოკის მინიმალური ზომა ბაიტებში (ნაგულისხმევი: 0)</translation>
    </message>
    <message>
        <source>Sets the DB_PRIVATE flag in the wallet db environment (default: 1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show all debugging options (usage: --help -help-debug)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show benchmark information (default: 0)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>debug.log ფაილის შეკუმშვა გაშვებისას (ნაგულისხმევია: 1 როცა არ აყენია -debug)</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>ტრანსაქციების ხელმოწერა ვერ მოხერხდა</translation>
    </message>
    <message>
        <source>Specify connection timeout in milliseconds (default: 5000)</source>
        <translation>მიუთითეთ შეერთების ტაიმაუტი მილიწამებში (ნაგულისხმევი: 5000)</translation>
    </message>
    <message>
        <source>Start Beginnercoin Core Daemon</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>System error: </source>
        <translation>სისტემური შეცდომა:</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>ტრანსაქციების რაოდენობა ძალიან ცოტაა</translation>
    </message>
    <message>
        <source>Transaction amounts must be positive</source>
        <translation>ტრანსაქციების რაოდენობა დადებითი რიცხვი უნდა იყოს</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>ტრანსაქცია ძალიან დიდია</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 0)</source>
        <translation>გამოიყენეთ UPnP მისაყურადებელი პორტის გადასამისამართებლად (ნაგულისხმევი: 0)</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 1 when listening)</source>
        <translation>გამოიყენეთ UPnP მისაყურადებელი პორტის გადასამისამართებლად (ნაგულისხმევი: 1 როცა ჩართულია მიყურადება)</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>მომხმარებლის სახელი JSON-RPC-შეერთებისათვის</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>გაფრთხილება</translation>
    </message>
    <message>
        <source>Warning: This version is obsolete, upgrade required!</source>
        <translation>ყურადღება: ვერსია მოძველებულია, საჭიროა განახლება!</translation>
    </message>
    <message>
        <source>Zapping all transactions from wallet...</source>
        <translation>ტრანსაქციების ჩახსნა საფულიდან...</translation>
    </message>
    <message>
        <source>on startup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>version</source>
        <translation>ვერსია</translation>
    </message>
    <message>
        <source>wallet.dat corrupt, salvage failed</source>
        <translation>wallet.dat დაზიანებულია, აღდგენა ვერ მოხერხდა</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>პაროლი JSON-RPC-შეერთებისათვის</translation>
    </message>
    <message>
        <source>Allow JSON-RPC connections from specified IP address</source>
        <translation>JSON-RPC-შეერთების ნებართვა მითითებული IP მისამართიდან</translation>
    </message>
    <message>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</source>
        <translation>კომანდის გაგზავნა კვანძისათვის, რომელიც გაშვებულია მისამართზე &lt;ip&gt; (ნაგულისხმევი: 127.0.0.1)</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>კომანდის შესრულება უკეთესი ბლოკის გამოჩენისას (%s კომანდაში ჩანაცვლდება ბლოკის ჰეშით)</translation>
    </message>
    <message>
        <source>Upgrade wallet to latest format</source>
        <translation>საფულის ფორმატის განახლება</translation>
    </message>
    <message>
        <source>Set key pool size to &lt;n&gt; (default: 100)</source>
        <translation>გასაღების პულის ზომა იქნება &lt;n&gt; (ნაგულისხმევი: 100)</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>ბლოკების ჯაჭვის გადამოწმება საფულეში გამორჩენილ ტრანსაქციებზე</translation>
    </message>
    <message>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>OpenSSL-ის (https) გამოყენება JSON-RPC-შეერთებებისათვის</translation>
    </message>
    <message>
        <source>Server certificate file (default: server.cert)</source>
        <translation>სერვერის სერტიფიკატის ფაილი (ნაგულისხმევი: server.cert)</translation>
    </message>
    <message>
        <source>Server private key (default: server.pem)</source>
        <translation>სერვერის პირადი გასაღები (ნაგულისხმევი: server.pem)</translation>
    </message>
    <message>
        <source>This help message</source>
        <translation>ეს ტექსტი</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer (bind returned error %d, %s)</source>
        <translation>ვერ ხერხდება მიბმა %s-თან ამ კომპიუტერზე (მიღებულია შეცდომა %d, %s)</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>DNS-ძებნის დაშვება -addnode, -seednode და -connect-სათვის</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>მისამართების ჩატვირთვა...</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>არ იტვირთება wallet.dat: საფულე დაზიანებულია</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet requires newer version of Beginnercoin</source>
        <translation>არ იტვირთება wallet.dat: საფულეს სჭირდება Beginnercoin-ის ახალი ვერსია</translation>
    </message>
    <message>
        <source>Wallet needed to be rewritten: restart Beginnercoin to complete</source>
        <translation>საჭიროა საფულის აღდგენა: დაარესტარტეთ Beginnercoin </translation>
    </message>
    <message>
        <source>Error loading wallet.dat</source>
        <translation>არ იტვირთება wallet.dat</translation>
    </message>
    <message>
        <source>Invalid -proxy address: &apos;%s&apos;</source>
        <translation>არასწორია მისამართი -proxy: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: &apos;%s&apos;</source>
        <translation>-onlynet-ში მითითებულია უცნობი ქსელი: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Unknown -socks proxy version requested: %i</source>
        <translation>მოთხოვნილია -socks პროქსის უცნობი ვერსია: %i</translation>
    </message>
    <message>
        <source>Cannot resolve -bind address: &apos;%s&apos;</source>
        <translation>ვერ ხერხდება -bind მისამართის გარკვევა: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Cannot resolve -externalip address: &apos;%s&apos;</source>
        <translation>ვერ ხერხდება -externalip მისამართის გარკვევა: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>დაუშვებელი მნიშვნელობა -paytxfee=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <source>Invalid amount</source>
        <translation>დაუშვებელი თანხა</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>არ არის საკმარისი თანხა</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>ბლოკების ინდექსის ჩატვირთვა...</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>მისაერთებელი კვანძის დამატება და მიერთების შეძლებისდაგვარად შენარჩუნება</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>საფულის ჩატვირთვა...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>საფულის ძველ ვერსიაზე გადაყვანა შეუძლებელია</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>ვერ ხერხდება ნაგულისხმევი მისამართის ჩაწერა</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>სკანირება...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>ჩატვირთვა დასრულებულია</translation>
    </message>
    <message>
        <source>To use the %s option</source>
        <translation>%s ოპციის გამოსაყენებლად</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>შეცდომა</translation>
    </message>
    <message>
        <source>You must set rpcpassword=&lt;password&gt; in the configuration file:
%s
If the file does not exist, create it with owner-readable-only file permissions.</source>
        <translation>უნდა დააყენოთ rpcpassword=&lt;password&gt; საკონფიგურაციო ფაილში:
%s
თუ ეს ფაილი არ არსებობს, შექმენით იგი უფლებებით owner-readable-only.</translation>
    </message>
</context>
</TS>